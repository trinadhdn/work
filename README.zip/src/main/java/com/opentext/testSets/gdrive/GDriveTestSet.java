/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.gdrive;

import static org.testng.AssertJUnit.assertTrue;


import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.pageObjects.advanceSearch.AdvanceSearchPage;
import com.opentext.pageObjects.assetDetails.AssetDetailsPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsDownloadPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsMetadatasPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsSaveInCollectionPage;
import com.opentext.pageObjects.collection.types.GDriveCollectionPage;
import com.opentext.pageObjects.collectionInfo.CollectionInfoPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.containerCollections.ContainerCollectionsPage;
import com.opentext.pageObjects.createAndEditionCollection.specific.EditionCollectionPage;
import com.opentext.pageObjects.export.ExportPage;
import com.opentext.pageObjects.inbox.InboxPage;
import com.opentext.pageObjects.saveInCollection.SaveInCollectionPage;
import com.opentext.pageObjects.singleDownload.specificModal.MultiDownloadPage;
import com.opentext.pageObjects.singleDownload.specificModal.SingleDownloadPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.AssetCategoryValues.AssetType;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain the tests of the GDrive collections in the web
 * application.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 * @author Sowjanya Lankadasu <slankada@opentext.com>
 */
public class GDriveTestSet extends BasicTestSet {

    static Logger log = Logger.getLogger(GDriveTestSet.class);
    // String name = "Collection - 1503899790890";
    String name = null;
    String currentWindow = null;

    public GDriveTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
     * Check the Collection page elements:
     * 
     * -# @see loginAux()
     * -# @see createSimpleCollectionAux()
     * -# Check and create the Gdrive Collection page.
     * -# @see logoutAux()
     */
    @Test(description = "Check the Collection page elements.", priority = 1)
    public void checkLayout(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Create a new collection and enter.
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");
        name = collectionPage.getTitle();
        // Check the Collection page.
        assertTrue("Collection page is not ready after collection is created.", collectionPage.isReady());
        assertTrue("No records present text should be present.", collectionPage.isNoResultsTextPresent());

        // Perform the logout action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Saving result in an existing collection, check views and sort test:
     * 
     * -# @see loginAux() -# Search and add assets to existing collection -#
     * Navigate and check the Collection page for saved assets -# Check List
     * view -# Change the SortBy option -# Check thumbsnail view -# Change the
     * SortBy option -# @see logoutAux()
     */
    @Test(description = " Saving result in an existing collection, check views and sort test.", priority = 2)
    public void saveAssetsInAGDriveCollectionAndSortTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Search for a word with expected result.
        searchPage.search(SEARCH_WORD_2);
        assertTrue("Search page is not ready after performing a search.", searchPage.isReady());

        // Getting assets IDs to compare later.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        List<String> assetsIDs = containerAssets.getAssetIDsOfAssetsShown();

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add to created collection.
        saveInCollection.addToExistingCollection(name);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        collectionListAreaPage.sleep20();

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());

        // Sort by for every option in Thumbnails view
        for (int index = 1; index < collectionPage.getNumberOfOptionsInSortBy(); index++) {
            // Change the SortBy option.
            collectionPage.changeSortByOptionSelected(index);
            // Check the changes.
            assertTrue("Collection page is not ready while performing sort in thumbnails view.", collectionPage
                    .isReady());
        }

        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("All the assets are not saved in the Collection.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));

        // Change to List view.
        collectionPage.changeToListView();
        assertTrue("List view is not active.", !collectionPage.isThumbsViewActive());

        // Sort by for every option
        for (int index = 1; index < collectionPage.getNumberOfOptionsInSortBy(); index++) {
            // Change the SortBy option.
            collectionPage.changeSortByOptionSelected(index);
            // Check the changes.
            assertTrue("Collection page is not ready while performing sort in list view.", collectionPage.isReady());
        }

        // Perform the logout action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the search action with a non existing result, exisitng result,
     * multi-byte character search and Search History in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Search for
     * a word with expected no result. -# Search for a word with expected
     * result. -# Search for a multi-byte character with expected result. -#
     * Check the history. -# Change to List view and check. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Check the search action with a non existing and exisitng result and Search History in a collection.", priority = 3)
    public void searchForNonExistingAndExisitngResultAndHistoryTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Search for a word with expected no result.
        collectionPage.search(SEARCH_WORD_DONT_EXPECTED_RESULT);
        assertTrue("Test1/4: Collection page is not ready after performing no resutls search.", collectionPage
                .isReady());
        assertTrue("Test1/4: Assets should not be displayed for the given search key word", collectionPage
                .getCounterAssets() == 0);

        // Change to List view and check.
        collectionPage.changeToListView();
        assertTrue("Test1/4: List view is not active.", !collectionPage.isThumbsViewActive());

        // Search for a word with expected result.
        collectionPage.search(SEARCH_WORD_1);
        assertTrue("Test2/4: Collection page is not ready after search action.", collectionPage.isReady());
        assertTrue("Test2/4: Assets should be displayed for the given search key word", collectionPage
                .getCounterAssets() > 0);

        // Change to thumbnails view and check.
        collectionPage.changeToThumbsView();
        assertTrue("Test3/4: Verify assets in thumbnails view after search results action.", collectionPage
                .isThumbsViewActive());
        assertTrue("Test3/4: Collection page is not ready after changing to thumnails view from list view.", collectionPage
                .isReady());

        // Show the history.
        collectionPage.typeCleanSearchText(SEARCH_WORD_1);
        // Check the history.
        assertTrue("Test 3/4: The history is not shown.", collectionPage.isHistoryShown());

        // Select an option of the history.
        collectionPage.selectAnHistoryOptionAndSearch(2);
        assertTrue("Test3/4: Collection page is not ready after selecting a history option.", collectionPage.isReady());
        assertTrue("Test3/4: Assets should be displayed for the selected key word in search history ", collectionPage
                .getCounterAssets() > 0);

        // Change to List view and check.
        collectionPage.changeToListView();
        assertTrue("Test3/4: Verify assets in list view after multi-byte characters search action.", !collectionPage
                .isThumbsViewActive());

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the search action with a multi-byte character search :
     *
     * -# @see loginAux() 
     * -# Create a collection and add a asset with multi-byte character name.
     * -# Naviaget to the collection and search for the asset.
     * -# Change to List view and check. 
     * -# @see deleteCollectionAux()
     * -# @see logoutAux()
     */
    @Test(description = "Check the search action with multi byte characters in a collection.", priority = 29)
    public void searchForMultiByteCharacterTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Create collection by giving shared user and Collection Owner.
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Save name collection
        String name = collectionPage.getTitle();
        // int oldCounterCollection = collectionPage.getHeader().getCollectionCounter();

        // Navigate to the search page
        searchPage = collectionPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready to work.", searchPage.isReady());

        // Perform a keyword search
        searchPage.search(SEARCH_WORD_WITH_MULTIBYTECHARACTERS);
        assertTrue("Search page is not ready after performing a search.", searchPage.isReady());
        assertTrue("No assets are fetched for the search. Please modify the search key.", searchPage
                .getCounterAssets() > 0);

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add to created collection.
        saveInCollection.addToExistingCollection(name);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        collectionListAreaPage.sleep20();

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());

        // Verify whether there are atleast one asset saved in the collection to perform the test.
        assertTrue("Atleast one asset should be saved in the collection to perform the test.", collectionPage
                .getCounterAssets() > 0);

        // Search for a word with multi-byte characters.
        collectionPage.search(SEARCH_WORD_WITH_MULTIBYTECHARACTERS);
        assertTrue("Collection page is not ready after multi-byte characters search action.", collectionPage.isReady());
        assertTrue("Assets should be displayed for the given search multi-byte keyword. This is failing because there are no assets with Multi-byte character name are uplaoded.", !(collectionPage
                .getCounterAssets() == 0));

        // Change to List view and check.
        collectionPage.changeToListView();
        assertTrue("Verify assets in list view after multi-byte characters search action.", !collectionPage
                .isThumbsViewActive());

        // Search for a word with multi-byte characters.
        collectionPage.search(SEARCH_WORD_WITH_MULTIBYTECHARACTERS);
        assertTrue("Collection page is not ready after multi-byte characters search action.", collectionPage.isReady());
        assertTrue("Assets should be displayed for the given search multi-byte keyword. This is failing because there are no assets with Multi-byte character name are uplaoded.", !(collectionPage
                .getCounterAssets() == 0));

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the advance search panel in a collection:
     *
     * -# @see loginAux(). -# Navigate to created collection. -# Open the
     * AdvanceSearch component. -# Use the date filters. -# Check changes of
     * Date filter. -# Use Reset button. -# Use the Asset Type filter. -# Check
     * changes of AssetType filter. -# @see logoutAux().
     */
    @Test(description = "Check the advance search panel in a collection.", priority = 4)
    public void advanceSearchTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Open the AdvanceSearch component.
        AdvanceSearchPage advanceSearch = collectionPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());

        // Use the date filters.
        int prevCounterAssets = collectionPage.getCounterAssets();
        for (int index = 0; index < advanceSearch.getDateFilterSize(); index++) {
            advanceSearch.selectDateFilter(collectionPage.getContainerAssets(), index);
            // Check changes of Date filter.
            assertTrue("The previous counter of assets shouldn't be minor.", prevCounterAssets >= collectionPage
                    .getCounterAssets());
        }

        // Use Reset button.
        advanceSearch.clickOnResetButton(collectionPage.getContainerAssets());

        // Use the Asset Type filter
        for (int index = 0; index < advanceSearch.getAssetTypeFilterSize(); index++) {
            int counterAssetType = advanceSearch.selectAssetType(collectionPage.getContainerAssets(), index);
            // Check changes of AssetType filter.
            assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
            assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == collectionPage
                    .getCounterAssets());

            advanceSearch.removeAssetTypeFilter(collectionPage.getContainerAssets());
        }

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Sharing a collection to a user via valid and invalid email.:
     * 
     * -# @see loginAux() -# The user enters and log in the web. -# Navigate to
     * particular collection. -# Click on Share button. -# Write an invalid
     * email. -# Fill Email and Comment. -# Click on SendEmail and verify the
     * message. -# Write a valid email. -# Fill Email and Comment. -# Click on
     * SendEmail and verify the message. -# @see logoutAux()
     */
    @Test(description = "Creation of a collection and sharing with correct and incorrect email address.", priority = 5)
    public void createCollectionAndShareWithCorrectAndIncorrectEmail(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Click on Share button
        collectionPage.clickOnShareButton();
        // CreateCollectionPage createCollectionPage = new CreateCollectionPage(driver);
        assertTrue("SendEmail and Cancel buttons are not visible.", collectionPage.isSendEmailAndCancelButtonVisible());

        // Click on Cancel button and verify the dialog is closed
        collectionPage.clickOnCancleShareCollection();
        assertTrue("SendEmail and Cancel buttons are visible.", !collectionPage.isSendEmailAndCancelButtonNotVisible());

        // Click on Share button and verify the dialog is open
        collectionPage.clickOnShareButton();
        assertTrue("SendEmail and Cancel buttons are not visible.", collectionPage.isSendEmailAndCancelButtonVisible());

        // Fill invalid Email and ShareComment
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        collectionPage.fillShareCollectionEmail(UserDomain.INVALID, UserType.QA1);
        collectionPage.fillShareCollectionComment("SharedComment - " + df.format(now));

        // Asserting Email text area description for invaild email's
        assertTrue("Invalid email textarea description is not present", collectionPage.isErrorMessageForInavlidEmail());

        // Click on SendEmail
        collectionPage.clickOnSendEmail();
        assertTrue("Alert Message is NOT maching for Invalid email test.", collectionPage
                .isSharedEmailMessageInvalid(UserDomain.INVALID, UserType.QA1));

        // Fill Email and ShareComment
        /*
         * DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss"); Date now
         * = Calendar.getInstance().getTime();
         */
        collectionPage.fillShareCollectionEmail(UserDomain.LDAP_USER, UserType.QA1);
        collectionPage.fillShareCollectionComment("SharedComment - " + df.format(now));

        // Click on SendEmail
        collectionPage.clickOnSendEmail();
        assertTrue("Alert Message is NOT maching for vaid email test.", collectionPage
                .isSharedEmailMessageValid(UserDomain.LDAP_USER, UserType.QA1));

        // performing log out action.
        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Show actions available and verify Select All and deselect All.:
     *
     * -# @see loginAux() -# Navigate to a created collection -# Open the
     * actions area. -# Check the actions area is open. -# Verify select all and
     * unselect all. -# @see logoutAux()
     */
    @Test(description = "Show actions available and verify select all and deselect all options.", priority = 6)
    public void showActionsAvailableSelectAllUnselectAllTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Open the actions area.
        collectionPage.getActionArea().openActionsArea();
        // Check the actions area is open.
        assertTrue("The action area is collapsed.", collectionPage.getActionArea().isActionAreaOpen());

        // Click on 'Select all' button.
        collectionPage.getActionArea().clickOnSelectUnselectAll();
        // Check every asset shown is selected.
        assertTrue("Not every asset shown is selected.", collectionPage.getContainerAssets()
                .getCountOfSelected() == collectionPage.getNumberOfAssetsShown());

        // Click on 'Unselect all' button.
        collectionPage.getActionArea().clickOnSelectUnselectAll();
        // Check no assets shown are selected.
        assertTrue("There should not be any assets selected.", collectionPage.getContainerAssets()
                .getCountOfSelected() == 0);

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Change collection cover:
     *
     * -# @see loginAux() -# Navigage to collection area -# Navigate back to
     * collection list area. -# Get old cover of the created collection. -#
     * Enter in the created collection. -# Change the cover. -# Navigate back to
     * collection list area. -# Compare the cover have changed. -# @see
     * logoutAux()
     */
    @Test(description = "Change collection cover.", priority = 7)
    public void changeCollectionCoverTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();

        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        int numberOfAssetsShown = collectionPage.getNumberOfAssetsShown();

        // Navigate back to collection list area.
        collectionListAreaPage = collectionPage.goBack();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Get old cover of the created collection.
        String oldCover = collectionListAreaPage.getContainerCollections().getImageSrc(name);
        assertTrue("This cover has just the default image.", oldCover != null);

        // Enter in the created collection.
        collectionPage = collectionListAreaPage.getContainerCollections().navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Change the cover.
        collectionPage.getActionArea().changeCover(collectionPage.getNumberOfAssetsShown() - 5, collectionPage
                .getContainerAssets(), collectionPage);

        // Navigate back to collection list area.
        collectionListAreaPage = collectionPage.goBack();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Compare the cover have changed.
        if (numberOfAssetsShown > 1) {
            assertTrue("Collection cover page is same as old image.", !oldCover
                    .equalsIgnoreCase(collectionListAreaPage.getContainerCollections().getImageSrc(name)));
        } else {
            assertTrue("There are no assets in the collection.", oldCover
                    .equalsIgnoreCase(collectionListAreaPage.getContainerCollections().getImageSrc(name)));
        }

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Export selection to CSV and PDF formats from Action tab:
     *
     * -# @see loginAux() -# Navigate to created collection with assets -#
     * Select some assets. -# Navigate and click on the 'Export selection'
     * button in Action area. -# Check the export modal is shown. -# Click on
     * CSV button of one of the templates. -# Check the counter of Inbox's
     * messages has increased. -# Enter in the Inbox and check the last message
     * and close the Inbox. -# Again navigate and click on the 'Export
     * selection' button. -# Check the export modal is shown. -# Click on PDF
     * button of one of the templates. -# Check the counter of Inbox's messages
     * has increased. -# Enter in the Inbox and check the last message. -# @see
     * logoutAux()
     */
    @Test(description = "Export selection to CSV and PDF.", priority = 8)
    public void exportSelectionToCsvAndPdfTestWithAssets(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();

        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        int inboxCounter = collectionPage.getHeader().getInboxCounter();

        // Select some assets.
        collectionPage.getContainerAssets().selectRandomAssetsUsingCtrlKey(collectionPage);
        assertTrue("Test1/2: None asset shown is selected.", collectionPage.getContainerAssets()
                .getCountOfSelected() > 0);

        // Navigate and click on the 'Export selection' button.

        ExportPage exportModal = collectionPage.getActionArea().goToExportSelection(collectionPage
                .getCounterAssets(), collectionPage.getContainerAssets().getCountOfSelected());
        // Check the export modal is shown.
        assertTrue("Test1/2: Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());

        // Click on CSV button of one of the templates.
        exportModal.clickOnCSVButton(0);

        // Check the counter of Inbox's messages has increased.
        exportModal.sleep20(); // This wait is needed to leave time to receive
                               // the message.
        assertTrue("Test1/2: The inbox counter should have been increased.", collectionListAreaPage.getHeader()
                .getInboxCounter() == inboxCounter + 1);

        // Enter in the Inbox and check the last message.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("Test1/2: The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("Test1/2: The message is not the correct one.", inboxPage.isMessageOfExportFile(0));
        inboxPage.close();

        // Get the inbox counter after exporting in csv format.
        inboxCounter = collectionPage.getHeader().getInboxCounter();

        // Navigate and click on the 'Export selection' button in pdf format.
        exportModal = collectionPage.getActionArea().goToExportSelection(collectionPage
                .getCounterAssets(), collectionPage.getContainerAssets().getCountOfSelected());
        // Check the export modal is shown.

        assertTrue("Test2/2: Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());

        // Click on PDF button of one of the templates.
        exportModal.clickOnPDFButton(0);

        // Check the counter of Inbox's messages has increased.
        exportModal.sleep20(); // This wait is needed to leave time to receive
                               // the message.
        assertTrue("Test2/2: The inbox counter should have been increased.", collectionListAreaPage.getHeader()
                .getInboxCounter() == inboxCounter + 1);
        // Enter in the Inbox and check the last message.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("The message is not the correct one.", inboxPage.isMessageOfExportFile(0));
        inboxPage.close();

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Export without selecing any assets from Action tab:
     *
     * -# @see loginAux() 
     * -# Navigate to created collection with assets
     * -# Click on Export button without selecting any assets. 
     * -# Verify the error dialog. 
     * -# @see logoutAux()
     * 
     */
    @Test(description = "Export without selecing any assets.", priority = 9)
    public void exportSelectionWithoutAssetsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();

        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Open action area again and unselect the selected asset.
        collectionPage.getActionArea().openActionsArea();

        // Unselect all selected assets.

        collectionPage.getContainerAssets().unselectAllSelectedAssetsUsingCtrlKey(collectionPage);
        assertTrue("None of the assets should be selectd.", collectionPage.getContainerAssets()
                .getCountOfSelected() == 0);
        assertTrue("Action are should be opened.", collectionPage.getActionArea().isActionAreaOpen());

        // Navigate and click on the 'Export selection' button in pdf format.
        collectionPage.getActionArea().goToExportSelection(collectionPage.getCounterAssets(), collectionPage
                .getContainerAssets().getCountOfSelected());

        // Check the warning dialog is shown.
        assertTrue("Error dialog saying no assets selected should be displayed.", collectionPage
                .isExportErrorDialogPresent());
        collectionPage.clickOkbtnOnExportDialog();
        assertTrue("Error dialog saying no assets selected is present even after accepting it.", !collectionPage
                .isExportErrorDialogPresent());

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * View download standalone modal in a collection, check and download
     * asset.:
     *
     * -# @see loginAux() -# Navigate to created collection. -# Navigate to the
     * SingleDownload modal. -# Check the SingleDownload modal. -# Verify error
     * by downloading without accpeting DRM. -# Verify download by accpeting
     * DRM. -# Close the SingleDownload modal. -# @see logoutAux()
     */
    @Test(description = "View download standalone modal in a collection and verify download asset.", priority = 10)
    public void viewDownloadStandaloneTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();

        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Navigate to the SingleDownload modal.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        SingleDownloadPage singleDownload = containerAssets
                .goToSingleDownloadOfTheAsset(containerAssets.getRandomIndexOfAssetsShown());

        // Check the SingleDownload modal.
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Click on Download button without accepting DRM.
        singleDownload.clickOnDownloadButton();
        assertTrue("Test 1/3: The error message should be shown.", singleDownload.isErrorMessageShown());

        // Accept the DRM.
        singleDownload.acceptDRM();
        // Click on Download button.
        singleDownload.clickOnDownloadButton();
        assertTrue("Test 2/3: The after download message and the link should be shown.", singleDownload
                .isAfterDownloadMessageAndLinkShown());

        // Click on the download link.
        singleDownload.clickOnDownloadLink();

        // Close the SingleDownload modal.
        singleDownload.close();

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Download of multiples assets, in a collection:
     *
     * -# @see loginAux(). -# Navigate to created collection. -# Using Ctrl key
     * select different assets. -# Navigate to the MultiDownload modal. -#
     * Accept the DRM. -# Click on Download button. -# @see logoutAux().
     */
    @Test(description = "Download of multiples assets, in a collection.", priority = 11)
    public void multiDownloadTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // get inbox counter before download
        int inboxCounterBefore = collectionPage.getHeader().getInboxCounter();

        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        assertTrue("The number of assets  should be more than one in the collection but there are - "
                + collectionPage.getNumberOfAssetsShown()
                + " asset only.", collectionPage.getNumberOfAssetsShown() > 1);

        // Using Ctrl key select different assets.
        int numberOfSelected = containerAssets.selectRandomAssetsUsingCtrlKey(collectionPage);
        assertTrue("Should be " + numberOfSelected + " selected assets but there are "
                + containerAssets.getCountOfSelected() + ".", containerAssets.getCountOfSelected() == numberOfSelected);

        // Navigate to the MultiDownload modal.
        MultiDownloadPage multiDownload = collectionPage.getActionArea()
                .goToMultiDownloadOfTheAssets(containerAssets.getCountOfSelected());
        assertTrue("MultiDownload modal is not ready.", multiDownload.isReady());

        // Accept the DRM.
        multiDownload.acceptDRM();
        // Click on Download button.
        multiDownload.clickOnDownloadButton();
        assertTrue("The after download message should be shown.", multiDownload.isAfterDownloadMessageShown());

        // Close the MultiDownload modal.
        multiDownload.close();

        // Wait and verify whether the Inbox counter got increased or not.
        multiDownload.sleep20andRefresh();
        assertTrue("There should be a  new notification in inbox after multi-download. Old counter : "
                + inboxCounterBefore + "New counter should be one more than before but it is : "
                + collectionPage.getHeader()
                        .getInboxCounter(), collectionPage.getHeader().getInboxCounter() == inboxCounterBefore + 1);

        // Open inbox modal and verify the message.
        InboxPage inboxPage = collectionPage.getHeader().clickOnInboxButton();
        assertTrue("The messages should be unread.", !inboxPage.isMessageRead(0));
        assertTrue("The Message should be related to downlaod", inboxPage.isMessageforDownload(0));

        inboxPage.close();

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Export a collection to CSV and PDF:
     *
     * -# {@see loginAux()}. -# Navigate to created collection -# Navigate to
     * the export modal. -# Check the export modal is shown. -# Click on CSV
     * button of one of the templates. -# Check the counter of Inbox's messages
     * has increased. -# Enter in the Inbox and check the last message. -#
     * Navigate to the export modal again. -# Check the export modal is shown.
     * =# Click on PDF button of one of the templates. -# Check the counter of
     * Inbox's messages has increased. -# Enter in the Inbox and check the last
     * message. -# @see logoutAux()
     */
    @Test(description = "Export a collection to CSV and PDF", priority = 12)
    public void exportAllToCsvAndPdfTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());
        // name = "27gdrive";

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        int inboxCounter = collectionPage.getHeader().getInboxCounter();

        // Navigate to the export modal.
        ExportPage exportModal = collectionPage.goToExport();
        // Check the export modal is shown.
        assertTrue("Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());

        // Click on CSV button of one of the templates.
        exportModal.clickOnCSVButton(0);

        // Check the counter of Inbox's messages has increased.
        exportModal.sleep20(); // This wait is needed to leave time to receive
                               // the message.
        assertTrue("The inbox counter should have been increased.", collectionListAreaPage.getHeader()
                .getInboxCounter() == inboxCounter + 1);
        // Enter in the Inbox and check the last message.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("The message is not the correct one.", inboxPage.isMessageOfExportFile(0));
        inboxPage.close();

        inboxCounter = collectionPage.getHeader().getInboxCounter();

        // Navigate to the export modal.
        exportModal = collectionPage.goToExport();
        // Check the export modal is shown.
        assertTrue("Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());

        // Click on CSV button of one of the templates.
        exportModal.clickOnPDFButton(0);

        // Check the counter of Inbox's messages has increased.
        exportModal.sleep20(); // This wait is needed to leave time to receive
                               // the message.
        assertTrue("The inbox counter should have been increased.", collectionListAreaPage.getHeader()
                .getInboxCounter() == inboxCounter + 1);
        // Enter in the Inbox and check the last message.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("The message is not the correct one.", inboxPage.isMessageOfExportFile(0));
        inboxPage.close();

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Export a collection to CSV and PDF when there are no assets in the
     * collection.:
     *
     * -# {@see loginAux()}. -# @see createSimpleCollectionAux. -# Click on
     * Export button and verify the alert. -# @see logoutAux()
     */
    @Test(description = "Export an empty collection to CSV and PDF", priority = 13)
    public void exportAllToCsvAndPdfEmptyCollTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Create collection by giving shared user and Collection Owner.
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        String collName = collectionPage.getTitle();

        // Navigate to the export modal.
        ExportPage exportModal = collectionPage.goToExport();

        // Check the warning dialog is shown.
        assertTrue("Error dialog saying no assets selected should be displayed.", collectionPage
                .isExportErrorDialogPresent());

        collectionPage.clickOkbtnOnExportDialog();
        assertTrue("Error dialog saying no assets selected is present even after accepting it.", !collectionPage
                .isExportErrorDialogPresent());

        // Delete the created collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), collName);

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Multiselect and delete assets using Shift key.:
     *
     * -# @see loginAux(). 
     * -# Navigate to an existing collection with assets. 
     * -# Using Shift key select different assets. 
     * -# Check if the assets are deleted in the collection. 
     * -# @see logoutAux().
     */
    @Test(description = "Delete the selected assets.", priority = 14)
    public void deletingTheSelectedAssetsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Veriyf there are atleast two assets for selection.
        assertTrue("Atleast 2 assets should be present to performing selection of assets using Shift key", collectionPage
                .getCounterAssets() > 2);

        // selected assets.
        // Using Ctrl key select different assets.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        List<String> assetsIDs = containerAssets.getAssetIDsOfAssetsShown();
        int numberOfSelected1 = containerAssets.selectRandomAssetsUsingCtrlKeyInCollections(collectionPage);

        // Click on delete button.
        collectionPage.deleteSelectedAssets();

        GDriveCollectionPage gdriveCollectionPage = new GDriveCollectionPage(DriverManager.getDriver());
        assertTrue("the Sync icon is  not shown", gdriveCollectionPage.isSyncIconShown());
        collectionPage.sleep20andRefresh();
        collectionListAreaPage.rechargeContainerCollections();

        // Navigate to the created collection.
        containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Number assets present in collection after deletion should be less than original .", !containerAssets
                .compareLists(containerAssets.getAssetIDsOfAssetsShown(), assetsIDs));

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Multiselect and delete assets using Shift Key.:
     *
     * -# @see loginAux(). 
     * -# Navigate to an existing collection with assets. 
     * -# Using Ctrl key select different assets. 
     * -# Click on delete button. 
     * -# Using Shift key select different assets.
     * -# Check if the assets are deleted in the collection. 
     * -# @see logoutAux().
     */
    @Test(description = "Multiselect and delete assets using Shift Key.", priority = 29)
    public void MultiselectAssetsWithShiftKeyTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Test1: Verifying multi-select using shift key.
        // Veriyf there are atleast two assets for selection.
        assertTrue("Atleast 2 assets should be present to performing selection of assets using Shift key", collectionPage
                .getCounterAssets() > 2);

        // Using Shift key select different assets.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        int numberOfSelected = containerAssets.selectAssetsUsingShiftKey(collectionPage, 1, 2);
        // Check selected assets.
        assertTrue("Should be " + numberOfSelected + " selected assets but there are "
                + containerAssets.getCountOfSelected() + ".", containerAssets.getCountOfSelected() == numberOfSelected);

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the charge of more assets in a collection:
     *
     * -# @see loginAux() -# Navigate to created collection. -# Scroll bottom to
     * charge more assets. -# Check quantity of assets shown. -# Change to List
     * view. -# Scroll bottom to charge more assets. -# Check quantity of assets
     * shown. -# @see logoutAux()
     */
    @Test(description = "Check the charge of more assets in a collection.", priority = 15)
    public void chargeMoreAssetsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Search for a word with expected result.
        searchPage.search(SEARCH_WORD_1);
        assertTrue("Search page is not ready after performing a search.", searchPage.isReady());

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add to created collection.
        saveInCollection.addToExistingCollection(name);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        collectionListAreaPage.sleep20();

        // Navigate to the created collection.
        containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());
        int numberOfAssetsShownBefore = collectionPage.getNumberOfAssetsShown();
        // wait until all the
        collectionPage.waitUntil28AssetsLoad(name);

        // Check if the assets are saved in the collection.
        assertTrue("A minimum of 27 assets should be present to get the 'Items left' icon. But only - "
                + collectionPage.getCounterAssets() + "assets are present", collectionPage.getCounterAssets() > 27);

        // Scroll bottom to charge more assets.
        collectionPage.scrollToChargeMoreAssets();
        // Check quantity of assets shown.
        assertTrue("The number of assets shown has not increased.", numberOfAssetsShownBefore < collectionPage
                .getNumberOfAssetsShown());

        // Change to List view.
        collectionPage.changeToListView();
        assertTrue("List view is not active.", !collectionPage.isThumbsViewActive());

        numberOfAssetsShownBefore = collectionPage.getNumberOfAssetsShown();
        // Scroll bottom to charge more assets.
        collectionPage.scrollToChargeMoreAssets();
        // Check quantity of assets shown.
        assertTrue("The number of assets shown has not increased.", numberOfAssetsShownBefore < collectionPage
                .getNumberOfAssetsShown());

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Edition of a collection by changing Name and adding a collection owner
     * and Shared user.:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Navigate to
     * collection info modal. -# Navigate to edit collection modal. -# Change
     * the collection name -# Add collection Owner and shared user. -# Save the
     * collection details and verify the new name. -# @see logoutAndLoginAux()
     * with Collectio Owner user. -# Navigate to the Collection List Area. -#
     * Check if the Collection owner have the collection in My Collection tab.
     * -# @see logoutAndLoginAux() with Shared user. -# Navigate to the
     * Collection List Area. -# Check if the Shared User have the collection in
     * Shared tab. -# @see logoutAux().
     */
    @Test(description = "Editing a collection by changing Name and adding a collection owner and Shared user.", priority = 17)
    public void editCollectionNameTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Create collection by giving shared user and Collection Owner.
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");
        assertTrue("Collection page is not ready.", collectionPage.isReady());
        String collName = collectionPage.getTitle();

        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Navigate to collection info modal.
        CollectionInfoPage infoModal = collectionPage.goToInfo();
        assertTrue("Collection Info modal is not ready.", infoModal.isReady());

        // Navigate to edit collection modal.
        EditionCollectionPage editPage = infoModal.goToEditModal();
        assertTrue("Edit collection modal is not ready.", editPage.isReady());

        // Editing collection information.
        String editedCollName = "Edited - " + collName;
        collectionPage = editPage.editCollInfo(collectionPage, editedCollName);

        // Validate collection page is ready.
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Validate the edited name.
        assertTrue("The name of the collection should be changed to new name - " + editedCollName
                + " but it still has the old name - " + collName
                + ".", collectionPage.getCollectionName().equals(editedCollName));

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), editedCollName);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Edition of a collection by changing Expiration date.:
     *
     * -# @see loginAux(). -# Navigate to the created colleciton. -# Navigate to
     * collection info modal. -# Navigate to edit collection modal. -# Change
     * the expiry date -# Save the collection details and verify the new date.
     * -# @see logoutAux().
     */
    @Test(description = "Edition of a collection by changing Expiration date.", priority = 18)
    public void editExpiryDateTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Create a collection.
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");
        assertTrue("Collection page is not ready.", collectionPage.isReady());
        String collName = collectionPage.getTitle();

        // Navigate to collection info modal.
        CollectionInfoPage infoModal = collectionPage.goToInfo();
        assertTrue("Collection Info modal is not ready.", infoModal.isReady());

        String beforeExpirydate = infoModal.getExpiryDate();
        Reporter.log("Before Expiry date--->" + beforeExpirydate);

        // Navigate to edit collection modal.
        EditionCollectionPage editPage = infoModal.goToEditModal();
        assertTrue("Edit collection modal is not ready.", editPage.isReady());

        // Editing collection information.
        collectionPage = editPage.editCollInfo(collectionPage, collName);

        // Validate collection page is ready.
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Verify the edited Expiry date.
        // Navigate to collection info modal.
        infoModal = collectionPage.goToInfo();
        assertTrue("Collection Info modal is not ready.", infoModal.isReady());

        String afterExpiryDate = infoModal.getExpiryDate();
        Reporter.log("After Expiry date--->" + afterExpiryDate);

        assertTrue("The new date should be different from the old date.", !beforeExpirydate.equals(afterExpiryDate));

        infoModal.close();

        // Delete the created collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), collName);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * User tries to create a new collection without assets and edit it by
     * adding a shared user and a collection owner and verify.
     * 
     * -# @see loginAux() with admin. -# @see createSimpleCollectionAux. -# Edit
     * the collection and add collection owner and Shared user. -# @see
     * logoutAndLoginAux() with Collection Owner user. -# Navigate to the
     * Collection List Area. -# Check if the Collection owner have the
     * collection in My Collection tab. -# @see logoutAndLoginAux() with Shared
     * user. -# Navigate to the Collection List Area. -# Check if the Shared
     * User have the collection in Shared tab. -# @see logoutAux(). -# @author
     * Sowjanya Lankadasu <slankada@opentext.com>.
     */
    @Test(description = "The user tries to create a new collection without assets and edit it by adding a shared user and a collection owner.", priority = 19)
    public void editCollectionByAddingOwnerAndUserTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Login to the application
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection by giving shared user and Collection Owner.
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");

        // Save name collection.
        String collName = collectionPage.getTitle();

        // Navigate to collection info modal.
        CollectionInfoPage infoModal = collectionPage.goToInfo();
        assertTrue("Collection Info modal is not ready.", infoModal.isReady());

        // Navigate to edit collection modal.
        EditionCollectionPage editPage = infoModal.goToEditModal();
        assertTrue("Edit collection modal is not ready.", editPage.isReady());

        // Editing collection information.
        collectionPage = editPage.editCollInfo(collectionPage, collName);

        // log out and login again with Collection owner user.
        searchPage = logoutAndLoginAux(UserDomain.COLLECTIONOWNER, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready in collection owner login.", collectionListAreaPage
                .isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(collName);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // log out and login again with Shared user.
        searchPage = logoutAndLoginAux(UserDomain.SHAREDUSER, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready in shared user login.", collectionListAreaPage.isReady());

        // Switch to Shared tab.
        collectionListAreaPage.clickOnShareButton();

        // Navigate to the created collection in Shared tab.
        ContainerCollectionsPage containerCollectionsShr = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollectionsShr.navigateToCollection(collName);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // log out and login again with Shared user.
        searchPage = logoutAndLoginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Delete the created collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), collName);

        // Logout from shared user
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * View the assets details in a collection:
     *
     * -# @see loginAux() -# @see createSimpleCollectionAux(); -# Navigate to
     * search page. -# Perform an advance search for just images. -# Save the
     * results in the created collection. -# Navigate to the collection. -#
     * Perform an advance search for just images. -# Click on any asset to see
     * the asset details. -# Check the asset details modal. -# Close the asset
     * details modal. -# Change to List view. -# Click on any asset's view
     * button to see the asset details. -# Check the asset details modal. -#
     * Close the asset details modal. -# @see deleteCollectionAux() -# @see
     * logoutAux()
     */
    @Test(description = "View the assets details in a collection.", priority = 20)
    public void assetDetailsViewOfAnImageTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create a Gdrive collection.
        collectionPage = this.createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");
        String collName = collectionPage.getTitle();

        // Navigate to the serch page
        searchPage = collectionPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready to work.", searchPage.isReady());

        // Perform an advance search for just images.
        AdvanceSearchPage advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        int counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "png");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());

        /*
         * // Getting assets IDs to compare later. ContainerAssetsPage
         * containerAssets = searchPage.getContainerAssets(); List<String>
         * assetsIDs = containerAssets.getAssetIDsOfAssetsShown();
         */
        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add to created collection.
        saveInCollection.addToExistingCollection(collName);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        collectionListAreaPage.sleep20();

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(collName);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());

        // Verify whether there are atleast one asset saved in the collection to
        // perform the test.
        assertTrue("Atleast one asset should be saved in the collection to perform the test.", collectionPage
                .getCounterAssets() > 0);

        // Perform an advance search for just images.
        advanceSearch = collectionPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        counterAssetType = advanceSearch.selectAssetType(collectionPage.getContainerAssets(), "png");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        // assertTrue("The counter of assets of the AssetType was wrong.",
        // collectionPage.getCounterAssets() > 0);

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.IMAGE);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // Change to List view.
        collectionPage.changeToListView();
        assertTrue("List view is not active.", !collectionPage.isThumbsViewActive());

        // Click on any asset's view button to see the asset details.
        assetDetails = containerAssets.goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.IMAGE);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // collectionListAreaPage =
        // deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * View the assets details of a document:
     *
     * -# @see loginAux() -# @see createSimpleCollectionAux(); -# Navigate to
     * search page. -# Perform an advance search for just documents. -# Save
     * results in the above created collection. -# Perform an advance search for
     * just documents. -# Click on any asset to see the asset details. -# Check
     * the asset details modal. -# Close the asset details modal. -# Change to
     * List view. -# Click on any asset's view button to see the asset details.
     * -# Check the asset details modal. -# Change pages using arrows. -# Close
     * the asset details modal. -# @see deleteCollectionAux() -# @see
     * logoutAux()
     */
    @Test(description = "View the assets details of a document.", priority = 21)
    public void assetDetailsViewOfADocumentTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create a Gdrive collection.
        collectionPage = this.createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");
        String collName = collectionPage.getTitle();

        // Navigate to the search page
        searchPage = collectionPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready to work.", searchPage.isReady());

        // Perform an advance search for just documents.
        AdvanceSearchPage advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        int counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "pdf");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add to created collection.
        saveInCollection.addToExistingCollection(collName);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        collectionListAreaPage.sleep20();

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(collName);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());

        // Verify whether there are atleast one asset saved in the collection to
        // perform the test.
        assertTrue("Atleast one asset should be saved in the collection to perform the test.", collectionPage
                .getCounterAssets() > 0);

        // Perform an advance search for just documents.
        advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "pdf");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.DOCUMENT);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // Change to List view.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        // Click on any asset's view button to see the asset details.
        assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.DOCUMENT);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Change pages using arrows.
        for (int i = 1; i < 5; i++) {
            String oldSrc = assetDetails.getCurrentSrc();
            int oldPage = assetDetails.getCurrentPage();
            assetDetails.goToNextPage();
            if (assetDetails.getNumberOfPages() > 1) {
                assertTrue("The page has not changed.", !oldSrc.equalsIgnoreCase(assetDetails.getCurrentSrc()));
                assertTrue("The page has not changed.", oldPage != assetDetails.getCurrentPage());
            } else {
                assertTrue("The page should be the same.", oldSrc.equalsIgnoreCase(assetDetails.getCurrentSrc()));
                assertTrue("The page has not changed.", oldPage == assetDetails.getCurrentPage());
            }
        }

        // Close the asset details modal.
        assetDetails.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), collName);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * View the assets details of a video:
     *
     * -# @see loginAux() -# Perform an advance search for just documents. -#
     * {@see createCollectionWithAssetsAux()}. -# Perform an advance search for
     * just documents. -# Click on any asset to see the asset details. -# Check
     * the asset details modal. -# Click play a video -# Close the asset details
     * modal. -# Change to List view. -# Click on any asset's view button to see
     * the asset details. -# Check the asset details modal. -# Click play a
     * video -# Close the asset details modal. -# @see deleteCollectionAux()
     * -# @see logoutAux()
     */
    @Test(description = "View the assets details of a video.", priority = 22)
    public void assetDetailsViewOfAVideoTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create a Gdrive collection.
        collectionPage = this.createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");
        String collName = collectionPage.getTitle();

        // Navigate to the search page
        searchPage = collectionPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready to work.", searchPage.isReady());

        // Perform an advance search for just documents.
        AdvanceSearchPage advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        int counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "MULTIMEDIAFILE");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add to created collection.
        saveInCollection.addToExistingCollection(collName);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        collectionListAreaPage.sleep20();

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(collName);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());

        // Verify whether there are atleast one asset saved in the collection to
        // perform the test.
        assertTrue("Atleast one asset should be saved in the collection to perform the test.", collectionPage
                .getCounterAssets() > 0);

        // Perform an advance search for just documents.
        advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "MULTIMEDIAFILE");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.VIDEO);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Click play a video
        assetDetails.goPlayVideo();

        // Close the asset details modal.
        assetDetails.close();

        // Change to List view.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        // Click on any asset's view button to see the asset details.
        assetDetails = containerAssets.goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.VIDEO);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Click play a video
        assetDetails.goPlayVideo();

        // Close the asset details modal.
        assetDetails.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), collName);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Perform the download from the asset details in a collection:
     *
     * -# @see loginAux() -# Navigate to the created collection. -# Click on any
     * asset to see the asset details. -# Expand the Download complement. -#
     * Accept the DRM. -# Click on Download button. -# Collapse the Download
     * complement. -# Close the asset details modal. -# @see logoutAux()
     */
    @Test(description = "Perform the download from the asset details in a collection.", priority = 23)
    public void downloadFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());

        // Verify whether there are atleast one asset saved in the collection to
        // perform the test.
        assertTrue("Atleast one asset should be saved in the collection to perform the test.", collectionPage
                .getCounterAssets() > 0);

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the Download complement.
        AssetDetailsDownloadPage downloadComplement = AssetDetailsPage.getDownloadComplement();
        downloadComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Accept the DRM.
        downloadComplement.acceptDRM();

        // Click on Download button.
        downloadComplement.clickOnDownloadButton();
        assertTrue("The after download message and the link should be shown.", downloadComplement
                .isAfterDownloadMessageAndLinkShown());

        // Collapse the Download complement.
        downloadComplement.close();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // collectionListAreaPage =
        // deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Note: This test case will fail until Defect :MB-15060 is fixed. Perform
     * the 'Saving result in an existing collection.' from the asset details in
     * a collection:
     *
     * -# @see loginAux() 
     * -# @see createSimpleCollectionAux()
     * -# @see createSimpleCollectionAux()
     * -# Search and save few assets in the second collection.
     * -# Navigate to the Collection List Area. 
     * -# Navigate to the created collection.
     * -# Click on any asset to see the asset details ans save the Index. 
     * -# Expand the SaveInCollection complement. 
     * -# Add the asset to the first created collection. 
     * -# Close the asset details modal.
     * -# Navigate to the Collection List Area.
     * -# Navigate to the first created collection.
     * -# Check if the assets are saved in the collection. 
     * -# @see deleteAssetOfCollection
     * -# Check if the assets are removed from the collection.
     * -# @see deleteCollectionAux
     * -# @see logoutAux()
     */
    @Test(description = "Perform the 'Saving result in an existing collection.' and removing assets from the asset details in a collection.", priority = 24)
    public void saveInExistingCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection simple
        collectionPage = this.createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");

        // Save name collection
        String name = collectionPage.getTitle();
        int oldCounterCollection = collectionPage.getHeader().getCollectionCounter();

        // Create collection with assets
        collectionPage = this.createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");
        String name1 = collectionPage.getTitle();

        // Navigate to the search page
        searchPage = collectionPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready to work.", searchPage.isReady());

        // Perform a keyword search
        searchPage.search(SEARCH_WORD_2);
        assertTrue("Search page is not ready after performing a search.", searchPage.isReady());

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add to created collection.
        saveInCollection.addToExistingCollection(name1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        collectionListAreaPage.sleep20();

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name1);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());

        // Verify whether there are atleast one asset saved in the collection to perform the test.
        assertTrue("Atleast one asset should be saved in the collection to perform the test.", collectionPage
                .getCounterAssets() > 0);

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();

        int index = containerAssets.getRandomIndexOfAssetsShown();
        // String assetsIDs = containerAssets.getAssetIDsOfAsset(index);
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(containerAssets.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Select the checkbox of the existing collections to save in.
        saveInCollectionComplement.addToExistingCollection(name);

        // Collapse the SaveInCollection complement (not necessary).
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        searchPage.sleep20andRefresh();
        // assertTrue("The counter of collections hasn't been increased.", oldCounterCollection + 1 == searchPage
        // .getHeader().getCollectionCounter());

        /*// Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        */
        // Navigate to the created collection.
        containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());
        /*
        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));
        */
        // Click on any asset to see the asset details.
        containerAssets = collectionPage.getContainerAssets();

        assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();

        // Check the save asset is in the collection
        assertTrue("Collection hasn't been found.", saveInCollectionComplement
                .checkCollectionIsSavingThisAsset(name) != null);

        // Delete an asset from a collection
        saveInCollectionComplement.deleteAssetOfCollection(collectionPage.getContainerAssets(), name);

        // Close the asset details modal.
        assetDetails.close();

        // Check if the assets are saved or deleted are in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));

        // Delete the created collections
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name1);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Perform the 'save in a new collection' from the asset details in a Album and Persoanl collection:
     *
     * -# @see loginAux().
     * -# Navigate to the created collection.
     * -# Click on any asset to see the asset details. 
     * -# Expand the SaveInCollection complement.
     * -# Enter new collection name, and collection type as Album and Personal and save. 
     * -# Close the asset details modal. 
     * -# Navigate to the Collection List Area.
     * -# Navigate to the created collection. 
     * -# Check if the assets are saved in the collection.
     * -# @see deleteCollectionAux().
     * -# @see logoutAux().
     */
    @Test(description = "Perform the 'save in a new collection' from the asset details in a  Album and Persoanl collection.", priority = 25)
    public void saveInNewCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // int oldCounterCollection = collectionPage.getHeader().getCollectionCounter();

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();

        int index = containerAssets.getRandomIndexOfAssetsShown();
        // String assetsIDs = containerAssets.getAssetIDsOfAsset(index);
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(containerAssets.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready while clicking on an asset.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        assertTrue("AssetDetails modal is not ready while expanding the SaveInCollection complement.", assetDetails
                .isReady());

        // Add a new collection.
        String name1 = "Album Collection - " + new Date().getTime();
        String name2 = "Personal Collection - " + new Date().getTime();

        saveInCollectionComplement.addToNewCollection(name2, "Personal");

        // Expand the SaveInCollection complement.
        // saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        assertTrue("AssetDetails modal is not readywhile expanding the SaveInCollection complement.", assetDetails
                .isReady());

        saveInCollectionComplement.addToNewCollection(name1, "Albums");

        // Collapse the SaveInCollection complement (not necessary).
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        searchPage.sleep20andRefresh();

        // assertTrue("The counter of collections hasn't been increased.",
        // oldCounterCollection + 1 == searchPage
        // .getHeader().getCollectionCounter());

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created Album collection.
        containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name1);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created Personal collection.
        containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name2);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));

        // Delete the created collections
        collectionListAreaPage = deleteCollectionAux(collectionListAreaPage.getHeader(), name1);
        collectionListAreaPage = deleteCollectionAux(collectionListAreaPage.getHeader(), name2);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Search for a metadata value.:
     *
     * -# {@see loginAux()}. 
     * -# Navigated to the created collection. 
     * -# Navigate to the export modal. -# Check the export modal is not shown. 
     * -# {@see logoutAux()}.
     */
    @Test(description = "Search for a metadata value.", priority = 26)
    public void searchForMetadataValueFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        if (name == null) {
            collectionPage = createSimpleCollectionAux(collectionListAreaPage.getHeader(), "Gdrive");
            name = collectionPage.getTitle();
            collectionPage.addAssetstoCreatedCollection(name);
        } else {
            collectionPage = containerCollections.navigateToCollection(name);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();

        int index = containerAssets.getRandomIndexOfAssetsShown();
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(containerAssets.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the Metadata complement.
        AssetDetailsMetadatasPage metadataComplement = AssetDetailsPage.getMetadataComplement();

        // Expand the group of metadatas.
        metadataComplement.openGroup();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Perform a search in the metadata input.
        String textToSearch = "a";
        int counter = metadataComplement.numberOfMetadatasValuesShown();
        metadataComplement.search(textToSearch);

        // Check the text is found in the metadatas values.
        assertTrue("Should have less metadatas shown.", counter >= metadataComplement.numberOfMetadatasValuesShown());
        assertTrue("The visible values don't contain the searched text.", metadataComplement
                .isContainedInEveryValueShown(textToSearch));

        // Collapse the Metadata complement.
        metadataComplement.closeGroup();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // Delete the created collection
        // collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());

    }

    /**
     * User tries to share a new collection without assets.
     * 
     *  -# @see loginAux() with admin.
     *  -# @see createCollectionWithOwnerSharedUsersAux(), create a collection by giving owner and shared user.
     *  -# @see logoutAndLoginAux() with Collection Owner user. 
     *  -# Navigate to the Collection List Area. 
     *  -# Check if the Collection owner have the collection in My Collection tab.
     * -# @see logoutAndLoginAux() with Shared user. 
     * -# Navigate to the Collection List Area. 
     * -# Check if the Shared User have the collection in Shared tab.
     * -# @see logoutAux(). 
     * 
     * -# @author Sowjanya Lankadasu <slankada@opentext.com>.
     */
    @Test(description = "The user tries to share a new collection without assets with a shared user and with collection owner.", priority = 27)
    public void userSharesCollectionWithSharedUserAndOwnerTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Login to the application
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection by giving shared user and Collection Owner.
        collectionPage = createCollectionWithOwnerSharedUsersAux(searchPage.getHeader(), "Gdrive");

        // Save name collection.
        String name = collectionPage.getTitle();
        System.out.println("Name of the collection created is " + name);

        // log out and login again with Collection owner user.
        searchPage = logoutAndLoginAux(UserDomain.COLLECTIONOWNER, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // log out and login again with Shared user.
        searchPage = logoutAndLoginAux(UserDomain.SHAREDUSER, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Switch to Shared tab.
        collectionListAreaPage.clickOnShareButton();

        // Navigate to the created collection in Shared tab.
        ContainerCollectionsPage containerCollectionsShr = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollectionsShr.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Logout from shared user
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * User tries to share a new collection with assets and edit collection by adding shared user and collection user and verify. 
     * 
     * -# @see loginAux() with superuser.
     * -# @see createCollectionWithOwnerSharedUsersAux(), create a collection by giving owner and shared user.
     * -# Add assets to the collection.
     * -# @see logoutAndLoginAux() with Collectio Owner user. 
     * -# Navigate to the Collection List Area. 
     * -# Check if the Collection owner have the collection in My Collection tab.
     * -# @see logoutAndLoginAux() with Shared user. 
     * -# Navigate to the Collection List Area.
     * -# Check if the Shared User have the collection in Shared tab.
     * -# @see logoutAux(). 
     * 
     * -# @author Sowjanya Lankadasu <slankada@opentext.com>.
     */
    @Test(description = "The user tries to share a new collection with a shared user and with another owner user.", priority = 28)
    public void userSharesCollectionWithSharedUserAndOwnerWithAssetsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName()
                + " - Start test method: userSharesCollectionWithSharedUserAndOwnerWithAssetsTest");

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection simple
        collectionPage = this.createCollectionWithOwnerSharedUsersAux(searchPage.getHeader(), "Gdrive");

        // Save name collection
        String name = collectionPage.getTitle();
        // int oldCounterCollection = collectionPage.getHeader().getCollectionCounter();

        // Navigate to the search page
        searchPage = collectionPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready to work.", searchPage.isReady());

        // Perform a keyword search
        searchPage.search(SEARCH_WORD_2);
        assertTrue("Search page is not ready after performing a search.", searchPage.isReady());

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add to created collection.
        saveInCollection.addToExistingCollection(name);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        collectionListAreaPage.sleep20();

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());

        // Verify whether there are atleast one asset saved in the collection to perform the test.
        assertTrue("Atleast one asset should be saved in the collection to perform the test.", collectionPage
                .getCounterAssets() > 0);

        // log out and login again with Collection owner user.
        searchPage = logoutAndLoginAux(UserDomain.COLLECTIONOWNER, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollection = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollection.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // log out and login again with Shared user.
        searchPage = logoutAndLoginAux(UserDomain.SHAREDUSER, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Switch to Shared tab.
        collectionListAreaPage.clickOnShareButton();

        // Navigate to the created collection in Shared tab.
        ContainerCollectionsPage containerCollectionsShr = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollectionsShr.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Logout from shared user
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName()
                + " - End test method: userSharesCollectionWithSharedUserAndOwnerWithAssetsTest");
    }

}
