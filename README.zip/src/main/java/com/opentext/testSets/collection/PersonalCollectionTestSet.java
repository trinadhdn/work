/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.collection;

import static org.testng.AssertJUnit.assertTrue;

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.pageObjects.advanceSearch.AdvanceSearchPage;
import com.opentext.pageObjects.assetDetails.AssetDetailsPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsDownloadPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsMetadatasPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsSaveInCollectionPage;
import com.opentext.pageObjects.collectionInfo.CollectionInfoPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.containerCollections.ContainerCollectionsPage;
import com.opentext.pageObjects.createAndEditionCollection.specific.CreateCollectionPage;
import com.opentext.pageObjects.createAndEditionCollection.specific.EditionCollectionPage;
import com.opentext.pageObjects.export.ExportPage;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.pageObjects.saveInCollection.SaveInCollectionPage;
import com.opentext.pageObjects.singleDownload.specificModal.MultiDownloadPage;
import com.opentext.pageObjects.singleDownload.specificModal.SingleDownloadPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.AssetCategoryValues.AssetType;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain the tests of the Collection page in the web application for Personal collection type.
 * 
 * @author Sowjanya Lankadasu <slankada@opentext.com>
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public class PersonalCollectionTestSet extends BasicTestSet {

    static Logger log = Logger.getLogger(PersonalCollectionTestSet.class);

    public PersonalCollectionTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
     * Check the Collection page elements:
     * 
     * -# @see loginAux() -# @see createSimpleCollectionAux() -# Check the
     * Collection page. -# @see deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Check the Collection page elements.")
    public void checkLayout(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create a new collection and enter.
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Personal");
        String name = collectionPage.getTitle();
        // Check the Collection page.
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Delete the created collection
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        // Perform the logout action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the Thumbs view in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Change to
     * Thumbs view. -# Check the view. -# @see deleteCollectionAux() -# @see
     * logoutAux()
     */
    @Test(description = "Check the Thumbs view.")
    public void thumbsViewTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Change to Thumbs view.
        collectionPage.changeToThumbsView();
        // Check the view.
        assertTrue("Thumbs view is not active.", collectionPage.isThumbsViewActive());

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the List view:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Change to
     * List view. -# Check the view. -# @see deleteCollectionAux() -# @see
     * logoutAux()
     */
    @Test(description = "Check the List view in a collection.")
    public void listViewTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Change to Thumbs view.
        collectionPage.changeToListView();
        // Check the view.
        assertTrue("List view is not active.", !collectionPage.isThumbsViewActive());

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the charge of more assets in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Scroll
     * bottom to charge more assets. -# Check quantity of assets shown. -#
     * Change to List view. -# Scroll bottom to charge more assets. -# Check
     * quantity of assets shown. -# @see deleteCollectionAux() -# @see
     * logoutAux()
     */
    @Test(description = "Check the charge of more assets in a collection.")
    public void chargeMoreAssetsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_MORETHAN_28, "Personal");
        String name = collectionPage.getTitle();

        // Navigate to the created collection.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());
        int numberOfAssetsShownBefore = collectionPage.getNumberOfAssetsShown();

        // wait until most of the assets are loaded to get items left link.
        collectionPage.waitUntil28AssetsLoad(name);

        // Check if the assets are saved in the collection.
        assertTrue("A minimum of 15 assets should be present to get the 'Items left' icon. But only - "
                + collectionPage.getCounterAssets() + "assets are present", collectionPage.getCounterAssets() > 15);

        // Scroll bottom to charge more assets.
        collectionPage.scrollToChargeMoreAssets();

        // Check quantity of assets shown.
        assertTrue("The number of assets shown has not increased.", numberOfAssetsShownBefore <= collectionPage
                .getNumberOfAssetsShown());

        // Change to List view.
        collectionPage.changeToListView();
        assertTrue("List view is not active.", !collectionPage.isThumbsViewActive());

        numberOfAssetsShownBefore = collectionPage.getNumberOfAssetsShown();
        // Scroll bottom to charge more assets.
        collectionPage.scrollToChargeMoreAssets();
        // Check quantity of assets shown.
        assertTrue("The number of assets shown has not increased.", numberOfAssetsShownBefore < collectionPage
                .getNumberOfAssetsShown());

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the Sort by in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Change the
     * SortBy option. -# Check the changes. -# Change to List view. -# Change
     * the SortBy option. -# Check the changes. -# @see deleteCollectionAux()
     * -# @see logoutAux()
     */
    @Test(description = "Check the Sort by in a collection.")
    public void sortByTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // In the Thumbs view:
        // For every option:
        for (int index = 1; index <= 4; index++) {
            // Change the SortBy option.
            collectionPage.changeSortByOptionSelected(index);
            // Check the changes.
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Change to List view:
        collectionPage.changeToListView();
        assertTrue("List view is not active.", !collectionPage.isThumbsViewActive());
        // For every option:
        for (int index = 1; index <= 4; index++) {
            // Change the SortBy option.
            collectionPage.changeSortByOptionSelected(index);
            // Check the changes.
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the search action with a non existing result in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Search for
     * a word with expected no result. -# Change to List view and check. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Check the search action with a non existing result in a collection.")
    public void searchForNonExistingResultTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Search for a word with expected no result.
        collectionPage.search(SEARCH_WORD_DONT_EXPECTED_RESULT);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Change to List view and check.
        collectionPage.changeToListView();
        assertTrue("List view is not active.", !collectionPage.isThumbsViewActive());

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the search action with an existing result in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Search for
     * a word with expected result. -# Change to List view and check. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Check the search action with an existing result in a collection.")
    public void searchForExistingResultTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Search for a word with expected result.
        collectionPage.search(SEARCH_WORD_1);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Change to List view and check.
        collectionPage.changeToListView();
        assertTrue("List view is not active.", !collectionPage.isThumbsViewActive());
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the History of the search bar in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Perform
     * some searches. -# Show the history. -# Check the history. -# Select an
     * option of the history. -# @see deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Check the History of the search bar in a collection.")
    public void checkHistoryResultTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        for (int index = 1; index < 11; index++) {
            // Perform a search.
            collectionPage.search(SEARCH_WORD_1 + " " + index);
            assertTrue("Collection page is not ready.", collectionPage.isReady());
        }

        // Show the history.
        collectionPage.typeCleanSearchText(SEARCH_WORD_1);
        // Check the history.
        assertTrue("The history is not shown.", collectionPage.isHistoryShown());

        // Select an option of the history.
        collectionPage.selectAnHistoryOptionAndSearch(2);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the search action with a multi-byte character search :
     *
     * -# @see loginAux() 
     * -# Create a collection and add a asset with multi-byte character name.
     * -# Naviaget to the collection and search for the asset.
     * -# Change to List view and check. 
     * -# @see deleteCollectionAux()
     * -# @see logoutAux()
     */
    @Test(description = "Check the search action with multi byte characters in a collection.", priority = 29)
    public void searchForMultiByteCharacterTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Create collection by giving shared user and Collection Owner.
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Gdrive");
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Save name collection
        String name = collectionPage.getTitle();
        // int oldCounterCollection = collectionPage.getHeader().getCollectionCounter();

        // Navigate to the search page
        searchPage = collectionPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready to work.", searchPage.isReady());

        // Perform a keyword search
        searchPage.search(SEARCH_WORD_WITH_MULTIBYTECHARACTERS);
        assertTrue("Search page is not ready after performing a search.", searchPage.isReady());
        assertTrue("No assets are fetched for the search. Please modify the search key.", searchPage
                .getCounterAssets() > 0);

        // Open the SaveInCollection component.
        SaveInCollectionPage saveInCollection = searchPage.openSaveInCollection();
        assertTrue("SaveInCollection component is not ready.", saveInCollection.isReady());

        // Add to created collection.
        saveInCollection.addToExistingCollection(name);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());
        collectionListAreaPage.sleep20();

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready while navigating to the created collection.", collectionPage
                .isReady());

        // Verify whether there are atleast one asset saved in the collection to perform the test.
        assertTrue("Atleast one asset should be saved in the collection to perform the test.", collectionPage
                .getCounterAssets() > 0);

        // Search for a word with multi-byte characters.
        collectionPage.search(SEARCH_WORD_WITH_MULTIBYTECHARACTERS);
        assertTrue("Collection page is not ready after multi-byte characters search action.", collectionPage.isReady());
        assertTrue("Assets should be displayed for the given search multi-byte keyword. This is failing because there are no assets with Multi-byte character name are uplaoded.", !(collectionPage
                .getCounterAssets() == 0));

        // Change to List view and check.
        collectionPage.changeToListView();
        assertTrue("Verify assets in list view after multi-byte characters search action.", !collectionPage
                .isThumbsViewActive());

        // Search for a word with multi-byte characters.
        collectionPage.search(SEARCH_WORD_WITH_MULTIBYTECHARACTERS);
        assertTrue("Collection page is not ready after multi-byte characters search action.", collectionPage.isReady());
        assertTrue("Assets should be displayed for the given search multi-byte keyword. This is failing because there are no assets with Multi-byte character name are uplaoded.", !(collectionPage
                .getCounterAssets() == 0));

        // performing log out action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check the advance search panel in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Open the
     * AdvanceSearch component. -# Use the date filters. -# Check changes of
     * Date filter. -# Use Reset button. -# Use the Asset Type filter. -# Check
     * changes of AssetType filter. -# @see deleteCollectionAux() -# @see
     * logoutAux()
     */
    @Test(description = "Check the advance search panel in a collection.")
    public void advanceSearchTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Open the AdvanceSearch component.
        AdvanceSearchPage advanceSearch = collectionPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());

        // Use the date filters.
        int prevCounterAssets = collectionPage.getCounterAssets();
        for (int index = 0; index < advanceSearch.getDateFilterSize(); index++) {
            advanceSearch.selectDateFilter(collectionPage.getContainerAssets(), index);
            // Check changes of Date filter.
            assertTrue("The previous counter of assets shouldn't be minor.", prevCounterAssets >= collectionPage
                    .getCounterAssets());
        }

        // Use Reset button.
        advanceSearch.clickOnResetButton(collectionPage.getContainerAssets());

        // Use the Asset Type filter
        for (int index = 0; index < advanceSearch.getAssetTypeFilterSize(); index++) {
            int counterAssetType = advanceSearch.selectAssetType(collectionPage.getContainerAssets(), index);
            // Check changes of AssetType filter.
            assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
            assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == collectionPage
                    .getCounterAssets());

            advanceSearch.removeAssetTypeFilter(collectionPage.getContainerAssets());
        }

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Multi selection of assets individually in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Using Ctrl
     * key select different assets. -# Check selected assets. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Multi selection of assets individually in a collection.")
    public void multiSelectionIndividuallyTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        // Using Ctrl key select different assets.
        int numberOfSelected = containerAssets.selectRandomAssetsUsingCtrlKey(collectionPage);
        // Check selected assets.
        assertTrue("Should be " + numberOfSelected + " selected assets but there are "
                + containerAssets.getCountOfSelected() + ".", containerAssets.getCountOfSelected() == numberOfSelected);

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Multi selection of assets from asset to asset in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Using Shift
     * key select different assets. -# Check selected assets. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Multi selection of assets from asset to asset in a collection.")
    public void multiSelectionFromAssetToAssetTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_3, "Personal");
        String name = collectionPage.getTitle();

        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        // Using Shift key select different assets.
        int numberOfSelected = containerAssets.selectAssetsUsingShiftKey(collectionPage, 1, 5);
        // Check selected assets.
        assertTrue("Should be " + numberOfSelected + " selected assets but there are "
                + containerAssets.getCountOfSelected() + ".", containerAssets.getCountOfSelected() == numberOfSelected);

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * View download standalone modal in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Navigate to
     * the SingleDownload modal. -# Check the SingleDownload modal. -# Close the
     * SingleDownload modal. -# @see deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "View download standalone modal in a collection.")
    public void viewDownloadStandaloneTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Navigate to the SingleDownload modal.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        SingleDownloadPage singleDownload = containerAssets
                .goToSingleDownloadOfTheAsset(containerAssets.getRandomIndexOfAssetsShown());
        // Check the SingleDownload modal.
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Close the SingleDownload modal.
        singleDownload.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Try to download standalone without accepting DRM in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Navigate to
     * the SingleDownload modal. -# Click on Download button without accepting
     * DRM. -# Close the SingleDownload modal. -# @see deleteCollectionAux()
     * -# @see logoutAux()
     */
    @Test(description = "Try to download standalone without accepting DRM in a collection.")
    public void downloadStandaloneWithoutDrmTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Navigate to the SingleDownload modal.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        SingleDownloadPage singleDownload = containerAssets
                .goToSingleDownloadOfTheAsset(containerAssets.getRandomIndexOfAssetsShown());
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Click on Download button without accepting DRM.
        singleDownload.clickOnDownloadButton();
        assertTrue("The error message should be shown.", !singleDownload.isErrorMessageShown());

        // Close the SingleDownload modal.
        singleDownload.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Perform a download standalone from thumbnail view in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Navigate to
     * the SingleDownload modal. -# Accept the DRM. -# Click on Download button.
     * -# Close the SingleDownload modal. -# @see deleteCollectionAux() -# @see
     * logoutAux()
     */
    @Test(description = "Perform a download standalone from thumbnail view in a collection.")
    public void downloadStandaloneFromThumbnailViewTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Navigate to the SingleDownload modal.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        SingleDownloadPage singleDownload = containerAssets
                .goToSingleDownloadOfTheAsset(containerAssets.getRandomIndexOfAssetsShown());
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Accept the DRM.
        singleDownload.acceptDRM();
        // Click on Download button.
        singleDownload.clickOnDownloadButton();
        assertTrue("The after download message and the link should be shown.", singleDownload
                .isAfterDownloadMessageAndLinkShown());

        // Close the SingleDownload modal.
        singleDownload.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Perform a download standalone using the link, in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Navigate to
     * the SingleDownload modal. -# Accept the DRM. -# Click on Download button.
     * -# Click on the download link. -# Close the SingleDownload modal. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Perform a download standalone using the link, in a collection.")
    public void downloadStandaloneByLinkTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Navigate to the SingleDownload modal.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        SingleDownloadPage singleDownload = containerAssets
                .goToSingleDownloadOfTheAsset(containerAssets.getRandomIndexOfAssetsShown());
        assertTrue("SingleDownload modal is not ready.", singleDownload.isReady());

        // Accept the DRM.
        singleDownload.acceptDRM();
        // Click on Download button.
        singleDownload.clickOnDownloadButton();
        assertTrue("The after download message and the link should be shown.", singleDownload
                .isAfterDownloadMessageAndLinkShown());

        // Click on the download link.
        singleDownload.clickOnDownloadLink();

        // Close the SingleDownload modal.
        singleDownload.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Download of multiples assets, in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Using Ctrl
     * key select different assets. -# Navigate to the MultiDownload modal. -#
     * Accept the DRM. -# Click on Download button. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Download of multiples assets, in a collection.")
    public void multiDownloadTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        // Using Ctrl key select different assets.
        int numberOfSelected = containerAssets.selectRandomAssetsUsingCtrlKey(collectionPage);
        assertTrue("Should be " + numberOfSelected + " selected assets but there are "
                + containerAssets.getCountOfSelected() + ".", containerAssets.getCountOfSelected() == numberOfSelected);

        // Navigate to the MultiDownload modal.
        MultiDownloadPage multiDownload = collectionPage.getActionArea()
                .goToMultiDownloadOfTheAssets(containerAssets.getCountOfSelected());
        assertTrue("MultiDownload modal is not ready.", multiDownload.isReady());

        // Accept the DRM.
        multiDownload.acceptDRM();
        // Click on Download button.
        multiDownload.clickOnDownloadButton();
        assertTrue("The after download message should be shown.", multiDownload.isAfterDownloadMessageShown());

        // Close the MultiDownload modal.
        multiDownload.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * View the assets details in a collection:
     *
     * -# @see loginAux() -# Perform an advance search for just images. -#
     * {@see createCollectionWithAssetsAux()}. -# Perform an advance search for
     * just images. -# Click on any asset to see the asset details. -# Check the
     * asset details modal. -# Close the asset details modal. -# Change to List
     * view. -# Click on any asset's view button to see the asset details. -#
     * Check the asset details modal. -# Close the asset details modal. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "View the assets details in a collection.")
    public void assetDetailsViewOfAnImageTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Perform an advance search for just images.
        AdvanceSearchPage advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        int counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "Image");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        /*// Perform an advance search for just images.
        advanceSearch = collectionPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        counterAssetType = advanceSearch.selectAssetType(collectionPage.getContainerAssets(), "Image");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == collectionPage
                .getCounterAssets());*/

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.IMAGE);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // Change to List view.
        collectionPage.changeToListView();
        assertTrue("List view is not active.", !collectionPage.isThumbsViewActive());

        // Click on any asset's view button to see the asset details.
        assetDetails = containerAssets.goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.IMAGE);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * View the assets details of a document:
     *
     * -# @see loginAux() -# Perform an advance search for just documents. -#
     * {@see createCollectionWithAssetsAux()}. -# Perform an advance search for
     * just documents. -# Click on any asset to see the asset details. -# Check
     * the asset details modal. -# Close the asset details modal. -# Change to
     * List view. -# Click on any asset's view button to see the asset details.
     * -# Check the asset details modal. -# Change pages using arrows. -# Close
     * the asset details modal. -# @see deleteCollectionAux() -# @see
     * logoutAux()
     */
    @Test(description = "View the assets details of a document.")
    public void assetDetailsViewOfADocumentTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Perform an advance search for just documents.
        AdvanceSearchPage advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        int counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "MSOffice");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_3, "Personal");
        String name = collectionPage.getTitle();

        // Perform an advance search for just documents.
        /*     advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "Acrobat PDF");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());*/

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.DOCUMENT);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // Change to List view.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        // Click on any asset's view button to see the asset details.
        assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.DOCUMENT);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * View the assets details of a video:
     *
     * -# @see loginAux() -# Perform an advance search for just documents. -#
     * {@see createCollectionWithAssetsAux()}. -# Perform an advance search for
     * just documents. -# Click on any asset to see the asset details. -# Check
     * the asset details modal. -# Click play a video -# Close the asset details
     * modal. -# Change to List view. -# Click on any asset's view button to see
     * the asset details. -# Check the asset details modal. -# Click play a
     * video -# Close the asset details modal. -# @see deleteCollectionAux()
     * -# @see logoutAux()
     */
    @Test(description = "View the assets details of a video.")
    public void assetDetailsViewOfAVideoTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Perform an advance search for just documents.
        AdvanceSearchPage advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        int counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "Video");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_3, "Personal");
        String name = collectionPage.getTitle();

        /*       // Perform an advance search for just documents.
        advanceSearch = searchPage.openAdvanceSearch();
        assertTrue("AdvanceSearch component is not ready.", advanceSearch.isReady());
        counterAssetType = advanceSearch.selectAssetType(searchPage.getContainerAssets(), "Video");
        assertTrue("The tag or the counter are not shown.", advanceSearch.areTagAndCounterShown());
        assertTrue("The counter of assets of the AssetType was wrong.", counterAssetType == searchPage
                .getCounterAssets());*/

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.VIDEO);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Click play a video
        assetDetails.goPlayVideo();

        // Close the asset details modal.
        assetDetails.close();

        // Change to List view.
        searchPage.changeToListView();
        assertTrue("List view is not active.", !searchPage.isThumbsViewActive());

        // Click on any asset's view button to see the asset details.
        assetDetails = containerAssets.goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.VIDEO);

        // Check the asset details modal.
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Click play a video
        assetDetails.goPlayVideo();

        // Close the asset details modal.
        assetDetails.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Perform the download from the asset details in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Click on
     * any asset to see the asset details. -# Expand the Download complement. -#
     * Accept the DRM. -# Click on Download button. -# Collapse the Download
     * complement. -# Close the asset details modal. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Perform the download from the asset details in a collection.")
    public void downloadFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        AssetDetailsPage assetDetails = containerAssets
                .goToAssetDetails(containerAssets.getRandomIndexOfAssetsShown(), AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the Download complement.
        AssetDetailsDownloadPage downloadComplement = AssetDetailsPage.getDownloadComplement();
        downloadComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Accept the DRM.
        downloadComplement.acceptDRM();

        // Click on Download button.
        downloadComplement.clickOnDownloadButton();
        assertTrue("The after download message and the link should be shown.", downloadComplement
                .isAfterDownloadMessageAndLinkShown());

        // Collapse the Download complement.
        downloadComplement.close();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Perform the 'save in a new collection' from the asset details in a
     * collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Click on
     * any asset to see the asset details. -# Expand the SaveInCollection
     * complement. -# Add a new collection. -# Close the asset details modal. -#
     * Navigate to the Collection List Area. -# Navigate to the created
     * collection. -# Check if the assets are saved in the collection. -# @see
     * logoutAux()
     */
    @Test(description = "Perform the 'save in a new collection' from the asset details in a collection.")
    public void saveInNewCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name1 = collectionPage.getTitle();

        int oldCounterCollection = collectionPage.getHeader().getCollectionCounter();
        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();

        int index = containerAssets.getRandomIndexOfAssetsShown();
        // String assetsIDs = containerAssets.getAssetIDsOfAsset(index);
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(containerAssets.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Add a new collection.
        String name2 = "Collection - " + new Date().getTime();
        saveInCollectionComplement.addToNewCollection(name2, "Albums");
        // Collapse the SaveInCollection complement (not necessary).
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        searchPage.sleep20andRefresh();
        /*
         * assertTrue("The counter of collections hasn't been increased.",
         * oldCounterCollection + 1 == searchPage
         * .getHeader().getCollectionCounter());
         */

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name2);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));

        // Delete the created collections
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name1);
        collectionListAreaPage = deleteCollectionAux(collectionListAreaPage.getHeader(), name2);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Perform the 'Saving result in an existing collection.' from the asset
     * details in a collection:
     *
     * -# @see loginAux() -# @see createSimpleCollectionAux() -# @see
     * createCollectionWithAssetsAux() -# Click on any asset to see the asset
     * details. -# Expand the SaveInCollection complement. -# Close the asset
     * details modal. -# Navigate to the Collection List Area. -# Navigate to
     * the created collection. -# Check if the assets are saved in the
     * collection. -# @see deleteCollectionAux -# @see logoutAux()
     */
    @Test(description = "Perform the 'Saving result in an existing collection.' from the asset details in a collection.")
    public void saveInExistingCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection simple
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Albums");

        // Save name collection
        String name = collectionPage.getTitle();

        // Navigate to seach page.
        searchPage = collectionPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Create collection with assets
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name1 = collectionPage.getTitle();

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();

        int index = containerAssets.getRandomIndexOfAssetsShown();
        // String assetsIDs = containerAssets.getAssetIDsOfAsset(index);
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(containerAssets.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Select the checkbox of the existing collections to save in.
        saveInCollectionComplement.addToExistingCollection(name);
        // Collapse the SaveInCollection complement (not necessary).
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        searchPage.sleep20andRefresh();
        /*
         * assertTrue("The counter of collections hasn't been increased.",
         * oldCounterCollection + 1 == searchPage
         * .getHeader().getCollectionCounter());
         */

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));

        // Delete the created collections
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name1);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Perform the asset saved in a collection should appear as marked in the
     * complement 'Save in' from the asset details in a collection:
     *
     * -# @see loginAux() -# @see createSimpleCollectionAux() -# @see
     * createCollectionWithAssetsAux() -# Click on any asset to see the asset
     * details. -# Expand the SaveInCollection complement. -# Close the asset
     * details modal. -# Navigate to the Collection List Area. -# Navigate to
     * the created collection. -# Click on any asset to see the asset details.
     * -# Expand the SaveInCollection complement. -# @see checkCollection() -#
     * Close the asset details modal. -# Check if the assets are saved in the
     * collection. -# @see deleteCollectionAux -# @see logoutAux()
     */
    @Test(description = "Asset saved in a collection should appear as marked in the complement 'Save in' from the asset details in a collection.")
    public void belongingToCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection simple
        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Albums");

        // Save name collection
        String name = collectionPage.getTitle();
        // int oldCounterCollection = collectionPage.getHeader().getCollectionCounter();

        // Navigate to seach page.
        searchPage = collectionPage.getHeader().clickOnLogo();
        assertTrue("Search page is not ready.", searchPage.isReady());

        // Create collection with assets
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name1 = collectionPage.getTitle();

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();

        int index = containerAssets.getRandomIndexOfAssetsShown();
        // String assetsIDs = containerAssets.getAssetIDsOfAsset(index);
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(containerAssets.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Select the checkbox of the existing collections to save in.
        saveInCollectionComplement.addToExistingCollection(name);
        // Collapse the SaveInCollection complement (not necessary).
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        searchPage.sleep20andRefresh();
        /*
         * assertTrue("The counter of collections hasn't been increased.",
         * oldCounterCollection + 1 == searchPage
         * .getHeader().getCollectionCounter());
         */
        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Click on any asset to see the asset details.
        containerAssets = collectionPage.getContainerAssets();

        assetDetails = containerAssets.goToAssetDetails(0, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();

        // Check the save asset is in the collection
        assertTrue("Collection hasn't been found.", saveInCollectionComplement
                .checkCollectionIsSavingThisAsset(name) != null);

        // Close the asset details modal.
        assetDetails.close();

        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));

        // Delete the created collections
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name1);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Delete an asset from a collection by the complement 'Save in' of the
     * asset details.:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Click on
     * any asset to see the asset details. -# Expand the SaveInCollection
     * complement. -# Close the asset details modal. -# Navigate to the
     * Collection List Area. -# Navigate to the created collection. -# Click on
     * any asset to see the asset details. -# Expand the SaveInCollection
     * complement. -# @see addToNewCollection() -# Close the asset details
     * modal. -# Navigate to the Collection List Area. -# Navigate to the
     * created collection. -# Click on any asset to see the asset details. -#
     * Expand the SaveInCollection complement. -# @see deleteAssetOfCollection
     * -# Check if the assets are saved in the collection. -# @see
     * deleteCollectionAux -# @see logoutAux()
     */
    @Test(description = "Delete an asset from a collection by the complement 'Save in' of the asset details.")
    public void deletingOfCollectionFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection with assets
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name1 = collectionPage.getTitle();
        int oldCounterCollection = collectionPage.getHeader().getCollectionCounter();

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();

        int index = containerAssets.getRandomIndexOfAssetsShown();
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(containerAssets.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        AssetDetailsSaveInCollectionPage saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());
        // Add a new collection.
        String name = "Collection - " + new Date().getTime();
        saveInCollectionComplement.addToNewCollection(name, "Albums");
        // Collapse the SaveInCollection complement (not necessary).
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        searchPage.sleep20andRefresh();
        /*
         * assertTrue("The counter of collections hasn't been increased.",
         * oldCounterCollection + 1 == searchPage
         * .getHeader().getCollectionCounter());
         */

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Click on any asset to see the asset details.
        assetDetails = containerAssets.goToAssetDetails(0, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the SaveInCollection complement.
        saveInCollectionComplement = AssetDetailsPage.getSaveInComplement();
        saveInCollectionComplement.open();

        // Delete an asset from a collection
        saveInCollectionComplement.deleteAssetOfCollection(collectionPage.getContainerAssets(), name);

        // Check if the assets are saved in the collection.
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", !containerAssets
                .compareLists(assetsIDs, containerAssets.getAssetIDsOfAssetsShown()));

        // Delete the created collection
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name1);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Search for a metadata value.:
     *
     * -# {@see loginAux()}. -# {@see createCollectionWithAssetsAux()}. -#
     * Navigate to the export modal. -# Check the export modal is not shown. -#
     * {@see logoutAux()}.
     */
    @Test(description = "Search for a metadata value..")
    public void searchForMetadataValueFromAssetDetailsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection with assets
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Click on any asset to see the asset details.
        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();

        int index = containerAssets.getRandomIndexOfAssetsShown();
        List<String> assetsIDs = new ArrayList<String>();
        assetsIDs.add(containerAssets.getAssetIDsOfAsset(index));

        AssetDetailsPage assetDetails = containerAssets.goToAssetDetails(index, AssetType.IMAGE);
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Expand the Metadata complement.
        AssetDetailsMetadatasPage metadataComplement = AssetDetailsPage.getMetadataComplement();

        // Expand the group of metadatas.
        metadataComplement.openGroup();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Perform a search in the metadata input.
        String textToSearch = ".";
        int counter = metadataComplement.numberOfMetadatasValuesShown();
        metadataComplement.search(textToSearch);

        // Check the text is found in the metadatas values.
        assertTrue("Should have less metadatas shown.", counter >= metadataComplement.numberOfMetadatasValuesShown());
        assertTrue("The visible values don't contain the searched text.", metadataComplement
                .isContainedInEveryValueShown(textToSearch));

        // Collapse the Metadata complement.
        metadataComplement.closeGroup();
        assertTrue("AssetDetails modal is not ready.", assetDetails.isReady());

        // Close the asset details modal.
        assetDetails.close();

        // Delete the created collection
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());

    }

    /**
     * Exporting to CSV or PDF a collection without assets:
     *
     * -# {@see loginAux()}. -# {@see createSimpleCollectionAux()}. -# Navigate
     * to the export modal. -# Check the export modal is not shown. -# @see
     * deleteCollectionAux() -# {@see logoutAux()}.
     */
    @Test(description = "Exporting to CSV or PDF a collection without assets.")
    public void exportCsvOrPdfWithouthAssetsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createSimpleCollectionAux(searchPage.getHeader(), "Albums");
        String name = collectionPage.getTitle();

        // Navigate to the export modal.
        ExportPage exportModal = collectionPage.goToExport();
        // Check the export modal is shown.
        assertTrue("Ok button of the modal is not ready.", collectionPage.isOkOfModalShown());
        assertTrue("Export modal shouldn't be shown.", exportModal == null || !exportModal.isReady());
        collectionPage.clickOnOkOfModal();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Export to CSV a collection:
     *
     * -# {@see loginAux()}. -# {@see createCollectionWithAssetsAux()}. -#
     * Navigate to the export modal. -# Check the export modal is shown. -#
     * Click on CSV button of one of the templates. -# Check the counter of
     * Inbox's messages has increased. -# Enter in the Inbox and check the last
     * message. -# @see deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Export to CSV a collection.")
    public void exportAllToCsvTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();
        int inboxCounter = collectionPage.getHeader().getInboxCounter();

        // Navigate to the export modal.
        ExportPage exportModal = collectionPage.goToExport();
        // Check the export modal is shown.
        assertTrue("Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());

        // Click on CSV button of one of the templates.
        exportModal.clickOnCSVButton(0);

        // Check the counter of Inbox's messages has increased.
        exportModal.sleep20andRefresh(); // This wait is needed to leave time to
                                         // receive the message.
        assertTrue("The inbox counter should have been increased.", collectionListAreaPage.getHeader()
                .getInboxCounter() == inboxCounter + 1);
        // Enter in the Inbox and check the last message.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("The message is not the correct one.", inboxPage.isMessageOfExportFile(0));
        inboxPage.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Export to PDF a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Navigate to
     * the export modal. -# Check the export modal is shown. -# Click on PDF
     * button of one of the templates. -# Check the counter of Inbox's messages
     * has increased. -# Enter in the Inbox and check the last message. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Export to PDF a collection.")
    public void exportAllToPdfTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();
        int inboxCounter = collectionPage.getHeader().getInboxCounter();

        // Navigate to the export modal.
        ExportPage exportModal = collectionPage.goToExport();
        // Check the export modal is shown.
        assertTrue("Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());

        // Click on PDF button of one of the templates.
        exportModal.clickOnPDFButton(0);

        // Check the counter of Inbox's messages has increased.
        exportModal.sleep20andRefresh(); // This wait is needed to leave time to
                                         // receive the message.
        assertTrue("The inbox counter should have been increased.", collectionListAreaPage.getHeader()
                .getInboxCounter() == inboxCounter + 1);
        // Enter in the Inbox and check the last message.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("The message is not the correct one.", inboxPage.isMessageOfExportFile(0));
        inboxPage.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Show actions available:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Open the
     * actions area. -# Check the actions area is open. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Show actions available.")
    public void showActionsAvailableTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Open the actions area.
        collectionPage.getActionArea().openActionsArea();
        // Check the actions area is open.
        assertTrue("The action area is collapsed.", collectionPage.getActionArea().isActionAreaOpen());

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Select all assets in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Open the
     * actions area. -# Click on 'Select all' button. -# Check every asset shown
     * is selected. -# @see deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Select all assets in a collection.")
    public void selectAllTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Open the actions area.
        collectionPage.getActionArea().openActionsArea();

        // Click on 'Select all' button.
        collectionPage.getActionArea().clickOnSelectUnselectAll();
        // Check every asset shown is selected.
        assertTrue("Not every asset shown is selected.", collectionPage.getContainerAssets()
                .getCountOfSelected() == collectionPage.getNumberOfAssetsShown());

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Unselect all assets in a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Open the
     * actions area. -# Click on 'Select all' button. -# Click on 'Unselect all'
     * button. -# Check no assets shown are selected. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Unselect all assets in a collection.")
    public void unselectAllTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Open the actions area.
        collectionPage.getActionArea().openActionsArea();

        // Click on 'Select all' button.
        collectionPage.getActionArea().clickOnSelectUnselectAll();
        assertTrue("Not every asset shown is selected.", collectionPage.getContainerAssets()
                .getCountOfSelected() == collectionPage.getNumberOfAssetsShown());

        // Click on 'Unselect all' button.
        collectionPage.getActionArea().clickOnSelectUnselectAll();
        // Check no assets shown are selected.
        assertTrue("There should not be any assets selected.", collectionPage.getContainerAssets()
                .getCountOfSelected() == 0);

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());

    }

    /**
     * Export selection to CSV:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Select some
     * assets. -# Navigate and click on the 'Export selection' button. -# Check
     * the export modal is shown. -# Click on CSV button of one of the
     * templates. -# Check the counter of Inbox's messages has increased. -#
     * Enter in the Inbox and check the last message. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Export selection to CSV.")
    public void exportSelectionToCsvTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();
        int inboxCounter = collectionPage.getHeader().getInboxCounter();

        // Select some assets.
        collectionPage.getContainerAssets().selectRandomAssetsUsingCtrlKey(collectionPage);
        assertTrue("None asset shown is selected.", collectionPage.getContainerAssets().getCountOfSelected() > 0);

        // Navigate and click on the 'Export selection' button.

        ExportPage exportModal = collectionPage.getActionArea().goToExportSelection(collectionPage
                .getCounterAssets(), collectionPage.getContainerAssets().getCountOfSelected());
        // Check the export modal is shown.
        assertTrue("Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());

        // Click on CSV button of one of the templates.
        exportModal.clickOnCSVButton(0);

        // Check the counter of Inbox's messages has increased.
        exportModal.sleep20andRefresh(); // This wait is needed to leave time to
                                         // receive the message.
        assertTrue("The inbox counter should have been increased.", collectionListAreaPage.getHeader()
                .getInboxCounter() == inboxCounter + 1);
        // Enter in the Inbox and check the last message.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("The message is not the correct one.", inboxPage.isMessageOfExportFile(0));
        inboxPage.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Export selection to PDF:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Select some
     * assets. -# Navigate and click on the 'Export selection' button. -# Check
     * the export modal is shown. -# Click on PDF button of one of the
     * templates. -# Check the counter of Inbox's messages has increased. -#
     * Enter in the Inbox and check the last message. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Export selection to PDF.")
    public void exportSelectionToPdfTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();
        int inboxCounter = collectionPage.getHeader().getInboxCounter();

        // Select some assets.
        collectionPage.getContainerAssets().selectRandomAssetsUsingCtrlKey(collectionPage);
        assertTrue("None asset shown is selected.", collectionPage.getContainerAssets().getCountOfSelected() > 0);

        // Navigate and click on the 'Export selection' button.
        ExportPage exportModal = collectionPage.getActionArea().goToExportSelection(collectionPage
                .getCounterAssets(), collectionPage.getContainerAssets().getCountOfSelected());
        // Check the export modal is shown.
        assertTrue("Export modal is not ready (or there are not any template created).", exportModal != null
                && exportModal.isReady());

        // Click on PDF button of one of the templates.
        exportModal.clickOnPDFButton(0);

        // Check the counter of Inbox's messages has increased.
        exportModal.sleep20andRefresh(); // This wait is needed to leave time to
                                         // receive the message.
        assertTrue("The inbox counter should have been increased.", collectionListAreaPage.getHeader()
                .getInboxCounter() == inboxCounter + 1);
        // Enter in the Inbox and check the last message.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("The message is not the correct one.", inboxPage.isMessageOfExportFile(0));
        inboxPage.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Change collection cover:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Navigate
     * back to collection list area. -# Get old cover of the created collection.
     * -# Enter in the created collection. -# Change the cover. -# Navigate back
     * to collection list area. -# Compare the cover have changed. -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Change collection cover.")
    public void changeCollectionCoverTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();
        int numberOfAssetsShown = collectionPage.getNumberOfAssetsShown();

        // Navigate back to collection list area.
        collectionListAreaPage = collectionPage.goBack();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Get old cover of the created collection.
        String oldCover = collectionListAreaPage.getContainerCollections().getImageSrc(name);
        assertTrue("This cover has just the default image.", oldCover != null);

        // Enter in the created collection.
        collectionPage = collectionListAreaPage.getContainerCollections().navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Change the cover.
        collectionPage.getActionArea().changeCover(collectionPage.getNumberOfAssetsShown() - 1, collectionPage
                .getContainerAssets(), collectionPage);

        // Navigate back to collection list area.
        collectionListAreaPage = collectionPage.goBack();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Compare the cover have changed.
        if (numberOfAssetsShown > 1) {
            assertTrue("Collection List Area page is not ready.", !oldCover
                    .equalsIgnoreCase(collectionListAreaPage.getContainerCollections().getImageSrc(name)));
        } else {
            assertTrue("Collection List Area page is not ready.", oldCover
                    .equalsIgnoreCase(collectionListAreaPage.getContainerCollections().getImageSrc(name)));
        }

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Multi download of selected assets:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Using Ctrl
     * key select different assets. -# Navigate to the MultiDownload modal. -#
     * Accept the DRM. -# Click on Download button. -# Check the counter of
     * Inbox's messages has increased. -# Enter in the Inbox and check the last
     * message. -# @see deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Multi download of selected assets.")
    public void multiDownloadOfSelectedAssetsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();
        int inboxCounter = collectionPage.getHeader().getInboxCounter();

        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        // Using Ctrl key select different assets.
        int numberOfSelected = containerAssets.selectRandomAssetsUsingCtrlKey(collectionPage);
        /*
         * assertTrue( "Should be " + numberOfSelected +
         * " selected assets but there are " +
         * containerAssets.getCountOfSelected() + ".",
         * containerAssets.getCountOfSelected() == numberOfSelected);
         */

        // Navigate to the MultiDownload modal.
        MultiDownloadPage multiDownload = collectionPage.getActionArea()
                .goToMultiDownloadOfTheAssets(containerAssets.getCountOfSelected());
        assertTrue("MultiDownload modal is not ready.", multiDownload.isReady());

        // Accept the DRM.
        multiDownload.acceptDRM();
        // Click on Download button.
        multiDownload.clickOnDownloadButton();
        assertTrue("The after download message should be shown.", multiDownload.isAfterDownloadMessageShown());

        // Close the MultiDownload modal.
        multiDownload.close();

        // Check the counter of Inbox's messages has increased.
        assertTrue("The inbox counter should have been increased.", collectionListAreaPage.getHeader()
                .getInboxCounter() > inboxCounter);
        // Enter in the Inbox and check the last message.
        inboxPage = collectionListAreaPage.getHeader().clickOnInboxButton();
        assertTrue("The message should be as unread.", !inboxPage.isMessageRead(0));
        assertTrue("The message is not the correct one.", inboxPage.isNotMessageOfExportFile(0));
        inboxPage.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Delete the selected assets.:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Using Ctrl
     * key select different assets. -# Click on delete button. -# Click on
     * Download button. -# Check if the assets are deleted in the collection.
     * -# @see deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Delete the selected assets.")
    public void deletingTheSelectedAssetsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        ContainerAssetsPage containerAssets = collectionPage.getContainerAssets();
        List<String> assetsIDs = containerAssets.getAssetIDsOfAssetsShown();

        // Using Ctrl key select different assets.
        int numberOfSelected = containerAssets.selectRandomAssetsUsingCtrlKey(collectionPage);
        /*
         * assertTrue( "Should be " + numberOfSelected +
         * " selected assets but there are " +
         * containerAssets.getCountOfSelected() + ".",
         * containerAssets.getCountOfSelected() == numberOfSelected);
         */

        // Click on delete button.
        collectionPage.deleteSelectedAssets();
        containerAssets = collectionPage.getContainerAssets();
        assertTrue("Collection page is not ready.", !containerAssets
                .compareLists(containerAssets.getAssetIDsOfAssetsShown(), assetsIDs));

        // Delete the collection.
        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check collection Info modal:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Navigate to
     * collection info modal. -# Check collection info modal. -# Close
     * collection info modal. -# @see deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Check collection Info modal.")
    public void checkCollectionInfoTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String name = collectionPage.getTitle();

        // Navigate to collection info modal.
        CollectionInfoPage infoModal = collectionPage.goToInfo();

        // Check collection info modal.
        assertTrue("Collection Info modal is not ready.", infoModal.isReady());

        // Close collection info modal.
        infoModal.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), name);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Edition of a collection:
     *
     * -# @see loginAux() -# @see createCollectionWithAssetsAux() -# Navigate to
     * collection info modal. -# Navigate to edit collection modal. -# -# @see
     * deleteCollectionAux() -# @see logoutAux()
     */
    @Test(description = "Edition of a collection.")
    public void editCollectionTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");
        String collName = collectionPage.getTitle();

        // Navigate to collection info modal.
        CollectionInfoPage infoModal = collectionPage.goToInfo();
        assertTrue("Collection Info modal is not ready.", infoModal.isReady());

        // Navigate to edit collection modal.
        EditionCollectionPage editPage = infoModal.goToEditModal();
        assertTrue("Edit collection modal is not ready.", editPage.isReady());

        // Editing collection information.
        String editedCollName = "Edited - " + collName;
        collectionPage = editPage.editCollInfo(collectionPage, editedCollName);

        // Validate collection page is ready.
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Validate the edited name.
        assertTrue("The name of the collection should be changed to new name - " + editedCollName
                + " but it still has the old name - " + collName
                + ".", collectionPage.getCollectionName().equals(editedCollName));

        editPage.close();

        collectionListAreaPage = deleteCollectionAux(collectionPage.getHeader(), collName);

        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * User tries to share a new collection without assets. -# @see loginAux()
     * with admin. -# @see createCollectionWithOwnerSharedUsersAux(), create a
     * collection by giving owner and shared user. -# @see logoutAndLoginAux()
     * with Collection Owner user. -# Navigate to the Collection List Area. -#
     * Check if the Collection owner have the collection in My Collection tab.
     * -# @see logoutAndLoginAux() with Shared user. -# Navigate to the
     * Collection List Area. -# Check if the Shared User have the collection in
     * Shared tab. -# @see logoutAux(). -# @author Sowjanya Lankadasu
     * <slankada@opentext.com>.
     */
    @Test(description = "The user tries to share a new collection without assets with a shared user and with collection owner.")
    public void userSharesCollectionWithSharedUserAndOwnerTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Login to the application
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection by giving shared user and Collection Owner.
        collectionPage = createCollectionWithOwnerSharedUsersAux(searchPage.getHeader(), "Albums");

        // Save name collection.
        String name = collectionPage.getTitle();
        System.out.println("Name of the collection created is " + name);

        // log out and login again with Collection owner user.
        searchPage = logoutAndLoginAux(UserDomain.COLLECTIONOWNER, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // log out and login again with Shared user.
        searchPage = logoutAndLoginAux(UserDomain.SHAREDUSER, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Switch to Shared tab.
        collectionListAreaPage.clickOnShareButton();

        // Navigate to the created collection in Shared tab.
        ContainerCollectionsPage containerCollectionsShr = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollectionsShr.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Logout from shared user
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * User tries to share a new collection with assets and edit collection by
     * adding shared user and collection user and verify. -# @see loginAux()
     * with superuser. -# @see createCollectionWithAssetsAux(). -# Navigate to
     * the Collection List Area. -# Navigate to the created collection -#
     * Navigate to collection info modal. -# Navigate to edit collection modal.
     * -# Add Collection owner and shared user to the created collection and
     * save. -# @see logoutAndLoginAux() with Collectio Owner user. -# Navigate
     * to the Collection List Area. -# Check if the Collection owner have the
     * collection in My Collection tab. -# @see logoutAndLoginAux() with Shared
     * user. -# Navigate to the Collection List Area. -# Check if the Shared
     * User have the collection in Shared tab. -# @see logoutAux(). -# @author
     * Sowjanya Lankadasu <slankada@opentext.com>.
     */
    @Test(description = "The user tries to share a new collection with a shared user and with another owner user.")
    public void userSharesCollectionWithSharedUserAndOwnerWithAssetsTest(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName()
                + " - Start test method: userSharesCollectionWithSharedUserAndOwnerWithAssetsTest");

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Create collection by giving shared user and Collection Owner.
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");

        // Save name of the collection.
        String name = collectionPage.getTitle();
        System.out.println("Name of the collection created is " + name);

        // Navigate to the Collection List Area.
        HeaderPage headerPage = new HeaderPage(DriverManager.getDriver());
        collectionListAreaPage = headerPage.clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollections = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollections.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Navigate to collection info modal.
        CollectionInfoPage infoModal = collectionPage.goToInfo();
        assertTrue("Collection Info modal is not ready.", infoModal.isReady());

        // Navigate to edit collection modal.
        EditionCollectionPage editPage = infoModal.goToEditModal();
        assertTrue("Edit collection modal is not ready.", editPage.isReady());

        // Add Collection owner and shared user to the created collection
        CreateCollectionPage createCollectionPage = new CreateCollectionPage(DriverManager.getDriver());
        createCollectionPage.fillCollectionOwnerEmail(COLLECTION_OWNER);
        createCollectionPage.fillSharetoEmail(SHARED_USER);

        // Click on Save button.
        editPage.clickOnSaveButton();
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // log out and login again with Collection owner user.
        searchPage = logoutAndLoginAux(UserDomain.COLLECTIONOWNER, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Navigate to the created collection.
        ContainerCollectionsPage containerCollection = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollection.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // log out and login again with Shared user.
        searchPage = logoutAndLoginAux(UserDomain.SHAREDUSER, UserType.QA1);

        // Navigate to the Collection List Area.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Switch to Shared tab.
        collectionListAreaPage.clickOnShareButton();

        // Navigate to the created collection in Shared tab.
        ContainerCollectionsPage containerCollectionsShr = collectionListAreaPage.getContainerCollections();
        collectionPage = containerCollectionsShr.navigateToCollection(name);
        assertTrue("Collection page is not ready.", collectionPage.isReady());

        // Logout from shared user
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName()
                + " - End test method: userSharesCollectionWithSharedUserAndOwnerWithAssetsTest");
    }

    /**
     * Creation of a collection and sharing to user via email:
     * 
     * -# @see loginAux() 
     * -# The user enters and log in the web. 
     * -# Create a personal Collection with assets and navigate to particular collection. 
     * -# Click on Share button. 
     * -# Write a correct email. 
     * -# Fill Email and Comment. 
     * -# Click on SendEmail. 
     * -# @see logoutAux()
     */
    @Test(description = "Creation of a collection and sharing with correct email address.")
    public void createCollectionAndShareWithCorrectEmail(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Search for asserts and create collection and also navigated to
        // created Collection
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_3, "Personal");

        // Click on Share button
        collectionPage.clickOnShareButton();
        assertTrue("SendEmail and Cancel buttons are not visible.", collectionPage.isSendEmailAndCancelButtonVisible());

        // Fill Email and ShareComment
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        collectionPage.fillShareCollectionEmail(UserDomain.LDAP_USER, UserType.QA1);
        collectionPage.fillShareCollectionComment("SharedComment - " + df.format(now));

        // Click on SendEmail
        collectionPage.clickOnSendEmail();
        assertTrue("Alert Message is NOT maching.", collectionPage
                .isSharedEmailMessageValid(UserDomain.LDAP_USER, UserType.QA1));

        // Logout
        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check that User tries to share a collection with an incorrect email.
     * 
     * -# @see loginAux() -# The user enters and log in the web. -# Create
     * Collection with assets and navigate to particular collection. -# Click on
     * Share button. -# Write an incorrect email. -# Click on Send button.
     * -# @see logoutAux()
     */
    @Test(description = "Share a collection with an incorrect email.")
    public void shareCollectionwithIncorrectemail(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Search for asserts and create collection and also navigated to created Collection
        collectionPage = createCollectionWithAssetsAux(searchPage.getHeader(), SEARCH_WORD_2, "Personal");

        // Click on Share button
        collectionPage.clickOnShareButton();
        assertTrue("SendEmail and Cancel buttons are not visible.", collectionPage.isSendEmailAndCancelButtonVisible());

        // Fill Email and ShareComment
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date now = Calendar.getInstance().getTime();
        collectionPage.fillShareCollectionEmail(UserDomain.INVALID, UserType.QA1);
        collectionPage.fillShareCollectionComment("SharedComment - " + df.format(now));

        // Asserting Email text area description for invaild email's
        assertTrue("Invalid email textarea description is not present", collectionPage.isErrorMessageForInavlidEmail());

        // Click on SendEmail
        collectionPage.clickOnSendEmail();
        assertTrue("Alert Message is NOT maching.", collectionPage
                .isSharedEmailMessageInvalid(UserDomain.INVALID, UserType.QA1));

        // Logout
        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

}
