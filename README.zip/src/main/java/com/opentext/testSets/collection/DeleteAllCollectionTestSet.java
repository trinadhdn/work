/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 *  OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.collection;

import static org.testng.AssertJUnit.assertTrue;

import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain the tests of the Collection page in the web application.
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class DeleteAllCollectionTestSet extends BasicTestSet {

    static Logger log = Logger.getLogger(DeleteAllCollectionTestSet.class);

    public DeleteAllCollectionTestSet() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
        * Delete All Collections:-
        * 
        * -# @see loginAux()
        * -# Go to Collections
        * -# Delete all collections 
        * -# @see logoutAux()
        */
    @Test(description = "Delete All Collections")
    public void deleteAllCollections(Method method) {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        // Perform login action.
        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // Check the Collection page.
        collectionListAreaPage = searchPage.getHeader().clickOnCollectionsButton();
        assertTrue("Collection List Area page is not ready.", collectionListAreaPage.isReady());

        // Expand all collections
        collectionListAreaPage.expandAll();

        // Delete all
        collectionListAreaPage.deleteAllCollections();

        // Perform the logout action.
        logoutPage = logoutAux(collectionListAreaPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

}
