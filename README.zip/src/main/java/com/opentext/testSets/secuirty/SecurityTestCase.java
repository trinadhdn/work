/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.testSets.secuirty;

import static org.testng.AssertJUnit.assertTrue;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.google.gson.JsonArray;
import com.opentext.api.DHApiResponse;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.folders.FoldersPage;
import com.opentext.pageObjects.folders.foldersSideBar.FoldersSideBar;
import com.opentext.pageObjects.singleDownload.specificModal.MultiDownloadPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.testSets.BasicTestSet;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain the tests of the Search page in the web application.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public class SecurityTestCase extends BasicTestSet {

    static Logger log = Logger.getLogger(SecurityTestCase.class);

    public SecurityTestCase() {
        super();
    }

    @BeforeMethod(description = "startTest")
    public void before() {
        super.before();
    }

    @AfterMethod(description = "endTest")
    public void afterAllIsSaidAndDone() {
        super.afterAllIsSaidAndDone();
    }

    /**
        * Check DH data when super login
        *
        * -# @see loginAux()
        * -# Check the data
        * -# @see logoutAux()
        * @throws IOException 
        * @throws ClientProtocolException 
        */
    @Test(description = "Check DH data when super login .", enabled = true)
    public void checkDatainDHWithSuperAdmin(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());
        int NumberOfAssetsFromAPIcall = apiResponse
                .getTotalAssetsCountFromAPICall(UserDomain.SUPERADMIN, UserType.QA1, "search");

        // GET assets LIST from OTMM through API CALL
        JsonArray assetsIDListFromApi = apiResponse
                .getAssetsListFromAPICall(UserDomain.SUPERADMIN, UserType.QA1, "search");

        // Get counter from DH UI
        int numberOfAssetsShowninUI = searchPage.getCounterAssets();
        ContainerAssetsPage containerAssetsPage = new ContainerAssetsPage(DriverManager.getDriver());

        // Scroll extreme down to last asset in search page
        containerAssetsPage.scrollToDown();

        // get asset list from DH ui
        List<String> assetIDsFromUI = containerAssetsPage.getAllAssetIDsOfAssetsShown();

        // Assert the counter from UI and counter from API Call
        assertTrue("Thumbs view is not active.", numberOfAssetsShowninUI == NumberOfAssetsFromAPIcall);

        // Assert the AssetsID's from UI and counter from API Call
        assertTrue("Thumbs view is not active.", apiResponse.checkAssetsList(assetIDsFromUI, assetsIDListFromApi));

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH data when Defaultuser login
     *
     * -# @see loginAux()
     * -# Check the data
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH data when Defaultuser login .", enabled = true)
    public void checkDatainDHWithdefaultUser(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.DHAMTDEFAULTUSER, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());
        int NumberOfAssetsFromAPIcall = apiResponse
                .getTotalAssetsCountFromAPICall(UserDomain.DHAMTDEFAULTUSER, UserType.QA1, "search");

        // GET assets LIST from OTMM through API CALL
        JsonArray assetsIDListFromApi = apiResponse
                .getAssetsListFromAPICall(UserDomain.DHAMTDEFAULTUSER, UserType.QA1, "search");

        // Get counter from DH UI
        int numberOfAssetsShowninUI = searchPage.getCounterAssets();
        ContainerAssetsPage containerAssetsPage = new ContainerAssetsPage(DriverManager.getDriver());

        // Scroll extreme down to last asset in search page
        containerAssetsPage.scrollToDown();

        // get asset list from DH ui
        List<String> assetIDsFromUI = containerAssetsPage.getAllAssetIDsOfAssetsShown();

        // Assert the counter from UI and counter from API Call
        assertTrue("Thumbs view is not active.", numberOfAssetsShowninUI == NumberOfAssetsFromAPIcall);

        // Assert the AssetsID's from UI and counter from API Call
        assertTrue("Thumbs view is not active.", apiResponse.checkAssetsList(assetIDsFromUI, assetsIDListFromApi));

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH data when LDAP user login
     *
     * -# @see loginAux()
     * -# Check the data
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH data whenLDAP user login .", enabled = true)
    public void checkDatainDHWithLAPUse(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SHAREDUSER, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());
        int NumberOfAssetsFromAPIcall = apiResponse
                .getTotalAssetsCountFromAPICall(UserDomain.SHAREDUSER, UserType.QA1, "search");

        // GET assets LIST from OTMM through API CALL
        JsonArray assetsIDListFromApi = apiResponse
                .getAssetsListFromAPICall(UserDomain.SHAREDUSER, UserType.QA1, "search");

        // Get counter from DH UI
        int numberOfAssetsShowninUI = searchPage.getCounterAssets();
        ContainerAssetsPage containerAssetsPage = new ContainerAssetsPage(DriverManager.getDriver());

        // Scroll extreme down to last asset in search page
        containerAssetsPage.scrollToDown();

        // get asset list from DH ui
        List<String> assetIDsFromUI = containerAssetsPage.getAllAssetIDsOfAssetsShown();

        // Assert the counter from UI and counter from API Call
        assertTrue("Thumbs view is not active.", numberOfAssetsShowninUI == NumberOfAssetsFromAPIcall);

        // Assert the AssetsID's from UI and counter from API Call
        assertTrue("Thumbs view is not active.", apiResponse.checkAssetsList(assetIDsFromUI, assetsIDListFromApi));

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH Download functionality when SuperAdmin login
     *
     * -# @see loginAux()
     * -# Check the download
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH data when super login .", enabled = true)
    public void checkDowbloadWithSuperAdmin(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());
        int CountFromAPIcall = apiResponse
                .getAssetsCountDownloadedFormExportAPICall(UserDomain.SUPERADMIN, UserType.QA1, "download", "multiple");
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        MultiDownloadPage multiDownload = searchPage.goToMultiDownloadOfTheAssets(containerAssets.getCountOfSelected());

        assertTrue("MultiDownload modal is not ready.", multiDownload.isReady());

        // Accept the DRM.
        multiDownload.acceptDRM();

        // Click on Download button.
        multiDownload.clickOnDownloadButton();

        assertTrue("The after download message should be shown.", multiDownload.isAfterDownloadMessageShown());
        assertTrue("Download Counter not matched form API call to UI.", (apiResponse.counter == CountFromAPIcall));

        // Close the MultiDownload modal.
        multiDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH Download functionality when Defaultuser login
     *
     * -# @see loginAux()
     * -# Check the download
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH data when Defaultuser login .", enabled = true)
    public void checkDowbloadWithDefaultuser(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.DHAMTDEFAULTUSER, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());
        int CountFromAPIcall = apiResponse
                .getAssetsCountDownloadedFormExportAPICall(UserDomain.DHAMTDEFAULTUSER, UserType.QA1, "download", "multiple");
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        MultiDownloadPage multiDownload = searchPage.goToMultiDownloadOfTheAssets(containerAssets.getCountOfSelected());

        assertTrue("MultiDownload modal is not ready.", multiDownload.isReady());

        // Accept the DRM.
        multiDownload.acceptDRM();

        // Click on Download button.
        multiDownload.clickOnDownloadButton();

        assertTrue("The after download message should be shown.", multiDownload.isAfterDownloadMessageShown());
        assertTrue("Download Counter not matched form API call to UI.", (apiResponse.counter == CountFromAPIcall));

        // Close the MultiDownload modal.
        multiDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH Download functionality when SuperAdmin login
     *
     * -# @see loginAux()
     * -# Check the download
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH data when LDAP user login .", enabled = true)
    public void checkDowbloadWithLDAPUser(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.DHAMTDEFAULTUSER, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());
        int CountFromAPIcall = apiResponse
                .getAssetsCountDownloadedFormExportAPICall(UserDomain.DHAMTDEFAULTUSER, UserType.QA1, "download", "multiple");
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        MultiDownloadPage multiDownload = searchPage.goToMultiDownloadOfTheAssets(containerAssets.getCountOfSelected());

        assertTrue("MultiDownload modal is not ready.", multiDownload.isReady());

        // Accept the DRM.
        multiDownload.acceptDRM();

        // Click on Download button.
        multiDownload.clickOnDownloadButton();

        assertTrue("The after download message should be shown.", multiDownload.isAfterDownloadMessageShown());
        assertTrue("Download Counter not matched form API call to UI.", (apiResponse.counter == CountFromAPIcall));

        // Close the MultiDownload modal.
        multiDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH Download functionality when user login
     *
     * -# @see loginAux()
     * -# Check the download
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH data when default user login .", enabled = true)
    public void checkDowbloadWithUser(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SHAREDUSER, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());
        int CountFromAPIcall = apiResponse
                .getAssetsCountDownloadedFormExportAPICall(UserDomain.DHAMTDEFAULTUSER, UserType.QA1, "download", "multiple");
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        MultiDownloadPage multiDownload = searchPage.goToMultiDownloadOfTheAssets(containerAssets.getCountOfSelected());

        assertTrue("MultiDownload modal is not ready.", multiDownload.isReady());

        // Accept the DRM.
        multiDownload.acceptDRM();

        // Click on Download button.
        multiDownload.clickOnDownloadButton();

        assertTrue("The after download message should be shown.", multiDownload.isAfterDownloadMessageShown());
        assertTrue("Download Counter not matched form API call to UI.", (apiResponse.counter == CountFromAPIcall));

        // Close the MultiDownload modal.
        multiDownload.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH Folders data  functionality when SuperAdmin login
     *
     * -# @see loginAux()
     * -# Check the download
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH Folders data when DefaultUser login .", enabled = true)
    public void checkFoldersWithSuperAdmin(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());

        // GET assets LIST from OTMM through API CALL
        JsonArray foldersListFromApi = apiResponse
                .getFoldersListFromAPICall(UserDomain.SUPERADMIN, UserType.QA1, "folders");

        FoldersPage folderPage = new FoldersPage(DriverManager.getDriver());
        folderPage.clickOnFolderButton();
        folderPage.isReady();
        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two parent folders ", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be two parent folders ", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());
        FoldersSideBar publicFolderList = new FoldersSideBar(DriverManager.getDriver());
        publicFolderList.waitForReady();
        publicFolderList.isReady();
        List<String> publicFolders = publicFolderList.getPublicFoldersList();

        assertTrue("Both the folders should be same ", apiResponse.checkFolderList(publicFolders, foldersListFromApi));

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH folder data functionality when default user  login
     *
     * -# @see loginAux()
     * -# Check the download
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH Folders data when default user login .", enabled = true)
    public void checkFoldersWithDefaultUSer(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.DHAMTDEFAULTUSER, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());

        // GET assets LIST from OTMM through API CALL
        JsonArray foldersListFromApi = apiResponse
                .getFoldersListFromAPICall(UserDomain.DHAMTDEFAULTUSER, UserType.QA1, "folders");

        FoldersPage folderPage = new FoldersPage(DriverManager.getDriver());
        folderPage.clickOnFolderButton();
        folderPage.isReady();
        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two parent folders ", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be two parent folders ", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());
        FoldersSideBar publicFolderList = new FoldersSideBar(DriverManager.getDriver());
        publicFolderList.waitForReady();
        publicFolderList.isReady();
        List<String> publicFolders = publicFolderList.getPublicFoldersList();

        assertTrue("Both the folders should be same ", apiResponse.checkFolderList(publicFolders, foldersListFromApi));

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH folder data functionality when default user  login
     *
     * -# @see loginAux()
     * -# Check the download
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH Folders data when LDAP user login .", enabled = true)
    public void checkFoldersWithLDAPtUSer(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SHAREDUSER, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());

        // GET assets LIST from OTMM through API CALL
        JsonArray foldersListFromApi = apiResponse
                .getFoldersListFromAPICall(UserDomain.SHAREDUSER, UserType.QA1, "folders");

        FoldersPage folderPage = new FoldersPage(DriverManager.getDriver());
        folderPage.clickOnFolderButton();
        folderPage.isReady();
        // check there is a public folder in the folder tree and check for public folder
        FoldersSideBar foldersSideBar = new FoldersSideBar(DriverManager.getDriver());
        assertTrue("There should be two parent folders ", foldersSideBar.getNumOfFoldersSize() >= 2);
        assertTrue("There should be two parent folders ", foldersSideBar.isPublicFolderthere());

        // Expand all the folders
        foldersSideBar.clickOnAllExpandArrows();

        // check the folders are expanded.
        assertTrue("TC#OTMM_PC_Folders_008:All the root folders should be expanded.", foldersSideBar
                .isAllFoldersExpanded());
        FoldersSideBar publicFolderList = new FoldersSideBar(DriverManager.getDriver());
        publicFolderList.waitForReady();
        publicFolderList.isReady();
        List<String> publicFolders = publicFolderList.getPublicFoldersList();

        assertTrue("Both the folders should be same ", apiResponse.checkFolderList(publicFolders, foldersListFromApi));

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH  single Download functionality when SuperAdmin login
     *
     * -# @see loginAux()
     * -# Check the download
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH data when super login .", enabled = true)
    public void checkSingleDowbloadWithSuperAdmin(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SUPERADMIN, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());
        int CountFromAPIcall = apiResponse
                .getAssetsCountDownloadedFormExportAPICall(UserDomain.SUPERADMIN, UserType.QA1, "download", "Single");
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        MultiDownloadPage download = searchPage.goToMultiDownloadOfTheAssets(containerAssets.getCountOfSelected());

        assertTrue("MultiDownload modal is not ready.", download.isReady());

        // Accept the DRM.
        download.acceptDRM();

        // Click on Download button.
        download.clickOnDownloadButton();

        assertTrue("The after download message should be shown.", download.isAfterDownloadMessageShown());
        assertTrue("Download Counter not matched form API call to UI.", (apiResponse.counter == CountFromAPIcall));

        // Close the MultiDownload modal.
        download.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH single Download functionality when Shared user login
     *
     * -# @see loginAux()
     * -# Check the download
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH data when Shared user login .", enabled = true)
    public void checkSingleDowbloadWithSharedUser(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.DHAMTDEFAULTUSER, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());
        int CountFromAPIcall = apiResponse
                .getAssetsCountDownloadedFormExportAPICall(UserDomain.DHAMTDEFAULTUSER, UserType.QA1, "download", "Single");
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        MultiDownloadPage download = searchPage.goToMultiDownloadOfTheAssets(containerAssets.getCountOfSelected());

        assertTrue("MultiDownload modal is not ready.", download.isReady());

        // Accept the DRM.
        download.acceptDRM();

        // Click on Download button.
        download.clickOnDownloadButton();

        assertTrue("The after download message should be shown.", download.isAfterDownloadMessageShown());
        assertTrue("Download Counter not matched form API call to UI.", (apiResponse.counter == CountFromAPIcall));

        // Close the MultiDownload modal.
        download.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

    /**
     * Check DH single Download functionality when LDAP user login
     *
     * -# @see loginAux()
     * -# Check the download
     * -# @see logoutAux()
     * @throws IOException 
     * @throws ClientProtocolException 
     */
    @Test(description = "Check DH data when LDAP User login .", enabled = true)
    public void checkSingleDowbloadWithLDAPUser(Method method) throws ClientProtocolException, IOException {
        log.info("[log-TestSet] " + this.getClass().getName() + " - Start test method: " + method.getName());

        searchPage = loginAux(UserDomain.SHAREDUSER, UserType.QA1);

        // GET assets count from OTMM through API CALL
        DHApiResponse apiResponse = new DHApiResponse(DriverManager.getDriver());
        int CountFromAPIcall = apiResponse
                .getAssetsCountDownloadedFormExportAPICall(UserDomain.SHAREDUSER, UserType.QA1, "download", "Single");
        ContainerAssetsPage containerAssets = searchPage.getContainerAssets();

        MultiDownloadPage download = searchPage.goToMultiDownloadOfTheAssets(containerAssets.getCountOfSelected());

        assertTrue("MultiDownload modal is not ready.", download.isReady());

        // Accept the DRM.
        download.acceptDRM();

        // Click on Download button.
        download.clickOnDownloadButton();

        assertTrue("The after download message should be shown.", download.isAfterDownloadMessageShown());
        assertTrue("Download Counter not matched form API call to UI.", (apiResponse.counter == CountFromAPIcall));

        // Close the MultiDownload modal.
        download.close();

        logoutPage = logoutAux(searchPage.getHeader());

        log.info("[log-TestSet] " + this.getClass().getName() + " - End test method: " + method.getName());
    }

}
