/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.dto;

import java.util.ArrayList;
import java.util.List;

import com.opentext.utils.SectionType;

/**
 * Abstraction that represents an Section.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public class Section {

    /**
     * Components.
     */
    private String sectionPcId;
    private List<Subsection> subsections;
    private SectionType type;

    /**
     * Constructor.
     * @param sectionPcId to be used
     */
    public Section(String sectionPcId) {
        this.setSectionPcId(sectionPcId);
        subsections = new ArrayList<Subsection>();
    }

    /**
     * @return the sectionPcId
     */
    public synchronized String getSectionPcId() {
        return sectionPcId;
    }

    /**
     * It adds a subsection to the subsection list.
     * @param subsection to be added.
     */
    public synchronized void addSubsection(Subsection subsection) {
        this.subsections.add(subsection);

    }

    /**
     * @param sectionPcId the sectionPcId to set
     */
    public synchronized void setSectionPcId(String sectionPcId) {
        this.sectionPcId = sectionPcId;
    }

    /**
     * @return the subsections
     */
    public synchronized List<Subsection> getSubsections() {
        return subsections;
    }

    /**
     * @param subsections the subsections to set
     */
    public synchronized void setSubsections(List<Subsection> subsections) {
        this.subsections = subsections;
    }

    /**
     * @return the type
     */
    public synchronized SectionType getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public synchronized void setType(SectionType type) {
        this.type = type;
    }

}
