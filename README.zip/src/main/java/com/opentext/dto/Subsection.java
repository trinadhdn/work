/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.dto;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.opentext.utils.SectionType;

/**
 * Abstraction that represents an Subsection.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public class Subsection {

    /**
     * Components.
     */
    protected String subsectionPcId;
    protected CopyOnWriteArrayList<Subsection> subsectionTabs;
    protected SectionType type;

    /**
     * Constructor.
     * @param subsectionPcId to be used
     */
    public Subsection(String subsectionPcId) {
        this.setSubsectionPcId(subsectionPcId);
        subsectionTabs = new CopyOnWriteArrayList<Subsection>();
    }

    /**
     * @return the subsectionPcId
     */
    public String getSubsectionPcId() {
        return subsectionPcId;
    }

    /**
     * @param subsectionPcId the subsectionPcId to set
     */
    public synchronized void setSubsectionPcId(String subsectionPcId) {
        this.subsectionPcId = subsectionPcId;
    }

    /**
     * @return the subsectionTabs
     */
    public synchronized List<Subsection> getSubsectionTabs() {
        return subsectionTabs;
    }

    /**
     * @param subsectionTabs the subsectionTabs to set
     */
    public synchronized void setSubsectionTabs(CopyOnWriteArrayList<Subsection> subsectionTabs) {
        this.subsectionTabs = subsectionTabs;
    }

    /**
     * @return the type
     */
    public synchronized SectionType getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(SectionType type) {
        this.type = type;
    }

    /**
     * It adds a subsection to this subsection (like a tab).
     * @param subsection to be added.
     */
    public void addSubsectionTabs(Subsection subsection) {
        this.subsectionTabs.add(subsection);

    }

}
