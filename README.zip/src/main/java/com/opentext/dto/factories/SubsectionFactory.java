/**
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.dto.factories;

import java.util.List;

import com.opentext.dto.Subsection;
import com.opentext.utils.SectionType;

/**
 * Factory that builds the @see Subsection and add its @see Subsection (tabs) if necessary.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public abstract class SubsectionFactory {

    /**
     * It retrieves a {@link Subsection} instance depending on the provided pc-id.
     * @param pc-id.
     * @return a {@link Subsection}.
     */
    public static Subsection buildSubsection(String pcid) {
        Subsection subsection = new Subsection(pcid);
        subsection.setType(getSectionTypeFromId(pcid));
        return subsection;
    }

    /**
     * It retrieves a {@link Subsection} instance depending on the provided pc-id, also the subsectionTabs.
     * @param pc-id.
     * @param subtabs
     * @return a {@link Subsection}.
     */
    public static Subsection buildSubsection(String pcid, List<String> subtabs) {
        Subsection subsection = buildSubsection(pcid);

        for (String subtab : subtabs) {
            Subsection subsectiontab = buildSubsection(subtab);
            subsectiontab.setType(getSectionTypeFromId(subtab));
            subsection.addSubsectionTabs(subsectiontab);
        }

        return subsection;
    }

    /**
     * Method to compare and get the proper type using the pc-id.
     * @param pc-id of the Subsection.
     * @return {@link SectionType}
     */
    private static SectionType getSectionTypeFromId(String id) {
        SectionType type = null;
        for (SectionType typeValue : SectionType.values()) {
            if (id.trim().equalsIgnoreCase(typeValue.getType().trim())) {
                type = typeValue;
            }
        }
        return type;
    }

}
