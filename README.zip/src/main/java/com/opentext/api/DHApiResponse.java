package com.opentext.api;

import static org.testng.AssertJUnit.assertTrue;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.UserFactory;
import com.opentext.utils.UserTest;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * Class to read the properties files
 * 
 * @author Trinadh Nakka<tnakka@opentext.com>
 * @author Mavya Papishetty<mpapishe@opentext.com>
 */

public class DHApiResponse extends PCBasePage {

    public DHApiResponse(EmergyaWebDriver driver) {
        super(driver);
        // TODO Auto-generated constructor stub
    }

    public static String otmmIP;
    public static String otmmPort;
    public int counter;
    public int folderID;
    String folderName = "-" + new Date().getTime();

    /**
     * Get List of assets from API call:
     * @return list of assets from api
     *   
     */

    public JsonArray getAssetsListFromAPICall(UserDomain userDomain, UserType userType, String apiCallName)
            throws ClientProtocolException, IOException {

        JsonArray array = null;

        CloseableHttpResponse searchResponse = this.apiCall(userDomain, userType, apiCallName);

        array = this.getJsonArrayData(searchResponse, "asset_id_list");

        return array;

    }

    /**
     * Get List of folders from API call:
     * @return list of folders from api
     *   
     */

    public JsonArray getFoldersListFromAPICall(UserDomain userDomain, UserType userType, String apiCallName)
            throws ClientProtocolException, IOException {

        JsonArray array = null;

        CloseableHttpResponse foldersResponse = this.apiCall(userDomain, userType, apiCallName);

        array = this.getJsonArrayFoldersData(foldersResponse, "name");

        return array;

    }

    /**
     * Get count of asserts from API call:
     * @return list of assets from api
     *   
     */

    public int getTotalAssetsCountFromAPICall(UserDomain userDomain, UserType userType, String apiCallName)
            throws ClientProtocolException, IOException {

        int counter = 0;

        CloseableHttpResponse response = this.apiCall(userDomain, userType, apiCallName);

        counter = this.getJsonIntegerData(response, "total_hit_count");

        return counter;

    }

    /**
     * Get jobid for the download api call
     * @return jobid
     *   
     */

    public int getAssetsCountDownloadedFormExportAPICall(UserDomain userDomain, UserType userType, String apiCallName,
            String downloadType) throws ClientProtocolException, IOException {

        int counter = 0;

        CloseableHttpResponse response = this.downloadapiCall(userDomain, userType, apiCallName, downloadType);
        counter = this.getJobResponceData(response, "exportable_count");

        return counter;

    }

    /**
     * create a flder testing
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     * @return folder name
     * @throws IOException 
     * @throws ClientProtocolException 
     *   
     */
    public String createFolderApi(UserDomain userDomain, UserType userType, String apiCallName)
            throws ClientProtocolException, IOException {

        CloseableHttpResponse response = this.apiCall(userDomain, userType, apiCallName);
        assertTrue("The response code should be 200OK.", response.getStatusLine().getStatusCode() == 200);

        return folderName;
    }

    /* *//**
         * delete a flder testing
         * @author Sowjanya Lankadasu <slankada@opentext.com>
         * @return folder name
         * @throws IOException 
         * @throws ClientProtocolException 
         *   
         *//*
           public String deleteFolderApi(UserDomain userDomain, UserType userType, String apiCallName, String downloadtype)
                throws ClientProtocolException, IOException {
           
            CloseableHttpResponse response = this.apiCall(userDomain, userType, apiCallName);
            assertTrue("The response code should be 200OK.", response.getStatusLine().getStatusCode() == 200);
           
            return folderName;
           }*/

    /**
     * Check the Login action:
     * @return API url
     * -# To get API url 
     *  
     */

    public String getAPIUrl(UserDomain userDomain, UserType userType, String apiCall) throws IOException {

        UserTest user = UserFactory.getUser(userDomain, userType);

        String url = null;
        String username = user.getUsername();
        String password = user.getPassword();

        String properties = "test.properties";
        Properties prop = new Properties();

        // Load a properties file
        ClassLoader loader = Thread.currentThread().getContextClassLoader();

        prop.load(loader.getResourceAsStream(properties));

        // Get the property value
        otmmIP = prop.getProperty("otmmEnvironmentIP");
        otmmPort = prop.getProperty("otmmEnvironmentPort");

        if (apiCall.equalsIgnoreCase("sessionCreation")) {

            url = "http://" + otmmIP + ":" + otmmPort + "/otmmapi/v3/sessions?username=" + username + "&password="
                    + password;

        } else if (apiCall.equalsIgnoreCase("search")) {

            url = "http://" + otmmIP + ":" + otmmPort + "/otmmapi/v4/search/text";
        } else if (apiCall.equalsIgnoreCase("download")) {

            url = "http://" + otmmIP + ":" + otmmPort + "/otmmapi/v4/jobs/exports";
        } else if (apiCall.equalsIgnoreCase("createFolder")) {

            url = "http://" + otmmIP + ":" + otmmPort + "/otmmapi/v4/folders/ARTESIA.PUBLIC.TREEN";
        } else if (apiCall.equalsIgnoreCase("folders")) {

            url = "http://" + otmmIP + ":" + otmmPort + "/otmmapi/v4/folders/ARTESIA.PUBLIC.TREEN/folders";
        }
        return url;

    }

    /**
     * Check the Login action:
     * @return array
     * -# To get json array with data
     *  
     */

    public JsonArray getJsonArrayData(CloseableHttpResponse response, String dataString)
            throws ClientProtocolException, IOException {

        int responseCode = response.getStatusLine().getStatusCode();

        JsonArray array = new JsonArray();

        try {
            if (responseCode == 200)

            {

                Reader reader = new InputStreamReader(response.getEntity().getContent());
                JsonParser parser = new JsonParser();

                JsonObject objJsonObject = parser.parse(reader).getAsJsonObject();

                JsonObject pages = objJsonObject.getAsJsonObject("search_result_resource")
                        .getAsJsonObject("search_result");

                for (Map.Entry<String, JsonElement> entry : pages.entrySet()) {

                    if (!entry.getValue().isJsonNull()) {
                        JsonElement e = entry.getValue();

                        if (entry.toString().contains(dataString)) {

                            array = e.getAsJsonArray();
                        }
                    }
                }

            }

        } catch (Exception ex) {
            System.out.println(ex);
        }
        return array;
    }

    /**
     * Check the Login action:
     * @return array
     * -# To get json array with folders data
     *  
     */

    public JsonArray getJsonArrayFoldersData(CloseableHttpResponse response, String dataString)
            throws ClientProtocolException, IOException {

        int responseCode = response.getStatusLine().getStatusCode();

        JsonArray array = new JsonArray();

        try {
            if (responseCode == 200)

            {
                Reader reader = new InputStreamReader(response.getEntity().getContent());
                JsonParser parser = new JsonParser();
                JsonObject objJsonObject = parser.parse(reader).getAsJsonObject();
                JsonObject pages = objJsonObject.getAsJsonObject("folders_resource");
                for (Entry<String, JsonElement> entryMap : pages.entrySet()) {
                    for (JsonElement jsonEntryData : entryMap.getValue().getAsJsonArray()) {
                        for (Entry<String, JsonElement> jsonEntrySet : jsonEntryData.getAsJsonObject().entrySet()) {
                            if (jsonEntrySet.getKey().toString().equalsIgnoreCase(dataString)) {
                                String foldername = jsonEntrySet.getValue().toString().replace("\"", "");
                                array.add(foldername);
                                break;

                            }
                        }
                    }
                }
            }

        } catch (

        Exception ex) {
            System.out.println(ex);
        }
        return array;
    }

    /**
     * Check the Login action:
     * @return counter
     * -# To get json array with data
     *  
     */

    public int getJsonIntegerData(CloseableHttpResponse response, String data)
            throws ClientProtocolException, IOException {

        int responseCode = response.getStatusLine().getStatusCode();

        int count = 0;

        try {
            if (responseCode == 200)

            {

                Reader reader = new InputStreamReader(response.getEntity().getContent());
                JsonParser parser = new JsonParser();

                JsonObject objJsonObject = (JsonObject) parser.parse(reader);

                JsonObject pages = objJsonObject.getAsJsonObject("search_result_resource")
                        .getAsJsonObject("search_result");

                for (Map.Entry<String, JsonElement> entry : pages.entrySet()) {

                    if (!entry.getValue().isJsonNull()) {
                        JsonElement jsonEle = entry.getValue();

                        if (entry.toString().contains(data)) {

                            count = jsonEle.getAsInt();
                        }
                    }
                }

            }

        } catch (Exception ex) {
            System.out.println(ex);
        }
        return count;
    }

    /**
     * @return Job api call data
     * -# To get Job api call data
     *  
     */

    public int getJobResponceData(CloseableHttpResponse response, String data)
            throws ClientProtocolException, IOException {

        int responseCode = response.getStatusLine().getStatusCode();

        int count = 0;
        Reader reader = new InputStreamReader(response.getEntity().getContent());
        JsonParser parser = new JsonParser();

        JsonObject objJsonObject = (JsonObject) parser.parse(reader);

        try {
            if (responseCode == 200)

            {

                if (!objJsonObject.getAsJsonObject("export_job_handle").getAsJsonObject("export_response")
                        .isJsonNull()) {

                    JsonObject pages = objJsonObject.getAsJsonObject("export_job_handle")
                            .getAsJsonObject("export_response");

                    for (Map.Entry<String, JsonElement> entry : pages.entrySet()) {

                        if (!entry.getValue().isJsonNull()) {
                            JsonElement jsonEle = entry.getValue();

                            if (entry.toString().contains(data)) {

                                count = jsonEle.getAsInt();
                                break;
                            }
                        }
                    }
                }
            } else if (responseCode == 500) {

                JsonObject pages = objJsonObject.getAsJsonObject("exception_body");

                for (Map.Entry<String, JsonElement> entry : pages.entrySet()) {

                    if (!entry.getValue().isJsonNull()) {
                        JsonElement jsonEle = entry.getValue();

                        if (entry.toString().equalsIgnoreCase("http_response_code")) {

                            return count;
                        }
                    }
                }
            }

        } catch (Exception ex) {
            System.out.println(ex);
        }
        return count;
    }

    /**
     * To get te apicall data:
     * @return Responce
     * -# Tp get api responce 
     *  
     */

    public CloseableHttpResponse apiCall(UserDomain userDomain, UserType userType, String apiCallName)
            throws ClientProtocolException, IOException {

        // client
        CloseableHttpClient client = HttpClients.createDefault();

        // Session creation with user
        String SessionUrl = this.getAPIUrl(userDomain, userType, "sessionCreation");

        HttpPost sessionRequest = new HttpPost(SessionUrl);
        sessionRequest.addHeader("Content-Type", "application/x-www-form-urlencoded");
        CloseableHttpResponse sessionResponse = client.execute(sessionRequest);

        CloseableHttpResponse response = null;
        int SessionresponseCode = sessionResponse.getStatusLine().getStatusCode();

        if (SessionresponseCode == 200) {

            if (apiCallName.equalsIgnoreCase("search")) {
                // Making search api call to OTMM
                String url = this.getAPIUrl(userDomain, userType, "search");

                HttpPost searchrequest = new HttpPost(url);

                searchrequest.addHeader("folder_filter", "ARTESIA.PUCLIC.TREEN");
                searchrequest.addHeader("foler_filter_type", "all");
                searchrequest.addHeader("latest_version", "true");

                ArrayList<NameValuePair> postParameters;

                postParameters = new ArrayList<NameValuePair>();
                postParameters.add(new BasicNameValuePair("keyword_query", "*"));
                postParameters.add(new BasicNameValuePair("search_config_id", "3"));
                postParameters.add(new BasicNameValuePair("keyword_scope_id", "3"));

                searchrequest.setEntity(new UrlEncodedFormEntity(postParameters, "UTF-8"));

                response = client.execute(searchrequest);

            } else if (apiCallName.equalsIgnoreCase("createFolder")) {

                // Making search api call to OTMM
                String url = this.getAPIUrl(userDomain, userType, "createFolder");

                HttpPost createfolder = new HttpPost(url);

                createfolder.addHeader("Content-Type", "application/json");

                StringEntity params = new StringEntity("{\"folder_resource\":{\"folder\":{\"name\":" + folderName
                        + ",\"container_type_id\":\"ARTESIA.BASIC.FOLDER\",\"security_policy_list\":[{\"id\":1}],\"metadata\":{\"metadata_element_list\":[]},\"metadata_model_id\":\"ARTESIA.MODEL.BASIC FOLDER\"}}}");
                createfolder.setEntity(params);

                response = client.execute(createfolder);

            } else if (apiCallName.equalsIgnoreCase("folders")) {

                String url = this.getAPIUrl(userDomain, userType, "folders");

                HttpGet folderRequest = new HttpGet(url);

                folderRequest.addHeader("Content-Type", "application/json");

                response = client.execute(folderRequest);

            }
        }
        return response;
    }

    /**
     * To get te apicall data:
     * @return Responce
     * -# Tp get api responce 
     *  
     */

    public CloseableHttpResponse downloadapiCall(UserDomain userDomain, UserType userType, String apiCallName,
            String downloadType) throws ClientProtocolException, IOException {

        // client
        CloseableHttpClient client = HttpClients.createDefault();

        // Session creation with user
        String SessionUrl = this.getAPIUrl(userDomain, userType, "sessionCreation");

        HttpPost sessionRequest = new HttpPost(SessionUrl);
        sessionRequest.addHeader("Content-Type", "application/x-www-form-urlencoded");
        CloseableHttpResponse sessionResponse = client.execute(sessionRequest);

        CloseableHttpResponse response = null;
        int SessionresponseCode = sessionResponse.getStatusLine().getStatusCode();

        if (SessionresponseCode == 200) {

            if (apiCallName.equalsIgnoreCase("download")) {

                // Making search api call to OTMM
                String url = this.getAPIUrl(userDomain, userType, "download");

                HttpPost downloadrequest = new HttpPost(url);

                List assetIDS = this.getAssetIDFromUI(downloadType);

                downloadrequest.addHeader("Content-Type", "application/x-www-form-urlencoded");

                ArrayList<NameValuePair> postParameters;

                postParameters = new ArrayList<NameValuePair>();

                postParameters.add(new BasicNameValuePair("selection_context",
                        "{\"selection_context_param\":{\"selection_context\":{\"asset_ids\":" + assetIDS
                                + ",\"asssetContentType\":[],\"type\":\"com.artesia.asset.selection.AssetIdsSelectionContext\",\"include_descendants\":\"ALL\",\"child_type\":\"ASSETS_AND_CONTAINERS\",\"include_deleted_assets\":false}}}"));
                postParameters.add(new BasicNameValuePair("export_contents", "assets_and_metadata"));
                postParameters.add(new BasicNameValuePair("job_name", "export"));
                postParameters.add(new BasicNameValuePair("export_request",
                        "{\"export_request_param\":{\"export_request\":{\"content_request\":{\"export_master_content\":true,\"export_preview_content\":true},\"error_handling_action\":\"DEFAULT_HANDLING\",\"export_job_transformers\":[{\"transformer_id\":\"ARTESIA.TRANSFORMER.ZIP COMPRESSION.DEFAULT\",\"arguments\":[null,\"Download.zip\"]}],\"preserve_folder_hierarchy\":false,\"delivery_template\":{\"attribute_values\":[{\"argument_number\":4,\"value\":\"N\"}],\"id\":\"ARTESIA.TRANSFORMER.PROFILE.DOWNLOAD.DEFAULT\",\"transformer_id\":\"ARTESIA.TRANSFORMER.PROFILE.DOWNLOAD\"},\"write_xml\":true,\"write_csv\":false}}}"));

                downloadrequest.setEntity(new UrlEncodedFormEntity(postParameters, "UTF-8"));

                response = client.execute(downloadrequest);

            }
        }
        return response;
    }

    /**
     * Method to Compare  list and JsonArray
    */
    public boolean checkAssetsList(List<String> list1, JsonArray assetsFromApi) {

        boolean isListEqual = false;
        for (String parentloop : list1) {

            for (JsonElement child : assetsFromApi) {
                isListEqual = false;

                if (parentloop.contains(child.getAsString())) {
                    isListEqual = true;
                    break;
                }

            }
            if (isListEqual == false) {
                break;
            }

        }

        return isListEqual;
    }

    /**
     * Method to Compare Folder list and JsonArray
    */
    public boolean checkFolderList(List<String> list1, JsonArray assetsFromApi) {

        boolean isListEqual = false;

        for (String parentloop : list1) {
            for (JsonElement child : assetsFromApi) {
                isListEqual = false;
                if ((child.getAsString()).contains(parentloop)) {
                    isListEqual = true;

                    break;
                }

            }
            if (isListEqual == false) {
                break;
            }

        }

        return isListEqual;
    }

    /**
     * Method to get assetIDs from list 
    */
    public List getAssetIDFromUI(String downloadType) {

        ContainerAssetsPage containerAssets = new ContainerAssetsPage(driver);

        ContainerAssetsPage assets = new ContainerAssetsPage(driver, true, containerAssets.getNumberOfAssetsShown());

        List assetIDs = assets.getAssetIDSForDownload(downloadType);

        counter = assetIDs.size();

        return assetIDs;
    }

    /**
     * 
     *Method to get asset ID for a single asset
     *
     */
    public String getAssetIDOfSingleAssetFromUI() {

        ContainerAssetsPage containerAssets = new ContainerAssetsPage(driver);

        String assetID = containerAssets.getAssetID(1);

        return assetID;
    }

    @Override
    public void waitForReady() {
        // TODO Auto-generated method stub

    }

    @Override
    public boolean isReady() {
        // TODO Auto-generated method stub
        return false;
    }
}