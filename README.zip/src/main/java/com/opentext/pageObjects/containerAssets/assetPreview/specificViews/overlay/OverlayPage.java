/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.containerAssets.assetPreview.specificViews.overlay;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.assetDetails.AssetDetailsPage;
import com.opentext.pageObjects.singleDownload.specificModal.SingleDownloadPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.AssetCategoryValues.AssetType;

/**
 * This PO contains the methods to interact with the assets' Overlay in the Thumbs view.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class OverlayPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(OverlayPage.class);

    /**
     * Items keys selectors.
     */
    private final static String TITLE = "title";
    private final static String COUNTERS = "counters";
    private final static String FIELDS = "fields";
    private final static String DATAS = "datas";

    private final static String DOWNLOAD_BUTTON = "download";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public OverlayPage(EmergyaWebDriver driver) {
        super(driver);
        // this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 3; i++) {

            if (this.isElementVisibleByXPath(TITLE) && this.isElementVisibleByXPath(COUNTERS)
                    && this.isElementVisibleByXPath(FIELDS) && this.isElementVisibleByXPath(DATAS)
                    && this.isElementVisibleByXPath(DOWNLOAD_BUTTON)) {
                isReady = true;
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(TITLE);
        this.waitForByXPath(COUNTERS);
        this.waitForByXPath(FIELDS);
        this.waitForByXPath(DATAS);
        this.waitForByXPath(DOWNLOAD_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to perform a click on the Blue download button.
     * @return SingleDownload modal ready to work with.
     */
    public synchronized SingleDownloadPage clickOnBlueDownloadButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnBlueDownloadButton method");

        if (this.retryAndGetElementsByXPath(DOWNLOAD_BUTTON)) {
            this.waitUntilElementClickableByXPath(DOWNLOAD_BUTTON);
            this.retryAndGetElementByXPath(DOWNLOAD_BUTTON);
            this.getElementByXPath(DOWNLOAD_BUTTON).click();
            this.waitUntilDisappearByXPath(SPINNER);
        }

        SingleDownloadPage singleDownload = new SingleDownloadPage(driver);
        singleDownload.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnBlueDownloadButton method");

        return singleDownload;
    }

    /**
     * Method to perform a click on the Title.
     * @param The category of the asset.
     * @return AssetDetailsPage modal ready to work with.
     */
    public synchronized AssetDetailsPage clickOnTitle(AssetType assetType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnTitle method");

        this.getElementByXPath(TITLE).click();
        this.waitUntilDisappearByXPath(SPINNER);

        AssetDetailsPage assetDetails = new AssetDetailsPage(driver, assetType);
        assetDetails.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnTitle method");

        return assetDetails;
    }

}
