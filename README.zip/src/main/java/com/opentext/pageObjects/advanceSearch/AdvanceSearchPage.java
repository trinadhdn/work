/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.advanceSearch;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.search.SearchPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the AdvanceSearch component.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class AdvanceSearchPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(AdvanceSearchPage.class);

    /**
     * Items keys selectors.
     */
    private final static String ADVANCE_SEARCH_BUTTON = "//div/cpath";
    private final static String COUNTER = "advanceButtonCounter";

    private final static String PANEL = "panel";

    private final static String DATE_FILTER_SELECT = "dateFilterSelect";
    private final static String DATE_FILTER_OPTIONS = "dateFilterOptions";
    private final static String FROM_INPUT = "fromInput";
    private final static String TO_INPUT = "toInput";
    private final static String RESET_BUTTON = "resetButton";

    private final static String ASSET_TYPE_OPTIONS = "assetTypeOptions";
    private final static String TAGS_ASSET_TYPE = "tagAssetType";
    private final static String X_BTN_TAGS_ASSET_TYPE = "xButtonTagAssetType";

    private final static String ADVSEARCH_SPINNER = "advsearchSpinner";

    /**
     * Components
     */
    private volatile boolean isOpen;

    /**
     * Constructor method
     * 
     * @param driver
     *            selenium webdriver
     */
    public AdvanceSearchPage(EmergyaWebDriver driver) {
        super(driver);
        this.isOpen = this.isAdvanceSearchOpen();
        this.isReady();
    }
    
  
    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (this.retryAndGetElementByXPath(ADVANCE_SEARCH_BUTTON)) {
            isReady = true;
            if (this.isOpen) {
                if (this.isElementVisibleByXPath(DATE_FILTER_SELECT) && this.isElementVisibleByXPath(RESET_BUTTON)) {
                    isReady = true;
                    if (this.getAssetTypeFilterSize() > 0) {
                        // If there are any asset type we check that we have any
                        // asset type.
                        if (this.isElementVisibleByXPath(ASSET_TYPE_OPTIONS)) {
                            isReady = true;
                        } else {
                            isReady = false;
                        }
                    }
                }
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(ADVANCE_SEARCH_BUTTON);
        if (this.isOpen) { // If is opened the components should be waited.
            this.waitForByXPath(DATE_FILTER_SELECT);
            this.waitForByXPath(RESET_BUTTON);
            this.waitForByXPath(ASSET_TYPE_OPTIONS);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return true if the panel is open, false if it is closed.
     */
    public synchronized boolean isAdvanceSearchOpen() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isAdvanceSearchOpen method");

        boolean isOpen = false;
        try {
            if (!(this.getElementByXPath(PANEL).getAttribute("class").contains("toggled"))) {
                isOpen = true;
            }
        } catch (Exception e) {
            isOpen = false;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isAdvanceSearchOpen method");

        return isOpen;
    }

    /**
     * Method to open the panel of the AdvanceSearch component.
     */
    public synchronized void open() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start open method");

        if (!this.isAdvanceSearchOpen()) {

            this.getElementByXPath(ADVANCE_SEARCH_BUTTON).click();
            this.isOpen = true;
            this.waitForReady();
        }
        assertTrue("AdvanceSearch component is not open.", this.isAdvanceSearchOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End open method");
    }

    /**
     * Method to close the panel of the AdvanceSearch component.
     */
    public synchronized void close() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");

        if (this.isAdvanceSearchOpen()) {
            this.getElementByXPath(ADVANCE_SEARCH_BUTTON).click();
            this.isOpen = false;
            this.waitForReady();
        }
        assertTrue("AdvanceSearch component is not collapsed.", !this.isAdvanceSearchOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
    }

    /**
     * @return the number of options in the DateFilter select.
     */
    public synchronized int getDateFilterSize() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getDateFilterSize method");

        int size = 0;
        for (int i = 0; i <= 5; i++) {
            if (this.getElementsByXPath(DATE_FILTER_OPTIONS).size() != 0) {
                size = this.getElementsByXPath(DATE_FILTER_OPTIONS).size();
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getDateFilterSize method");

        return size;

    }

    /**
     * @return if the "From" and "To" input fields are shown.
     */
    private synchronized boolean areFromAndToFieldsShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start areFromAndToFieldsShown method");

        boolean areShown = false;
        if (this.isElementVisibleByXPath(FROM_INPUT) && this.isElementVisibleByXPath(TO_INPUT)) {
            areShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End areFromAndToFieldsShown method");

        return areShown;
    }

    /**
     * @return boolean
     * @param name
     *            of asset type
     */
    public synchronized boolean isAssetTypeListShowningOnlyFilterData(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getAssetTypeList method");

        this.waitForByXPath(ASSET_TYPE_OPTIONS);
        List<String> assetsList = this.getListForAttribute(ASSET_TYPE_OPTIONS, "title");

        SearchPage search = new SearchPage(driver, null);
        int totalAssetCountShown = search.getCounterAssets();
        boolean isShown = true;

        for (String asset : assetsList) {

            if (!(asset.contains(name)) || !(asset.contains(Integer.toString(totalAssetCountShown)))) {

                isShown = false;
            }

        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End areFromAndToFieldsShown method");

        return isShown;

    }

    /**
     * Method to select the date filter option:
     * 
     * @param containerAssets
     *            for re-charging.
     * @param option
     *            to select.
     */
    public synchronized void selectDateFilter(ContainerAssetsPage containerAssets, int dateFilter) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectDateFilter method");

        // Select the date filter option.
        if (dateFilter == this.getDateFilterSize() - 1) {
            // action.moveToElement(this.getElementByXPath(DATE_FILTER_SELECT)).click().perform();
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("document.getElementById('advanced_search_date_filter').getElementsByTagName('option')[3].selected = 'selected';");
            js.executeScript("$('#advanced_search_date_filter_panel').show();");
        } else {
            Select select = new Select(this.getElementByXPath(DATE_FILTER_SELECT));
            select.selectByIndex(dateFilter);
        }

        this.scrollTop();
        this.driver.sleep(1);
        // If the "or specify" option is selected the "From" and "To" input
        // fields should be shown.
        // if (select.getFirstSelectedOption().getText().contains("specif")) {
        if (dateFilter == this.getDateFilterSize() - 1) {
            assertTrue("The 'From' and 'To' input fields aren't shown.", this.areFromAndToFieldsShown());
            this.fillFromAndToInputs("01/07/2017", "31/12/2017"); // Template:
                                                                  // 01/12/2016
        }

        // Re-charge the container of the assets.
        containerAssets.initializeList();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectDateFilter method");
    }

    /**
     * Method to fill the "From" and "To" input fields.
     * 
     * @param Date
     *            to fill the "From" input.
     * @param Date
     *            to fill the "To" input.
     */
    private synchronized void fillFromAndToInputs(String fromDate, String toDate) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillFromAndToInputs method");

        JavascriptExecutor js = (JavascriptExecutor) driver;
        // Fill the "From" input.
        js.executeScript("document.getElementById('fromDate').focus()");
        js.executeScript("document.getElementById('fromDate').value='" + fromDate + "'");
        this.driver.sleep(1);
        // Fill the "To" input.
        js.executeScript("document.getElementById('toDate').focus()");
        js.executeScript("document.getElementById('toDate').value='" + toDate + "'");

        // To perform the search.
        js.executeScript("$(selectors.search.searchButton).trigger('click')");
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillFromAndToInputs method");
    }

    /**
     * Method to reset the Date filters.
     * 
     * @param containerAssets
     *            for re-charging.
     */
    public synchronized void clickOnResetButton(ContainerAssetsPage containerAssets) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnResetButton method");

        this.scrollTo(this.getElementByXPath(RESET_BUTTON));
        this.waitUntilElementClickableByXPath(RESET_BUTTON);
        this.driver.sleep(4);
        this.getElementByXPath(RESET_BUTTON).click();
        this.scrollTop();
        this.driver.sleep(1);

        // Re-charge the container of the assets.
        containerAssets.initializeList();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnResetButton method");
    }

    /**
     * @return the number of options in the AssetType component.
     */
    public synchronized int getAssetTypeFilterSize() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getAssetTypeFilterSize method");

        int size = this.getElementsByXPath(ASSET_TYPE_OPTIONS, 1).size();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAssetTypeFilterSize method");

        return size;
    }

    /**
     * Method to select a AssetType option by index.
     * 
     * @param containerAssets
     *            for re-charging.
     * @param index
     *            of the option to select.
     * @return counter of assets shown in the AssetType.
     */
    public synchronized int selectAssetType(ContainerAssetsPage containerAssets, Integer typeFilter) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAssetType method");
        int counter = Integer.parseInt(this.getElementsByXPath(ASSET_TYPE_OPTIONS).get(typeFilter).getAttribute("title")
                .replaceAll("[^0-9]", "").trim());
        this.waitUntilDisappearByXPath(SPINNER);
        this.scrollTo(this.getElementByXPath(ASSET_TYPE_OPTIONS));

        this.getElementsByXPath(ASSET_TYPE_OPTIONS).get(typeFilter).click();
        this.driver.sleep(1);
        this.waitUntilDisappearByXPath(ADVSEARCH_SPINNER);
        this.waitForByXPath(TAGS_ASSET_TYPE);
        this.waitForByXPath(X_BTN_TAGS_ASSET_TYPE);
        this.waitForByXPath(COUNTER);

        // Re-charge the container of the assets.
        containerAssets.initializeList();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAssetType method");

        return counter;
    }

    /**
     * Method to select a AssetType option by text.
     * 
     * @param containerAssets
     *            for re-charging.
     * @param text
     *            of the option to select.
     * @return counter of assets shown in the AssetType.
     */
    public synchronized Integer selectAssetType(ContainerAssetsPage containerAssets, String typeFilter) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAssetType method");

        Integer index = 0;
        boolean found = false;
        while (!found && index < this.getAssetTypeFilterSize()) {

            if (this.getElementsByXPath(ASSET_TYPE_OPTIONS).get(index).getAttribute("title").replaceAll("\\P{L}+", "")
                    .equalsIgnoreCase(typeFilter)) {
                found = true;
            } else {
                index++;
            }
        }
        if (!found) {
            index = null;
        }

        int counter = this.selectAssetType(containerAssets, index);
        assertTrue("Unable to find the filter - " + typeFilter
                + ".Please check the advanced search facets.", index != null);
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAssetType method");

        return counter;
    }

    /**
     * @return if the Tag and the Counter are shown.
     */
    public boolean areTagAndCounterShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start areTagAndCounterShown method");

        boolean areShown = false;
        for (int i = 0; i <= 3; i++) {
            if (this.isElementVisibleByXPath(TAGS_ASSET_TYPE) && this.isElementVisibleByXPath(X_BTN_TAGS_ASSET_TYPE)
                    && this.isElementVisibleByXPath(COUNTER)) {
                areShown = true;
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End areTagAndCounterShown method");

        return areShown;
    }

    /**
     * Method to remove the AssetType filter.
     * 
     * @param containerAssets
     *            for re-charging.
     */
    public void removeAssetTypeFilter(ContainerAssetsPage containerAssets) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start removeAssetTypeFilter method");

        if (this.areTagAndCounterShown()) {

            WebElement xButton = this.getElementByXPath(X_BTN_TAGS_ASSET_TYPE);
            if (!xButton.isDisplayed()) {
                this.scrollTo(xButton);
                this.driver.sleep(1);
            }

            xButton.click();
            this.scrollTop();
            this.waitUntilDisappearByXPath(ADVSEARCH_SPINNER);
            this.driver.sleep(1);

            // Re-charge the container of the assets.
            containerAssets.initializeList();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End removeAssetTypeFilter method");
    }

}
