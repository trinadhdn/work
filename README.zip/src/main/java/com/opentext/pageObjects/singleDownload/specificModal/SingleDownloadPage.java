/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.singleDownload.specificModal;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.singleDownload.DownloadModalPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the SingleDownload modal.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class SingleDownloadPage extends DownloadModalPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(SingleDownloadPage.class);

    /**
     * Items keys selectors.
     */
    private final static String FILENAME = "filename";
    private final static String PREVIEW = "preview";
    private final static String DOWNLOAD_LINK = "downloadLink";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public SingleDownloadPage(EmergyaWebDriver driver) {
        super(driver);
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && this.isElementVisibleByXPath(FILENAME) && this.isElementVisibleByXPath(PREVIEW)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        this.waitForByXPath(FILENAME);
        this.waitForByXPath(PREVIEW);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to perform a click on Download button.
     */
    public void clickOnDownloadButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnDownloadButton method");

        this.getElementByXPath(DOWNLOAD_BUTTON).click();
        this.waitForByXPath(DOWNLOAD_MESSAGE);

        if (this.isDrmAccepted) {
            this.waitForByXPath(DOWNLOAD_LINK);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnDownloadButton method");
    }

    /**
     * @return if the after download message & link is shown or not.
     */
    public boolean isAfterDownloadMessageAndLinkShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isAfterDownloadMessageShown method");

        boolean isShown = false;
        if (this.isElementVisibleByXPath(DOWNLOAD_MESSAGE, 5) && this.isElementVisibleByXPath(DOWNLOAD_LINK, 5)) {
            if (this.getElementByXPath(DOWNLOAD_MESSAGE).getAttribute("class").contains("text-primary")) {
                isShown = true;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isAfterDownloadMessageShown method");

        return isShown;
    }

    /**
     * Method to perform a click on Download button.
     */
    public void clickOnDownloadLink() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnDownloadLink method");

        if (this.isAfterDownloadMessageAndLinkShown()) {
            this.getElementByXPath(DOWNLOAD_LINK).click();
            this.waitUntilDisappearByXPath(DOWNLOAD_BUTTON);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnDownloadLink method");
    }

}
