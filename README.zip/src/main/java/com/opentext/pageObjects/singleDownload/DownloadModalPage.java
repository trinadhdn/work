/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.singleDownload;

import static org.testng.AssertJUnit.assertTrue;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Download modal.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public abstract class DownloadModalPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(DownloadModalPage.class);

    /**
     * Components
     */
    protected volatile boolean isDrmAccepted;

    /**
     * Items keys selectors.
     */
    private final static String CLOSE_BUTTON = "closeButton";
    private final static String TITLE = "title";

    private final static String DRM_CHECK = "drmCheck";
    private final static String DRM_TEXT = "drmText";

    private final static String RENDITION_SELECT = "renditionSelect";
    private final static String RENDITION_OPTIONS = "renditionOptions";

    protected final static String DOWNLOAD_MESSAGE = "downloadMessage";
    protected final static String DOWNLOAD_BUTTON = "downloadButton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public DownloadModalPage(EmergyaWebDriver driver) {
        super(driver);
        isDrmAccepted = false;
        // this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        this.waitForReady();

        for (int i = 0; i <= 5; i++) {
            if (this.isElementVisibleByXPath(CLOSE_BUTTON) && this.isElementVisibleByXPath(TITLE)
                    && this.isElementVisibleByXPath(DRM_CHECK) && this.isElementVisibleByXPath(DRM_TEXT)
                    && this.isElementVisibleByXPath(RENDITION_SELECT) && this.isElementVisibleByXPath(RENDITION_OPTIONS)
                    && this.isElementVisibleByXPath(DOWNLOAD_BUTTON)) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(CLOSE_BUTTON);
        this.waitForByXPath(TITLE);
        this.waitForByXPath(DRM_CHECK);
        this.waitForByXPath(DRM_TEXT);
        this.waitForByXPath(RENDITION_SELECT);
        this.waitForByXPath(RENDITION_OPTIONS);
        this.waitForByXPath(DOWNLOAD_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to close the Download modal.
     */
    public void close() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");

        if (this.isElementVisibleByXPath(CLOSE_BUTTON, 5)) {
            this.driver.sleep(2);
            this.getElementByXPath(CLOSE_BUTTON).click();
            this.waitUntilDisappearByXPath(CLOSE_BUTTON);
        }
        assertTrue("The single download modal is not closed.", !this.isElementVisibleByXPath(CLOSE_BUTTON, 3));

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
    }

    /**
     * Method to perform a click on Download button.
     */
    public abstract void clickOnDownloadButton();

    /**
     * @return if the error message is shown or not.
     */
    public boolean isErrorMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isErrorMessageShown method");

        boolean isShown = false;
        if (this.isElementVisibleByXPath(DOWNLOAD_MESSAGE, 5)) {
            if (this.getElementByXPath(DOWNLOAD_MESSAGE).getAttribute("class").contains("text-danger")) {
                isShown = true;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isErrorMessageShown method");

        return isShown;
    }

    /**
     * Method to accept the DRM.
     */
    public void acceptDRM() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start acceptDRM method");

        if (!this.isDrmAccepted) {
            this.getElementByXPath(DRM_CHECK).click();
            this.driver.sleep(1);
            this.isDrmAccepted = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End acceptDRM method");
    }

}
