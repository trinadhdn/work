/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.collection.complements;

import static org.testng.AssertJUnit.assertTrue;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.collection.CollectionPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.export.ExportPage;
import com.opentext.pageObjects.singleDownload.specificModal.MultiDownloadPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the AdvanceSearch component.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class ActionAreaPage extends PCBasePage {

	/**
	 * Logger class initialization.
	 */
	static Logger log = Logger.getLogger(ActionAreaPage.class);

	/**
	 * Items keys selectors.
	 */

	private final static String ACTION_BUTTON = "actionButton";

	private final static String SELECT_ALL_BUTTON = "selectAllButton";
	private final static String EXPORT_SELECTION_BUTTON = "exportSelectionButton";
	private final static String CHANGE_COVER_BUTTON = "changeCoverButton";
	private final static String DOWNLOAD_SELECTION_BUTTON = "downloadSelectionButton";
	private final static String DELETE_SELECTION_BUTTON = "deleteSelectionButton";

	/**
	 * Components
	 */
	private boolean isOpen;

	/**
	 * Constructor method
	 * 
	 * @param driver
	 *            selenium webdriver
	 */
	public ActionAreaPage(EmergyaWebDriver driver) {
		super(driver);

		this.isOpen = this.isActionAreaOpen();

		this.isReady();
	}

	/**
	 * @return boolean about this PO is ready
	 */
	@Override
	public boolean isReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

		boolean isReady = false;
		this.waitForReady();
		for (int i = 0; i <= 5; i++) {

			if (this.isElementVisibleByXPath(ACTION_BUTTON)) {
				isReady = true;
				if (this.isOpen) {
					if (this.isElementVisibleByXPath(SELECT_ALL_BUTTON, 1)
							&& this.isElementVisibleByXPath(EXPORT_SELECTION_BUTTON, 1)
							&& this.isElementVisibleByXPath(CHANGE_COVER_BUTTON, 1)
							&& this.isElementVisibleByXPath(DOWNLOAD_SELECTION_BUTTON, 1)
							&& this.isElementVisibleByXPath(DELETE_SELECTION_BUTTON, 1)) {
						isReady = true;
						break;

					}
				}
			}
			if (isReady) {
				break;
			}

		}
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

		return isReady;
	}

	/**
	 * This method will wait until this PO is ready
	 */
	@Override
	public void waitForReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

		this.waitForByXPath(ACTION_BUTTON);
		if (this.isOpen) { // If is opened the components should be waited.
			this.waitForByXPath(SELECT_ALL_BUTTON);
			this.waitForByXPath(EXPORT_SELECTION_BUTTON);
			this.waitForByXPath(CHANGE_COVER_BUTTON);
			this.waitForByXPath(DOWNLOAD_SELECTION_BUTTON);
			this.waitForByXPath(DELETE_SELECTION_BUTTON);
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
	}

	/**
	 * @return if the action area is open or not.
	 */
	public boolean isActionAreaOpen() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isActionAreaOpen method");

		boolean isExpanded = false;

		try {
			if (this.getElementByXPath(ACTION_BUTTON).getAttribute("aria-expanded").contains("true")) {
				isExpanded = true;
			}
		} catch (Exception e) {
			isExpanded = false;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isActionAreaOpen method");

		return isExpanded;

	}

	/**
	 * @param isActionAreaOpen
	 */
	public void setActionAreaOpen(boolean isActionAreaOpen) {
		this.isOpen = isActionAreaOpen;
	}

	/**
	 * Method to open the actions area.
	 */
	public void openActionsArea() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start openActionsArea method");

		if (this.isReady()) {
			this.getElementByXPath(ACTION_BUTTON).click();
			this.waitForByXPath(SELECT_ALL_BUTTON);
		}
		assertTrue("The action area is collapsed.", this.isReady());

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End openActionsArea method");
	}

	/**
	 * Method to perform a click on the 'Select/Unselect all' button.
	 */
	public void clickOnSelectUnselectAll() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSelectUnselectAll method");

		if (!this.isReady()) {
			this.openActionsArea();
		}
		WebElement selectAllBtn = this.getElementByXPath(SELECT_ALL_BUTTON);
		String previousText = selectAllBtn.getText();

		selectAllBtn.click();
		this.driver.sleep(1);

		assertTrue("The 'Select/Unselect all' button should have changed.",
				!previousText.equalsIgnoreCase(selectAllBtn.getText()));

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSelectUnselectAll method");
	}

	/**
	 * Method to navigate to the MultiDownload modal of the selected assets.
	 * 
	 * @param counter
	 *            of the selected.
	 * @return MultiDownloadPage ready to work with, or null if there was no
	 *         selected assets.
	 */
	public MultiDownloadPage goToMultiDownloadOfTheAssets(int counterSelected) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName()
				+ " - Start goToMultiDownloadOfTheAssets method");

		MultiDownloadPage multiDownload = null;

		if (counterSelected > 0 && this.isActionAreaOpen()) {

			this.getElementByXPath(DOWNLOAD_SELECTION_BUTTON).click();

			multiDownload = new MultiDownloadPage(driver);
			multiDownload.waitForReady();
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToMultiDownloadOfTheAssets method");

		return multiDownload;
	}

	/**
	 * Method to navigate to the Export modal for selected assets.
	 * 
	 * @param Nnumber
	 *            of assets present in collection and number of assets selected.
	 * @return ExportPage ready to work with, or null if there was no selected
	 *         assets.
	 */
	public ExportPage goToExportSelection(int counterAssets, int counterSelected) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToExportSelection method");

		if (!this.isActionAreaOpen()) {
			this.openActionsArea();
		}
		ExportPage exportModal = null;

		this.getElementByXPath(EXPORT_SELECTION_BUTTON).click();

		if (counterAssets > 0 && counterSelected > 0) {
			exportModal = new ExportPage(driver);
			exportModal.waitForReady();
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToExportSelection method");

		return exportModal;
	}

	/**
	 * Method to change the collection's cover for the given asset.
	 * 
	 * @param index
	 *            of the asset to set as collection's cover.
	 */
	public void changeCover(int index, ContainerAssetsPage containerAssets, CollectionPage collectionPage) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start changeCover method");

		// Select the given asset.

		containerAssets.selectGivenAssetUsingCtrlKey(collectionPage, index);
		if (!this.isActionAreaOpen()) {
			this.openActionsArea();
		}

		// Perform a click on the 'Change cover' button.
		this.getElementByXPath(CHANGE_COVER_BUTTON).click();
		this.waitForByXPath(OK_MODAL_BUTTON);

		// Check the conformation modal is.
		assertTrue("Ok button of the modal is not ready.", this.isOkOfModalShown());
		this.clickOnOkOfModal();
		this.driver.sleep(1);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End changeCover method");
	}

	/**
	 * Method to perform a click on the delete button
	 * 
	 */
	public void clickDeleteBtn() {
		// Renamed the method from getDeleteBtn() to clickDeleteBtn()
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getDeleteBtn method");

		this.getElementByXPath(DELETE_SELECTION_BUTTON).click();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getDeleteBtn method");
	}
}
