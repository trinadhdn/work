/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.collection.types;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.collection.CollectionPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the general collection pages.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class GDriveCollectionPage extends CollectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(GDriveCollectionPage.class);

    /**
     * Components
     */
    // Take them from the parent.

    /**
     * Items keys selectors.
     */
    private final static String SUBTITLE = "subtitleGDrive";

    private final static String SYNC_ICON = "syncIcon";
    private final static String ERROR_ICON = "errorIcon";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public GDriveCollectionPage(EmergyaWebDriver driver) {
        super(driver);
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady()) {
            isReady = true;
            if (this.isElementVisibleByXPath(SUBTITLE)) {
                isReady = true;
            } else {
                isReady = false;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        this.waitForByXPath(SUBTITLE);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return the subtitle of this collection.
     */
    public String getSubtitle() { // TODO
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getSubtitle method");

        String title = this.getElementByXPath(SUBTITLE).getText().trim();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getSubtitle method");

        return title;
    }

    /**
     * @return If the Sync icon is shown or not.
     */
    @Override
    public boolean isSyncIconShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isSyncIconShown method");

        boolean isShown = false;
        if (this.isElementVisibleByXPath(SYNC_ICON)) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isSyncIconShown method");

        return isShown;
    }

    /**
     * @return If the Error of sync icon is shown or not.
     */
    public boolean isErrorIconShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isErrorIconShown method");

        boolean isShown = false;
        if (this.isElementVisibleByXPath(ERROR_ICON)) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isErrorIconShown method");

        return isShown;
    }

    /**
     * Method to navigate to the Collection Info modal. 
     * @return CollectionInfoPage ready to work with.
     */
    // public CollectionInfoPage goToInfo() { // TODO
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToInfo method");
    //
    // this.getElementByXPath(EDIT_BUTTON).click();
    // this.driver.sleep(1);
    //
    // CollectionInfoPage infoModal = new CollectionInfoPage(driver, this.getCounterAssets());
    // infoModal.waitForReady();
    //
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToInfo method");
    //
    // return infoModal;
    // }

    /**
     * Method for delete the selected assets from a GDrive collection. 
     */
    public void deleteSelectedAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteSelectedAssets method");

        super.deleteSelectedAssets();
        // this.rechargeContainerAssets();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteSelectedAssets method");

    }

}
