/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.createAndEditionCollection.specific;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.collection.CollectionPage;
import com.opentext.pageObjects.createAndEditionCollection.CreateAndEditionCollectionPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Edit collection modal page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class EditionCollectionPage extends CreateAndEditionCollectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(EditionCollectionPage.class);

    /**
     * Items keys selectors.
     */
    private final static String X_BUTTON = "xButton";
    private final static String TITLE = "title";

    /**
     * Constructor method
     * 
     * @param driver
     *            selenium webdriver
     */
    public EditionCollectionPage(EmergyaWebDriver driver) {
        super(driver);
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 3; i++) {

            if (super.isReady() && this.isElementVisibleByXPath(X_BUTTON) && this.isElementVisibleByXPath(TITLE)) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        this.waitForByXPath(X_BUTTON);
        this.waitForByXPath(TITLE);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to click on the X button, to close this modal.
     */
    public void close() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");

        WebElement xButton = this.getElementByXPath(X_BUTTON);
        if (!xButton.isDisplayed()) {
            this.scrollTo(xButton);
        }
        xButton.click();
        this.waitUntilDisappearWebElement(xButton);
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
    }

    /**
     * Method to save the edition of a collection and navigating back to the
     * info modal.
     */
    @Override
    public PCBasePage clickOnSaveButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSaveButton method");

        super.clickOnSaveButton();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSaveButton method");

        // returning null becasue of overriding the method.
        return null;
    }

    /**
     * Method to save the edition of a collection and navigating back to the
     * info modal.
     * 
     * @return CollectionPage ready to work with.
     */
    // public CollectionInfoPage clickOnSaveButton() {
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " -
    // Start clickOnSaveButton method");
    //
    // super.clickOnSaveButton();
    //
    // CollectionInfoPage infoModal = new CollectionInfoPage(driver);
    // infoModal.waitForReady();
    //
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End
    // clickOnSaveButton method");
    //
    // return infoModal;
    // }

    /**
     * Method to edit collection by editing Collection Name and Expiry date.
     * 
     * @param Collection page and new Collection name.
     * @return CollectionPage ready to work with.
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     */
    public CollectionPage editCollInfo(CollectionPage collectionPage, String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start editCollInfo method");

        // Editing the collection detials.
        this.fillName(name);

        DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
        Date now = Calendar.getInstance().getTime();
        Calendar after = Calendar.getInstance();
        after.setTime(now);
        after.add(Calendar.DAY_OF_YEAR, +2);
        Date nextDate = after.getTime();
        this.fillExpiredDate(df1.format(nextDate));

        // Saving the changes.
        this.clickOnSaveButton();
        this.driver.sleep(2);

        // Waiting for collection page to load.
        this.waitUntilDisappearByXPath(SPINNER);
        collectionPage.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End editCollInfo method");

        return collectionPage;
    }

}
