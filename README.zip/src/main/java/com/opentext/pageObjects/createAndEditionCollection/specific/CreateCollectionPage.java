/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.createAndEditionCollection.specific;

import static org.testng.AssertJUnit.assertTrue;

import org.apache.log4j.Logger;
import org.openqa.selenium.support.ui.Select;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.collection.CollectionPage;
import com.opentext.pageObjects.collection.types.GDriveCollectionPage;
import com.opentext.pageObjects.collection.types.StandardCollectionPage;
import com.opentext.pageObjects.createAndEditionCollection.CreateAndEditionCollectionPage;
import com.opentext.pageObjects.footer.FooterPage;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.pageObjects.login.external.GoogleLoginPage;
import com.opentext.pageObjects.search.SearchPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * This PO contains the methods to interact with the Create collection page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class CreateCollectionPage extends CreateAndEditionCollectionPage {

	/**
	 * Logger class initialization.
	 */
	static Logger log = Logger.getLogger(CreateCollectionPage.class);

	/**
	 * Components
	 */
	private static HeaderPage header;
	private static FooterPage footer;

	/**
	 * Items keys selectors.
	 */

	private final static String BACK_BTN = "backToSearchButton";

	private final static String TYPE_SELECT = "typeSelect";
	private final static String TYPE_OPTIONS = "typeOptions";

	private final static String GDRIVE_INPUT = "gdriveInput";
	private final static String GDRIVE_ERROR_MESSAGE = "gdriveErrorMessage";
	private final static String GDRIVE_BUTTON = "gdriveButton";
	private final static String GDRIVE_AUTH_SUCCESS = "gdriveAuthSuccess";
	private final static String GDRIVE_AUTH_ERROR = "gdriveAuthError";

	private final static String MEDIABIN_SELECT = "mediabinSelect";

	/**
	 * Constructor method
	 * 
	 * @param driver
	 *            selenium webdriver
	 */
	public CreateCollectionPage(EmergyaWebDriver driver) {
		super(driver);

		header = new HeaderPage(driver);
		footer = new FooterPage(driver);

		this.isReady();
	}

	/**
	 * @return boolean about this PO is ready
	 */
	@Override
	public boolean isReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

		boolean isReady = false;
		this.waitForReady();

		for (int i = 0; i <= 5; i++) {

			if (super.isReady() && header.isReady() && footer.isReady() && this.isElementVisibleByXPath(BACK_BTN)
					&& this.isElementVisibleByXPath(TYPE_SELECT)) {
				isReady = true;
				break;
			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

		return isReady;
	}

	/**
	 * This method will wait until this PO is ready
	 */
	@Override
	public void waitForReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

		super.waitForReady();
		header.waitForReady();
		footer.waitForReady();
		this.waitForByXPath(BACK_BTN);
		this.waitForByXPath(TYPE_SELECT);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
	}

	/**
	 * @return Header page.
	 */
	public HeaderPage getHeader() {
		return header;
	}

	/**
	 * Method to click in the Back button, to go back to search page.
	 * 
	 * @return Search page ready to work with.
	 */
	public SearchPage clickOnBackButton() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnBackButton method");

		this.getElementByXPath(BACK_BTN).click();
		this.driver.sleep(1);

		SearchPage searchPage = new SearchPage(driver);
		searchPage.waitForReady();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnBackButton method");

		return searchPage;
	}

	/**
	 * Method to select the collection type.
	 * 
	 * @param collection
	 *            type for the collection.
	 */
	public void selectAndFillType(String cType) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAndFillType method");

		Select typeSelect = new Select(this.getElementByXPath(TYPE_SELECT));
		typeSelect.selectByVisibleText(cType);

		switch (this.getCollectionTypeSelected()) {
		case "Albums":
			// Nothing to do
			break;
		case "Personal":
			// Nothing to do
			break;
		case "Gdrive":
			this.configureGDriveType();
			break;
		case "MediaBin":
			// TODO: change to MB logic.
			break;
		default:
			break;
		}
		this.driver.sleep(1);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAndFillType method");
	}

	/**
	 * Method to configure the GDrive elements. Preconditions: GDrive type
	 * selected, and GDrive authentication success shown.
	 */
	private void configureGDriveType() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start configureGDriveType method");

		if (this.isElementVisibleByXPath(GDRIVE_BUTTON)) {
			this.waitForByXPath(GDRIVE_BUTTON);
			assertTrue("GDrive option should be selected.",
					this.getCollectionTypeSelected().equalsIgnoreCase("Gdrive"));
			this.getElementByXPath(GDRIVE_BUTTON).click();

			GoogleLoginPage googleLoginPage = new GoogleLoginPage(driver);
			googleLoginPage.waitForReady();
			assertTrue("Google login page should be shown.", googleLoginPage.isReady());

			PCBasePage returnedPage = googleLoginPage.gDriveLogin(UserDomain.GOOGLE, UserType.QA1);

			// Verify authorization message in create collection page.
			assertTrue("Google authentication message is not shown",
					((CreateCollectionPage) returnedPage).isAuthorised());
		}

		// Enter the path of the Gdrive folder.
		assertTrue("Google drive path shuould be entered.", this.enterGdrivePath());

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End configureGDriveType method");

	}

	/**
	 * @return text of the collection type selected option.
	 */
	private String getCollectionTypeSelected() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCollectionTypeSelected method");

		Select typeSelect = new Select(this.getElementByXPath(TYPE_SELECT));
		String cType = typeSelect.getFirstSelectedOption().getText().trim();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCollectionTypeSelected method");

		return cType;
	}

	/**
	 * Method to save the creation of a collection and navigating into the
	 * created collection.
	 * 
	 * @return CollectionPage ready to work with.
	 */
	@Override
	public CollectionPage clickOnSaveButton() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSaveButton method");

		String cType = this.getCollectionTypeSelected();

		super.clickOnSaveButton();

		CollectionPage collection = null;
		if (!this.isElementVisibleByXPath(OK_MODAL_BUTTON, 1)) {
			switch (cType) {
			case "Albums":
				collection = new StandardCollectionPage(driver);
				break;
			case "Personal":
				collection = new StandardCollectionPage(driver);
				break;
			case "Google Drive":
				this.waitUntilDisappearByXPath(SPINNER);
				assertTrue("GDrive path shouldn't be empty.", !this.isElementVisibleByXPath(GDRIVE_ERROR_MESSAGE, 1));
				collection = new GDriveCollectionPage(driver);
				break;
			case "MediaBin":
				collection = new StandardCollectionPage(driver); // TODO: change
																	// to MB
																	// type
				break;
			default:
				collection = new StandardCollectionPage(driver);
				break;
			}
			collection.waitForReady();
		} else {
			// Click on OK modal button
			this.getElementByXPath(OK_MODAL_BUTTON).click();
			this.waitUntilDisappearByXPath(OK_MODAL_BUTTON);
			this.waitUntilDisappearByXPath(SPINNER);

		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSaveButton method");

		return collection;
	}

	/**
	 * Method to check authentication message for google drive login.
	 * 
	 * @return Returns boolean value depending on google authentication present
	 *         or not.
	 * @return HomePage
	 * @author Sowjanya Lankadasu <slankada@opentext.com>
	 */
	public boolean isAuthorised() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isAuthorised method");

		boolean isAuthecationMessage = false;

		if (this.isElementVisibleByXPath(GDRIVE_AUTH_SUCCESS)) {
			isAuthecationMessage = true;
			this.driver.sleep(1);
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isAuthorised method");

		return isAuthecationMessage;
	}

	/**
	 * Method to enter Google drive path in text box.
	 *
	 * @return Boolean value depending on whether the path is entered or not.
	 * @author Sowjanya Lankadasu <slankada@opentext.com>
	 */
	public boolean enterGdrivePath() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start enterGdrivePath method");

		boolean enterpath = false;

		this.waitForByXPath(GDRIVE_INPUT, 5);

		if (this.isElementVisibleByXPath(GDRIVE_INPUT)) {
			this.getElementByXPath(GDRIVE_INPUT).sendKeys(INVALID_GDRIVE_PATH);
			super.clickOnSaveButton();
			if (this.isElementVisibleByXPath(OK_MODAL_BUTTON)) {

				String invalidPathText = "invalid path";
				if (this.getElementByXPath(OK_MODAL_TEXT).getText().contains(invalidPathText)) {
					this.getElementByXPath(OK_MODAL_BUTTON).click();
					this.waitUntilDisappearByXPath(OK_MODAL_BUTTON);
					this.waitUntilDisappearByXPath(SPINNER);
				}
			}
			this.getElementByXPath(GDRIVE_INPUT).clear();
			this.getElementByXPath(GDRIVE_INPUT).sendKeys(VALID_GDRIVE_PATH);
			enterpath = true;
			this.driver.sleep(1);
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End enterGdrivePath method");

		return enterpath;
	}

}
