/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.createAndEditionCollection;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with commons between the Create and
 * Edit collection page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public abstract class CreateAndEditionCollectionPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(CreateAndEditionCollectionPage.class);

    /**
     * Items keys selectors.
     */
    private final static String TITLE_INPUT = "titleInput";
    private final static String TITLE_ERROR_MESSAGE = "titleErrorMessage";
    private final static String EXPIR_DATE_INPUT = "expirationDateinput";
    private final static String EXPIR_DATE_BUTTON = "expirationDateButton";

    private final static String OWNER_INPUT = "ownerInput";
    private final static String SHARED_INPUT = "sharedInput";

    private final static String COMMENTS_TA = "commentsTextarea";

    private final static String CANCEL_BUTTON = "cancelButton";
    private final static String SAVE_BUTTON = "saveButton";

    private final static String USER_AUTO_SUGGESTIONS = "userautosuggestions";

    /**
     * Constructor method
     * 
     * @param driver
     *            selenium webdriver
     */
    public CreateAndEditionCollectionPage(EmergyaWebDriver driver) {
        super(driver);
        // this.isReady()// not necessary.
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 5; i++) {

            if (this.isElementVisibleByXPath(TITLE_INPUT) && this.isElementVisibleByXPath(EXPIR_DATE_INPUT)
                    && this.isElementVisibleByXPath(EXPIR_DATE_BUTTON) && this.isElementVisibleByXPath(OWNER_INPUT)
                    && this.isElementVisibleByXPath(SHARED_INPUT) && this.isElementVisibleByXPath(COMMENTS_TA)
                    && this.isElementVisibleByXPath(CANCEL_BUTTON) && this.isElementVisibleByXPath(SAVE_BUTTON)) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(TITLE_INPUT);
        this.waitForByXPath(EXPIR_DATE_INPUT);
        this.waitForByXPath(EXPIR_DATE_BUTTON);
        this.waitForByXPath(OWNER_INPUT);
        this.waitForByXPath(SHARED_INPUT);
        this.waitForByXPath(COMMENTS_TA);
        this.waitForByXPath(CANCEL_BUTTON);
        this.waitForByXPath(SAVE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to clean the given input.
     * 
     * @param input
     *            to clean.
     */
    protected void cleanInput(WebElement input) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start cleanInput method");

        if (!input.getAttribute("value").isEmpty()) {
            input.sendKeys(Keys.END);
            while (!input.getAttribute("value").isEmpty()) {
                input.sendKeys(Keys.BACK_SPACE);
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End cleanInput method");
    }

    /**
     * Type the name in the proper input.
     * 
     * @param name
     *            of the collection.
     */
    public void fillName(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillName method");

        this.cleanInput(this.getElementByXPath(TITLE_INPUT));
        this.getElementByXPath(TITLE_INPUT).sendKeys(name);
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillName method");
    }

    /**
     * Type the comment in the proper input.
     * 
     * @param comment
     *            for the collection.
     */
    public void fillComment(String comment) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillComment method");

        this.cleanInput(this.getElementByXPath(COMMENTS_TA));
        this.getElementByXPath(COMMENTS_TA).sendKeys(comment);
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillComment method");
    }

    /**
     * Type the date in the expired date input.
     * 
     * @param comment
     *            for the collection.
     */
    public void fillExpiredDate(String date) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillExpiredDate method");

        this.getElementByXPath(EXPIR_DATE_BUTTON).click();

        this.cleanInput(this.getElementByXPath(EXPIR_DATE_INPUT));
        this.getElementByXPath(EXPIR_DATE_INPUT).sendKeys(date);

        this.getElementByXPath(EXPIR_DATE_BUTTON).click();
        this.driver.sleep(1);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillExpiredDate method");
    }

    /**
     * Method to save the creation of a collection and navigating into the
     * created collection.
     * 
     * @return CollectionPage ready to work with.
     */
    protected PCBasePage clickOnSaveButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSaveButton method");

        assertTrue("Collection name should be typed.", !this.getElementByXPath(TITLE_INPUT).getAttribute("value")
                .isEmpty());
        assertTrue("Name error shouldn't be shown.", !this.isElementVisibleByXPath(TITLE_ERROR_MESSAGE, 1));

        this.getElementByXPath(SAVE_BUTTON).click();
        this.driver.sleep(5);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSaveButton method");

        return null;
    }

    /**
     * Fill the share email field.
     * 
     * @param userDomain
     *            to perform the login.
     * @param usertype
     *            to perform the login.
     * @author Trinadh Kumar Nakka(tnakka@opentext.com), Sowjanya Lankadasu
     *         <slankada@opentext.com>
     */
    public void fillSharetoEmail(String sharedUser) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillSharetoEmail method");

        // UserTest user = UserFactory.getUser(userDomain, userType);

        // Enter the user name in the shared user text box
        log.info("[log-PageObjects-info] " + this.getClass().getSimpleName()
                + " - Clearing and Entering text in Shared User test box ");
        this.cleanInput(this.getElementByXPath(SHARED_INPUT));
        this.getElementByXPath(SHARED_INPUT).sendKeys(sharedUser);

        // clicking on the auto suggestions link to add the user to the text
        // box.
        log.info("[log-PageObjects-info] " + this.getClass().getSimpleName()
                + " - Clicking on Add button to add shared User to the test box ");
        selectAnUserFromAutoSuggOption();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillSharetoEmail method");
    }

    /**
     * Type the Collection Owner email in the proper input box.
     * 
     * @param user
     *            Domian and type of the collection.
     * @param usertype
     *            to perform the login.
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     */
    public void fillCollectionOwnerEmail(String collOwner) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillCollectionOwnerEmail method");

        // UserTest user = UserFactory.getUser(userDomain, userType);

        // Clearing the Colelction Owner text box, entering the text and
        // selecting a user from the auto suggestions.
        log.info("[log-PageObjects-info] " + this.getClass().getSimpleName()
                + " - Clearing and Entering text in Collection Owner test box ");
        this.cleanInput(this.getElementByXPath(OWNER_INPUT));
        this.getElementByXPath(OWNER_INPUT).sendKeys(collOwner);

        // clicking on the auto suggestions link to add the user to the text
        // box.
        log.info("[log-PageObjects-info] " + this.getClass().getSimpleName()
                + " - Clicking on Add button to add shared User to the test box ");
        selectAnUserFromAutoSuggOption();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillCollectionOwnerEmail method");
    }

    /**
     * Method to check for auto suggestions list is visible when entered a user
     * name in Shared user and collection owner text box.
     * 
     * @return If the auto suggestions are shown or not.
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     */
    public boolean isAutoSuggShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isAutoSugShown method");

        boolean isShown = false;
        if (this.isElementVisibleByXPath(USER_AUTO_SUGGESTIONS)) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isAutoSugShown method");

        return isShown;
    }

    /**
     * Method to select a user from the auto suggestions dropdown.
     * 
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     */
    public void selectAnUserFromAutoSuggOption() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectAUserFromAutoSuggOption method");

        if (this.isAutoSuggShown()) {
            log.info("[log-PageObjects -info] " + this.getClass().getSimpleName()
                    + " - Inside if loop, auto suggestions are present");
            // Get all of the options
            List<WebElement> options = this.getElementsByXPath(USER_AUTO_SUGGESTIONS);
            // Loop through the options and click the first option
            log.info("[log-PageObjects -info] " + this.getClass().getSimpleName()
                    + " - Total suggestions present in dropdown are : " + options.size());

            // Click on the first option.
            for (WebElement option : options) {
                log.info("[log-PageObjects -info] " + this.getClass().getSimpleName() + " Selecting option : "
                        + option.getText());
                option.click();
                this.driver.sleep(1);
                break;
            }
        } else {
            log.info("[log-PageObjects-error] " + this.getClass().getSimpleName()
                    + " Error - No Auto suggestions drop down to select ");
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectAUserFromAutoSuggOption method");
    }

}
