/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.inbox;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.UserFactory;
import com.opentext.utils.UserTest;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * This PO contains the methods to interact with the Inbox modal page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class InboxPage extends PCBasePage {

	/**
	 * Logger class initialization.
	 */
	static Logger log = Logger.getLogger(InboxPage.class);

	/**
	 * Items keys selectors.
	 */
	private static final String X_BUTTON = "xButton";
	private static final String TITLE = "title";

	private static final String TOTAL = "messagesTotal";
	private static final String UNREAD = "messagesUnread";

	private static final String MARKALLREAD_BUTTON = "markAllReadButton";

	private static final String NO_MESSAGES = "noMessages";

	private static final String ICONS = "icons";
	private static final String MESSAGES = "messages";
	private static final String LINKS_MESSAGES = "linksMessages";
	private static final String MESSAGES_HOVERS = "messagesHovers";
	private static final String SENT_DATES = "sentDates";
	private static final String DELETE_BUTTONS = "deleteButtons";

	/**
	 * Constructor method
	 * 
	 * @param driver
	 *            selenium webdriver
	 */
	public InboxPage(EmergyaWebDriver driver) {
		super(driver);
		this.isReady();
	}

	/**
	 * @return boolean about this PO is ready
	 */
	@Override
	public synchronized boolean isReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

		boolean isReady = false;
		if (this.isElementVisibleByXPath(X_BUTTON) && this.isElementVisibleByXPath(TITLE)
				&& this.isElementVisibleByXPath(TOTAL) && this.isElementVisibleByXPath(UNREAD)
				&& this.isElementVisibleByXPath(MARKALLREAD_BUTTON)) {
			isReady = true;
			if (this.getTotalMessages() > 0) { // Any message
				if (this.isElementVisibleByXPath(ICONS) && this.isElementVisibleByXPath(MESSAGES)
						&& this.isElementVisibleByXPath(SENT_DATES) && this.isElementVisibleByXPath(DELETE_BUTTONS)) {
					isReady = true;
				} else {
					isReady = false;
				}
			} else { // No messages
				if (this.isElementVisibleByXPath(NO_MESSAGES)) {
					isReady = true;
				} else {
					isReady = false;
				}
			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

		return isReady;
	}

	/**
	 * This method will wait until this PO is ready
	 */
	@Override
	public synchronized void waitForReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

		this.waitForByXPath(X_BUTTON);
		this.waitForByXPath(TITLE);
		this.waitForByXPath(TOTAL);
		this.waitForByXPath(UNREAD);
		this.waitForByXPath(MARKALLREAD_BUTTON);
		if (this.getTotalMessages() > 0) { // Any message
			this.waitForByXPath(ICONS);
			this.waitForByXPath(MESSAGES);
			this.waitForByXPath(SENT_DATES);
			this.waitForByXPath(DELETE_BUTTONS);
		} else { // No messages
			this.waitForByXPath(NO_MESSAGES);
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
	}

	/**
	 * @return the number total of the messages in the Inbox.
	 */
	public synchronized int getTotalMessages() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getTotalMessages method");

		int total = 0;
		for (int i = 0; i <= 5; i++) {

			if (!((this.getElementByXPath(TOTAL).getText().trim()) == "")) {

				total = Integer.parseInt(this.getElementByXPath(TOTAL).getText().trim());

				break;

			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getTotalMessages method");

		return total;
	}

	/**
	 * @return the number of the unread messages in the Inbox.
	 */
	public synchronized int getNumberOfUnreadMessages() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumberOfUnreadMessages method");

		int unread = Integer.parseInt(this.getElementByXPath(UNREAD).getText().trim());

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfUnreadMessages method");

		return unread;
	}

	/**
	 * Method to click on the X button, to close this modal.
	 */
	public synchronized void close() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");

		WebElement xButton = this.getElementByXPath(X_BUTTON);
		if (!xButton.isDisplayed()) {
			this.scrollTo(xButton);
		}
		xButton.click();
		this.waitUntilDisappearWebElement(xButton);
		this.waitUntilDisappearByXPath(SPINNER);
		this.driver.sleep(1);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
	}

	/**
	 * Method to check if is the given message read or not.
	 * 
	 * @param index
	 *            of the the message to check.
	 * @return if is the message read or not.
	 */
	public synchronized boolean isMessageRead(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isMessageRead method");

		boolean isMessageRead = false;
		String messageClass = this.getElementsByXPath(SENT_DATES).get(index).findElement(By.xpath("../.."))
				.getAttribute("class");

		if (messageClass.contains("read")) {
			isMessageRead = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isMessageRead method");

		return isMessageRead;
	}

	/**
	 * Method to check if is the given message an info message or not.
	 * 
	 * @param index
	 *            of the the message to check.
	 * @return if is the message an info message or not.
	 */
	private synchronized boolean isMessageInfo(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isMessageInfo method");

		boolean isMessageInfo = false;
		String messageClass = this.getElementsByXPath(SENT_DATES).get(index).findElement(By.xpath("../.."))
				.getAttribute("class");

		if (messageClass.contains("info")) {
			isMessageInfo = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isMessageInfo method");

		return isMessageInfo;
	}

	/**
	 * Method to check if is the given message an info message realted to
	 * collection or not and delete the message if it is collection realted.
	 * 
	 * @author Sowjanya Lankadasu <slankada@opentext.com>, Trinadh Nakka
	 *         <tnakka@opetenxt.com>.
	 * @param name
	 *            of Collection Name.
	 * @param userEmail
	 *            or userName and user type of the User .
	 * @param userType
	 *            whether it is shared user or owner user.
	 * @return if is the message an info message or not.
	 */
	public synchronized boolean isMessageGeneratedForCollection(String name, UserDomain userDomain, UserType uType,
			String type) {

		log.info("[log-PageObjects] " + this.getClass().getSimpleName()
				+ " - Start isMessageGeneratedForCollection method");

		boolean isMessageInfo = false;

		UserTest user = UserFactory.getUser(userDomain, uType);
		String userEmail = user.getUsername();

		List<String> messageList = this.getList(MESSAGES);

		if (type == "Shared") {
			for (String message : messageList) {

				String messageDisplayName = "You have been granted shared privileges on collection " + name + " by "
						+ "user " + userEmail;
				log.info(messageDisplayName);
				if (message.contains(messageDisplayName)) {
					this.clickOnMessage(messageList.indexOf(message));
					// this.getElementsByXPath(MESSAGES).get(messageList.indexOf(message)).click();
					this.clickOnDeleteButton(messageList.indexOf(message));
					// this.getElementsByXPath(DELETE_BUTTONS).get(messageList.indexOf(message)).click();
					isMessageInfo = true;
					break;
				}

			}
		} else if (type == "Owner") {
			for (String message : messageList) {

				String messageDisplayName = "You have been granted owner privileges on collection " + name + " by "
						+ "user " + userEmail;
				if (message.contains(messageDisplayName)) {
					this.clickOnMessage(messageList.indexOf(message));
					this.clickOnDeleteButton(messageList.indexOf(message));
					isMessageInfo = true;
					break;
				}

			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName()
				+ " - End isMessageGeneratedForCollection method");

		return isMessageInfo;
	}

	/**
	 * Method to check if is the given message has with link or not.
	 * 
	 * @param index
	 *            of the the message to check.
	 * @return if is the message has link or not.
	 */
	private synchronized boolean isMessageWithLink(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isMessageWithLink method");

		boolean isMessageWithLink = false;
		String messageClass = this.getElementsByXPath(SENT_DATES).get(index).findElement(By.xpath("../.."))
				.getAttribute("class");

		if (messageClass.contains("download")) {
			isMessageWithLink = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isMessageWithLink method");

		return isMessageWithLink;
	}

	/**
	 * Method to check if is the given message has a link of an exported file or
	 * not.
	 * 
	 * @param index
	 *            of the the message to check.
	 * @return if is the message has a link of an exported file or not.
	 */
	private synchronized boolean isLinkOfAnExportedFile(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isLinkOfAnExportedFile method");

		boolean isLinkOfAnExportedFile = false;

		if (this.getElementsByXPath(MESSAGES).get(index).findElement(By.xpath("./a")).getAttribute("href")
				.contains("getExportedFile")) {
			isLinkOfAnExportedFile = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isLinkOfAnExportedFile method");

		return isLinkOfAnExportedFile;
	}

	/**
	 * Method to check if is the given message is of an exported file or not.
	 * 
	 * @param index
	 *            of the the message to check.
	 * @return if is the message is of an exported file or not.
	 */
	public synchronized boolean isMessageOfExportFile(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isMessageOfExportFile method");

		boolean isMessageOfExportFile = false;

		if (this.isMessageInfo(index) && this.isMessageWithLink(index) && this.isLinkOfAnExportedFile(index)) {
			isMessageOfExportFile = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isMessageOfExportFile method");

		return isMessageOfExportFile;
	}

	/**
	 * Method to check if is not the given message is of an exported file or
	 * not.
	 * 
	 * @param index
	 *            of the the message to check.
	 * @return if is the message is of an exported file or not.
	 */
	public synchronized boolean isNotMessageOfExportFile(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isMessageOfExportFile method");

		boolean isMessageOfExportFile = false;

		if (this.isMessageInfo(index) && this.isMessageWithLink(index) && !this.isLinkOfAnExportedFile(index)) {
			isMessageOfExportFile = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isMessageOfExportFile method");

		return isMessageOfExportFile;
	}

	/**
	 * Method to perform a click on 'Mark all as read' button.
	 */
	public synchronized void clickOnMarkAllAsReadButton() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnMarkAllAsReadButton method");

		this.getElementByXPath(MARKALLREAD_BUTTON).click();
		this.driver.sleep(1);

		assertTrue("Ok button of the modal is not ready.", this.isOkOfModalShown());
		this.clickOnOkOfModal();
		this.driver.sleep(1);

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnMarkAllAsReadButton method");
	}

	/**
	 * Method to perform a click on the link of the given message.
	 * 
	 * @param index
	 *            of the message position.
	 */
	public synchronized void clickOnLinkOfMessage(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnLinkOfMessage method");

		if (this.getTotalMessages() > 0 && index < this.getTotalMessages()) {
			WebElement message = this.getElementsByXPath(MESSAGES).get(index);
			try {
				message.click();
				message.findElement(By.xpath("./a")).click();
				this.driver.sleep(1);
			} catch (Exception e) {

			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnLinkOfMessage method");
	}

	/**
	 * Method to delete the given message.
	 * 
	 * @param index
	 *            of the message position.
	 */
	public synchronized void clickOnDeleteButton(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnDeleteButton method");

		if (this.getTotalMessages() > 0 && index < this.getTotalMessages()) {
			this.getElementsByXPath(DELETE_BUTTONS).get(index).click();
			this.driver.sleep(1);
			this.waitUntilDisappearByXPath(SPINNER);
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnDeleteButton method");
	}

	/**
	 * Method to check if "no messages present" text is present or not.
	 * 
	 * @author Sowjanya Lankadasu <slankada@opentext.com>
	 * @return if is the message present or not.
	 */
	public boolean isNoMessageTextPresent() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isNoMessageTextPresent method");

		boolean isMessagePresent = false;

		// Verify whether "No messages" text is displayed
		if (this.isElementVisibleByXPath(NO_MESSAGES)) {
			isMessagePresent = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isNoMessageTextPresent method");

		return isMessagePresent;
	}

	/**
	 * Method to delete all the messages.
	 * 
	 * @author Sowjanya Lankadasu <slankada@opentext.com>
	 * @param number
	 *            of messages.
	 * @return if all the messages are deleted or not
	 */
	public void deleteAllMessages() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteAllMessages method");

		int count = this.getTotalMessages();
		if (count != 0) {
			int index = this.getElementsByXPath(DELETE_BUTTONS).size();
			while (index > 0) {
				index--;
				this.getElementsByXPath(DELETE_BUTTONS).get(index).click();
				this.driver.sleep(1);
				this.waitUntilDisappearByXPath(SPINNER);
			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteAllMessages method");

	}

	/**
	 * Method to perform a click on the given message.
	 * 
	 * @param index
	 *            of the message position.
	 * @author Sowjanya Lankadasu <slankada@opentext.com>
	 */
	public synchronized void clickOnMessage(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnMessage method");

		if (this.getTotalMessages() > 0 && index < this.getTotalMessages()) {
			WebElement message = this.getElementsByXPath(MESSAGES).get(index);
			message.click();
			this.driver.sleep(1);
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnMessage method");

	}

	/**
	 * Method to check if the given message is for download file or not.
	 * 
	 * @param index
	 *            of the the message to check.
	 * @return if is the message is for download or not.
	 * @author Sowjanya Lankadasu <slankada@opentext.com>
	 */
	public boolean isMessageforDownload(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isMessageforDownload method");

		boolean isMessageOfDownloadFile = false;

		if (this.isMessageInfo(index) && this.isMessageWithLink(index) && this.isMsgOfDownloadFile(index)) {
			isMessageOfDownloadFile = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isMessageforDownload method");

		return isMessageOfDownloadFile;
	}

	/**
	 * Method to check if is the given message is for download file or not.
	 * 
	 * @param index
	 *            of the the message to check.
	 * @return if is the message has a link of an exported file or not.
	 * @author Sowjanya Lankadasu <slankada@opentext.com>
	 */
	private boolean isMsgOfDownloadFile(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isMsgOfDownloadFile method");

		boolean isMsgOfDownload = false;

		if (this.getElementsByXPath(MESSAGES).get(index).getText().contains("download request")) {
			isMsgOfDownload = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isMsgOfDownloadFile method");

		return isMsgOfDownload;
	}

}