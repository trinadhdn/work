/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */

package com.opentext.pageObjects.uploadTestDataInRMM;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.ConfigFactory;
import com.opentext.utils.ConfigLibrary.ConfigDetails;
import com.opentext.utils.ConfigRMM;
import com.opentext.utils.ConfigRMM.ConfigRMMDetails;
import com.opentext.utils.UserFactory;
import com.opentext.utils.UserTest;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * A test class contain RMM related methods
 * @author Trinadh Nakka(tnakka@opentext.com)
 */

public class UploadTestDataInRMMPage extends PCBasePage {

    static Logger log = Logger.getLogger(UploadTestDataInRMMPage.class);

    /**
     * Items keys selectors.
     */
    protected final static String USER_NAME = "username";
    protected final static String PASSWORD = "password";
    protected final static String SIGNIN_BUTTON = "signInButton";
    protected final static String UPLOAD_BUTTON = "uploadbutton";
    protected final static String UPLOAD_WORKFLOW_BUTTON = "uploadworkflowbutton";
    protected final static String ADD_FILE_BUTTON = "addfilebutton";
    protected final static String UNCOMPRESS_ZIPCHECK = "uncompresszipcheck";
    protected final static String OK_BUTTON = "okbutton";
    protected final static String CLOSE_DAILOG = "closedailog";
    protected final static String USER_PROFILE_BUTTON = "userprofilebutton";
    protected final static String LOGOUT_BUTTON = "logoutbutton";
    protected final static String ACTIVITY_MANAGER_BUTTON = "activitymanager";
    protected final static String PENDING_COUNT = "pendingcount";
    protected final static String PENDING_COUNT_BUTTON = "pendingcountbutton";
    protected int PENDINGCOUNT = 0;
    private static ConfigDetails RMM_URL;

    /**
     * Constructor method
     * @param driver selenium webdriver
    
     */
    public UploadTestDataInRMMPage(EmergyaWebDriver driver) {
        super(driver);

    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(ADD_FILE_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * @return boolean about this login page is ready
     */

    public boolean loginPageIsReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start loginPageIsReady method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(USER_NAME) && this.isElementVisibleByXPath(PASSWORD)
                && this.isElementVisibleByXPath(SIGNIN_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End loginPageIsReady method");

        return isReady;
    }

    /**
     * Wait until login page is ready
     */

    public void waitForLoginPageIsReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start loginPageIsReady method");

        this.waitForByXPath(USER_NAME);
        this.waitForByXPath(PASSWORD);
        this.waitForByXPath(SIGNIN_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End loginPageIsReady method");

    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(UPLOAD_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * This method will login to RMM with given username and password
     * @param UserDomain
     * @param UserType
     */

    public void rmmLogin(UserDomain userDomain, UserType userType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start rmmLogin method");

        // navigate to Media bin URL
        ConfigRMM rmmurl = ConfigFactory.getRmmURL(ConfigRMMDetails.RMMURL);
        this.driver.get(rmmurl.getRmmUrl());
        this.waitForLoginPageIsReady();

        // Filling username and password
        UserTest user = UserFactory.getUser(userDomain, userType);
        this.getElementByXPath(USER_NAME).sendKeys(user.getUsername());
        this.driver.sleep(1);
        this.getElementByXPath(PASSWORD).sendKeys(user.getPassword());
        this.driver.sleep(1);

        // Click on Sign in
        this.getElementByXPath(SIGNIN_BUTTON).click();
        this.driver.sleep(10);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End rmmLogin method");

    }

    /**
     * This method will logout the RMM
     */

    public void rmmLoginOut() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start rmmLoginOut method");

        // this.waitForByXPath(USER_PROFILE_BUTTON);

        // Click on logout
        this.getElementByXPath(USER_PROFILE_BUTTON).click();
        this.waitForByXPath(LOGOUT_BUTTON);
        this.getElementByXPath(LOGOUT_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End rmmLoginOut method");

    }

    /**
     * This method will click on Upload button
    */

    public void clickOnUploadTask() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnUploadTask method");

        this.waitForReady();

        // Click on Upload button
        this.getElementByXPath(UPLOAD_BUTTON).click();
        this.driver.sleep(3);

        // Selecting Upload workflow
        this.getElementByXPath(UPLOAD_WORKFLOW_BUTTON).click();
        this.driver.sleep(15);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnUploadTask method");
    }

    /**
     * This method will click on Add file button
    */

    public void clickOnAddFileButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnAddFileButton method");

        this.waitForByXPath(ADD_FILE_BUTTON);

        this.getElementByXPath(ADD_FILE_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnAddFileButton method");
    }

    /**
     * This method to select file and handle windows popup dialog to upload data
     * @throws IOException
    */

    public void uploadData() throws IOException {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start uploadData method");

        String separate = System.getProperty("file.separator");

        String path = System.getProperty("user.dir") + separate + "src" + separate + "main" + separate + "resources"
                + separate + "files" + separate + "images" + separate + "RMM_TestData.zip";

        String autoITExecutable = System.getProperty("user.dir") + separate + "src" + separate + "main" + separate
                + "resources" + separate + "files" + separate + "software" + separate + "ProfilePictureUpload.exe" + " "
                + path;

        Runtime.getRuntime().exec(autoITExecutable);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End uploadData method");
    }

    /**
     * This method to select UncompressZip CheckBox
    */

    public void selectUncompressZipCheckBox() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectUncompressZipCheckBox method");

        this.waitForByXPath(UNCOMPRESS_ZIPCHECK);

        // Click on Add file button
        this.getElementByXPath(UNCOMPRESS_ZIPCHECK).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectUncompressZipCheckBox method");
    }

    /**
     * This method to click on OK button
    */

    public void clickOnOK() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnOK method");

        this.waitForByXPath(OK_BUTTON);

        // Click on Add file button
        this.getElementByXPath(OK_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnOK method");
    }

    /**
     * This method to click on closeUploadDailog button
    */

    public void closeUploadDailog() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start closeUploadDailog method");

        // Click on close button
        this.getElementByXPath(CLOSE_DAILOG).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End closeUploadDailog method");
    }

    /**
     * This method to click on ActivityManager button
    */

    public void clickOnActivityManagerButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start clickOnActivityManagerButton method");

        this.waitForByXPath(ACTIVITY_MANAGER_BUTTON);

        // Click on Add file button
        this.getElementByXPath(ACTIVITY_MANAGER_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnActivityManagerButton method");
    }

    /**
     * This method to check of upload is done or not
    */

    public void checkForUploadComplete() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkForUploadComplete method");

        this.waitForByXPath(PENDING_COUNT_BUTTON);

        // Click on Pending button
        this.getPendingCount();

        if (PENDINGCOUNT != 0) {

            for (int i = 0; i < 10; i++) {

                this.getPendingCount();

                if (PENDINGCOUNT == 0) {
                    break;
                }
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkForUploadComplete method");

    }

    /**
     * This method to get pending count
    */

    public void getPendingCount() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getPendingCount method");

        // this.waitForByXPath(PENDING_COUNT_BUTTON);

        // Click on Pending button
        this.getElementByXPath(PENDING_COUNT_BUTTON).click();
        driver.sleep(3);

        String count = this.getElementByXPath(PENDING_COUNT).getText();

        PENDINGCOUNT = Integer.parseInt(count);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getPendingCount method");
    }

}
