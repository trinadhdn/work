/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.assetDetails.components;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.saveInCollection.SaveInCollectionInterface;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the SaveInCollection component
 * of the AssetDetails modal.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class AssetDetailsSaveInCollectionPage extends PCBasePage implements SaveInCollectionInterface {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(AssetDetailsSaveInCollectionPage.class);

    /**
     * Components
     */
    private volatile boolean isOpen;

    /**
     * Items keys selectors.
     */
    private final static String EXPAND_BUTTON = "expandSaveInButton";

    private final static String IN_EXISTING_DROPDOWN = "inExistingDropDown";
    private final static String IN_EXISTING_OPTIONS = "inExistingOptions";

    private final static String CREATE_NEW_INPUT = "createNewInput";
    private final static String CREATE_NEW_BUTTON = "createNewButton";
    private final static String TYPE_COLL_DROPDOWN = "typeCollectionDropDown";
    private final static String TYPE_COLL_OPTIONS = "typeCollectionOptions";

    private final static String TAGS_COLLECTION = "tagCollectionToSaveIn";
    private final static String X_BTN_TAGS_COLLECTION = "xButtonTagCollectionToSaveIn";

    private final static String CANCEL_BUTTON = "cancelButton";
    private final static String OK_BUTTON = "okButton";

    /**
     * Constructor method
     * 
     * @param driver
     *            selenium webdriver
     */
    public AssetDetailsSaveInCollectionPage(EmergyaWebDriver driver) {
        super(driver);
        this.isOpen = this.isAssetDetailsSaveInCollectionComponentOpen();
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 5; i++) {

            if (this.isElementVisibleByXPath(EXPAND_BUTTON)) {
                isReady = true;
                if (this.isOpen) {// If is opened the components should be
                                  // shown.
                    if (this.isElementVisibleByXPath(IN_EXISTING_DROPDOWN)
                            && this.isElementVisibleByXPath(CREATE_NEW_INPUT)
                            && this.isElementVisibleByXPath(CREATE_NEW_BUTTON)
                            && this.isElementVisibleByXPath(TYPE_COLL_DROPDOWN)
                            && this.isElementVisibleByXPath(CANCEL_BUTTON) && this.isElementVisibleByXPath(OK_BUTTON)) {
                        isReady = true;
                    } else {
                        isReady = false;
                    }
                }
            }
            if (isReady) {
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(EXPAND_BUTTON);
        if (this.isOpen) { // If is opened the components should be waited.
            this.waitForByXPath(IN_EXISTING_DROPDOWN);
            this.waitForByXPath(CREATE_NEW_INPUT);
            this.waitForByXPath(CREATE_NEW_BUTTON);
            this.waitForByXPath(TYPE_COLL_DROPDOWN);
            this.waitForByXPath(CANCEL_BUTTON);
            this.waitForByXPath(OK_BUTTON);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return true if the panel is open, false if it is collapsed.
     */
    private synchronized boolean isAssetDetailsSaveInCollectionComponentOpen() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isAssetDetailsSaveInCollectionComponentOpen method");

        boolean isOpen = false;
        try {
            // aria-expanded = true: this complement is expanded
            if (this.getElementByXPath(EXPAND_BUTTON, 5).getAttribute("aria-expanded").contains("true")) {
                isOpen = true;
            }
        } catch (Exception e) {
            isOpen = false;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isAssetDetailsSaveInCollectionComponentOpen method");

        return isOpen;
    }

    /**
     * Method to open the panel of the SaveInCollection component.
     */
    public synchronized void open() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start open method");

        if (!this.isOpen) {

            this.expandAssetActionsInMobileView();
            this.getElementByXPath(EXPAND_BUTTON).click();
            this.isOpen = true;
            this.waitForByXPath(TYPE_COLL_DROPDOWN);
        }
        assertTrue("SaveInCollection component is not open.", this.isAssetDetailsSaveInCollectionComponentOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End open method");
    }

    /**
     * Method to close the panel of the SaveInCollection component.
     */
    public synchronized void close() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start close method");

        if (this.isOpen) {
            this.expandAssetActionsInMobileView();
            this.getElementByXPath(EXPAND_BUTTON).click();
            this.isOpen = false;
            this.waitUntilDisappearByXPath(TYPE_COLL_DROPDOWN);
        }
        assertTrue("SaveInCollection component is not collapsed.", !this.isAssetDetailsSaveInCollectionComponentOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End close method");
    }

    /**
     * Method to add the assets to a new collection:
     * 
     * @param title
     *            of the new collection.
     * @param type
     *            of the new collection.
     */
    public void addToNewCollection(String title, String type) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addToNewCollection method");

        boolean found = false;
        Select select = new Select(this.getElementByXPath(TYPE_COLL_DROPDOWN));
        List<WebElement> options = select.getOptions();

        // Select the correct type.
        for (WebElement option : options) {
            if (option.getText().equals(type)) {
                found = true;
                select.selectByVisibleText(type);
                this.scrollTop();
                this.driver.sleep(1);

                // Type the title of the collection.
                this.getElementByXPath(CREATE_NEW_INPUT).sendKeys(title);
                this.driver.sleep(1);

                // Add the collection.
                this.getElementByXPath(CREATE_NEW_BUTTON).click();
                this.waitForByXPath(TAGS_COLLECTION);
                this.waitForByXPath(X_BTN_TAGS_COLLECTION);
                assertTrue("The titles don't match.", this.checkCollectionIsSavingThisAsset(title) != null);

                // Confirm the creation of the new collection and the assets
                // saving in it.
                this.driver.sleep(1);
                this.getElementByXPath(OK_BUTTON).click();
                if (this.isElementVisibleByXPath(OK_MODAL_BUTTON, 1)) {
                    this.getElementByXPath(OK_MODAL_BUTTON).click();
                    this.waitUntilDisappearByXPath(OK_MODAL_BUTTON);
                }

                // The complement will collapse automatically.
                this.isOpen = false;
                this.waitUntilDisappearByXPath(SPINNER);
                this.waitUntilDisappearByXPath(OK_BUTTON);

            }
        }
        if (!found) {
            assertTrue("Unable to select the collection type which is - " + type, found);

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End addToNewCollection method");
    }

    /**
     * Method to add the assets to a existing collection:
     * 
     * @param title
     *            of the existing collection.
     * 
     */
    public synchronized void addToExistingCollection(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addToExistingCollection method");

        // Open dropdown of the existing collections.
        this.getElementByXPath(IN_EXISTING_DROPDOWN).click();

        boolean found = false;
        int index = 0;
        // Search for the collection index with the proper name.
        while (!found && index < this.getElementsByXPath(IN_EXISTING_OPTIONS).size()) {
            if (this.getElementsByXPath(IN_EXISTING_OPTIONS).get(index).getAttribute("title").equalsIgnoreCase(name)) {
                // When found, perform a click action on this option.
                found = true;
                WebElement option = this.getElementsByXPath(IN_EXISTING_OPTIONS, 1).get(index);
                if (!option.isDisplayed()) {
                    this.scrollTo(option);
                }
                this.driver.sleep(3);
                option.click();
                assertTrue("The collection is already added. collection name - "
                        + option.getText(), !(this.isOkOfModalShown() && this.isCollAlreadyTextPresent()));

            } else {
                index++;
            }
        }
        // Close the dropdown.
        this.getElementByXPath(IN_EXISTING_DROPDOWN).click();

        // Add the collection.
        this.waitForByXPath(TAGS_COLLECTION, 2);
        this.waitForByXPath(X_BTN_TAGS_COLLECTION, 2);
        assertTrue("The titles don't match.", this.getElementsByXPath(TAGS_COLLECTION)
                .get(this.checkCollectionIsSavingThisAsset(name)).getText().trim().split(":")[1].trim()
                        .equalsIgnoreCase(name));

        // Confirm the creation of the new collection and the assets saving in
        // it.
        this.driver.sleep(1);
        this.getElementByXPath(OK_BUTTON).click();

        this.isOpen = false;
        if (this.isElementVisibleByXPath(OK_MODAL_BUTTON, 1)) {
            this.getElementByXPath(OK_MODAL_BUTTON).click();
            this.waitUntilDisappearByXPath(OK_MODAL_BUTTON);
        }
        this.waitUntilDisappearByXPath(SPINNER);
        this.waitUntilDisappearByXPath(OK_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End addToExistingCollection method");
    }

    /**
     * Method for obtain the position of the given collection:
     * 
     * @param title
     *            of the existing collection.
     * @return index of the position of the collection, null is not found.
     */
    public synchronized Integer checkCollectionIsSavingThisAsset(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkCollection method");

        // Search for the given collection
        List<WebElement> collectionTags = this.getElementsByXPath(TAGS_COLLECTION);
        boolean isFound = false;
        Integer index = 0;

        while (!isFound && index < collectionTags.size()) {
            if (collectionTags.get(index).getText().split(":")[1].trim().equalsIgnoreCase(name)) {
                isFound = true;
            } else {
                index++;
            }

        }
        if (!isFound) {
            index = null;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkCollection method");

        return index;
    }

    /**
     * Method for delete an asset from a collection:
     * 
     * @param title
     *            of an existing collection to delete.
     */
    public synchronized void deleteAssetOfCollection(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteAssetOfCollection method");

        Integer index = checkCollectionIsSavingThisAsset(name);
        // Click in the element
        this.getElementsByXPath(X_BTN_TAGS_COLLECTION).get(index).click();
        this.driver.sleep(1);

        // Save the changes.
        this.waitUntilElementVisibileByXPath(OK_BUTTON);
        this.waitUntilElementClickableByXPath(OK_BUTTON);
        this.getElementByXPath(OK_BUTTON).click();
        this.isOpen = false;
        this.waitUntilDisappearByXPath(OK_BUTTON);
        if (this.isElementVisibleByXPath(OK_MODAL_BUTTON, 1)) {
            this.getElementByXPath(OK_MODAL_BUTTON).click();
            this.waitUntilDisappearByXPath(OK_MODAL_BUTTON);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteAssetOfCollection method");
    }

    /**
     * Method for delete an asset from a collection:
     * 
     * @param Container
     *            of the assets to recharge after deletion.
     * @param title
     *            of an existing collection to delete.
     */
    public synchronized void deleteAssetOfCollection(ContainerAssetsPage containerAssets, String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteAssetOfCollection method");

        this.deleteAssetOfCollection(name);

        containerAssets.initializeList();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteAssetOfCollection method");
    }

    /**
     * Method to verify Collection already present text.
     * 
     * @return returns a boolean value based on the text present or not.
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     */
    public boolean isCollAlreadyTextPresent() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isCollAlreadyTextPresent method");

        boolean textPresent = false;
        String expectedMessage = this.textShownInModalS();
        String actualMessage = "This collection is already added.";

        if (expectedMessage.contains(actualMessage)) {
            textPresent = true;
            this.driver.sleep(1);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isCollAlreadyTextPresent method");

        return textPresent;
    }

}
