/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.folders.folderAssets;

import static org.testng.AssertJUnit.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.assetDetails.AssetDetailsPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.containerAssets.assetPreview.AssetPreviewPage;
import com.opentext.pageObjects.containerAssets.assetPreview.specificViews.AssetPreviewListViewPage;
import com.opentext.pageObjects.containerAssets.assetPreview.specificViews.AssetPreviewThumbsViewPage;
import com.opentext.pageObjects.folders.FoldersPage;
import com.opentext.pageObjects.search.SearchPage;
import com.opentext.pageObjects.singleDownload.specificModal.SingleDownloadPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.AssetCategoryValues.AssetType;

/**
 * This PO contains the methods to interact with the folder assets.
 * 
 * @author Sowjanya Lankadasu <slankada@opentext.com>
 */
public class FolderAssetsPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(FolderAssetsPage.class);

    /**
     * Components
     */
    protected CopyOnWriteArrayList<AssetPreviewPage> assetsPreviews;
    private volatile boolean thumbsView;

    /**
     * Items keys selectors.
     */

    private final static String LIST_ASSETS = "listAssets";
    private final static String LIST_SELECTED = "listSelected";

    private final static String NOTFOUND_TEXT = "notFoundText";

    private final static String BACK_TO_TOP = "backToTop";
    protected final static String SPINNER_MORE_ASSETS = "spinnerMoreAssets";
    private final static String ITEMS_LEFT = "itemsLeft";

    /**
     * Constructor method.
     * 
     * @param driver selenium webdriver.
     * @param true if we are in thumbsview, false if we are in listview.
     */
    public FolderAssetsPage(EmergyaWebDriver driver, boolean thumbsView) {
        super(driver);

        this.thumbsView = thumbsView;
        this.initializeList();
        this.isReady();
    }

    /**
     * Method to initialize the list.
     */
    public synchronized void initializeList() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start initializeList method");

        this.waitUntilDisappearByXPath(SPINNER);
        this.waitUntilDisappearByXPath(SPINNER_MORE_ASSETS);
        if (!(this.isElementVisibleByXPath(NOTFOUND_TEXT))) {
            assetsPreviews = new CopyOnWriteArrayList<AssetPreviewPage>();
            if (thumbsView) {
                // Thumbs view
                for (int i = 0; i < this.getNumberOfAssetsShown(); i++) {
                    assetsPreviews.add(new AssetPreviewThumbsViewPage(driver, i));
                }
            } else {
                // List view
                for (int i = 0; i < this.getNumberOfAssetsShown(); i++) {
                    assetsPreviews.add(new AssetPreviewListViewPage(driver, i));
                }
            }
        } else {
            assetsPreviews = null;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End initializeList method");
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = true;
        if (!(this.isElementVisibleByXPath(NOTFOUND_TEXT))) {
            for (int i = 0; i < assetsPreviews.size() && isReady; i++) {
                if (!assetsPreviews.get(i).isReady()) {
                    isReady = false;
                }
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        if (!(this.isElementVisibleByXPath(NOTFOUND_TEXT))) {
            for (int i = 0; i < assetsPreviews.size(); i++) {
                assetsPreviews.get(i).waitForReady();
            }
        } else { // Wait for NOTFOUND_TEXT if there are not assets.
            this.waitForByXPath(NOTFOUND_TEXT);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * This method will verify whether assets are present in the selected folder or not.
     * 
     * @return whether the assets are present of not.
     */

    public synchronized boolean isNoResultsFoundTest() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isNoResultsFoundTest method");

        boolean isPresent = false;
        if ((this.isElementVisibleByXPath(NOTFOUND_TEXT))) {
            isPresent = true;
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isNoResultsFoundTest method");

        return isPresent;
    }

    /**
     * @return number of assets shown.
     */
    public synchronized int getNumberOfAssetsShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumberOfAssetsShown method");

        this.waitUntilDisappearByXPath(SPINNER);
        this.waitForByXPath(LIST_ASSETS);
        this.driver.sleep(2);
        int counterAssetsShown = 0;
        for (int i = 0; i <= 3; i++) {
            if (this.retryAndGetElementsByXPath(LIST_ASSETS)) {
                if (this.getElementsByXPath(LIST_ASSETS).size() != 0) {
                    counterAssetsShown = this.getElementsByXPath(LIST_ASSETS).size();
                    break;
                }

            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumberOfAssetsShown method");

        return counterAssetsShown;
    }

    /**
    * Method to select randomly the assets shown, using Ctrl Key.
    * 
    * @param searchPage
    *            to get the focus out.
    * @return Integer number of selected assets.
    */
    public Integer selectRandomAssetsUsingCtrlKey(FoldersPage foldersPage) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectRandomAssetsUsingCtrlKey method");

        int numberOfSelected = 0;
        boolean selected = false;

        action.keyDown(Keys.LEFT_CONTROL).perform();
        List<WebElement> listofAssets = this.getElementsByXPath(LIST_ASSETS);

        do {
            numberOfSelected = 0;
            for (int index = 0; index < assetsPreviews.size(); index++) {
                if ((int) (Math.random() * 2 + 1) == 1) { // If a random number
                                                          // between 1 & 2 is
                                                          // equal to 1
                    ((AssetPreviewThumbsViewPage) assetsPreviews.get(index)).selectAssets(listofAssets.get(index));
                    foldersPage.getHeader().getFocusOnLogo();
                    numberOfSelected++;
                    selected = true;
                }
            }
        } while (!selected);

        action.keyUp(Keys.LEFT_CONTROL).perform();

        SearchPage searchPage = new SearchPage(driver, "folderPage");
        assertTrue("The download button should be shown.", searchPage.isDownloadButtonShown());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectRandomAssetsUsingCtrlKey method");

        return numberOfSelected;
    }

    /*
    *//**
      * @return the counter of selected assets.
      *//*
        public int getCountOfSelected() {
         log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCountOfSelected method");
        
         int count = 0;
         if (this.isElementVisibleByXPath(LIST_SELECTED)) {
             count = this.getElementsByXPath(LIST_SELECTED).size();
         }
        
         log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCountOfSelected method");
        
         return count;
        }*/

    /**
     * Method to select a range of assets from/to given index, using Shift key.
     * 
     * @param searchPage
     *            to get the focus out.
     * @param index
     *            of the first asset to select.
     * @param index
     *            of the last asset to select.
     * @return Integer number of selected assets.
     */
    public int selectAssetsUsingShiftKey(FoldersPage folderspage, int first, int last) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAssetsUsingShiftKey method");

        int numberOfSelected = 0;
        folderspage.getHeader().getFocusOnLogo();
        List<WebElement> listofAssets = this.getElementsByXPath(LIST_ASSETS);
        action.keyDown(Keys.LEFT_SHIFT).perform();

        if (first >= 0 && first < assetsPreviews.size() && last >= 0 && last <= assetsPreviews.size()) {
            ((AssetPreviewThumbsViewPage) assetsPreviews.get(first)).selectAssets(listofAssets.get(first));
            ((AssetPreviewThumbsViewPage) assetsPreviews.get(last)).selectAssets(listofAssets.get(last));
            folderspage.getHeader().getFocusOnLogo();
            numberOfSelected = Math.abs(first - last) + 1;
        }

        action.keyUp(Keys.LEFT_SHIFT).perform();
        SearchPage searchPage = new SearchPage(driver, "folderPage");
        assertTrue("The download button should be shown.", searchPage.isDownloadButtonShown());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAssetsUsingShiftKey method");

        return numberOfSelected;
    }

    /**
     * @return a random index of an asset shown.
     */
    public synchronized int getRandomIndexOfAssetsShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getRandomIndexOfAssetsShown method");

        if (this.driver.findElement(By.xpath("//label[@pc-id = 'listview']")).getAttribute("class")
                .contains("active")) {

            this.thumbsView = false;
            this.initializeList();

        }

        // If a random number between (the size assetsPreviews -1) & 0.
        int index = (int) (Math.random() * (assetsPreviews.size() - 1) + 0);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getRandomIndexOfAssetsShown method");

        return index;
    }

    /**
      * Method to navigate to the SingleDownload modal of the given asset.
      * 
      * @param index
      *            of the asset to take the SingleDownload modal.
      * @return SingleDownload modal ready to work with.
      */
    public SingleDownloadPage goToSingleDownloadOfTheAsset(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start goToSingleDownloadOfTheAsset method");

        SingleDownloadPage singleDownload = assetsPreviews.get(index).goToSingleDownloadModal();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToSingleDownloadOfTheAsset method");

        return singleDownload;
    }

    /**
     * Method to navigate to the AssetDetails modal of the given asset.
     * 
     * @param index
     *            of the asset to take the AssetDetails modal.
     * @return AssetDetails modal ready to work with.
     */
    public synchronized AssetDetailsPage goToAssetDetails(int index, AssetType assetType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToAssetDetails method");

        AssetDetailsPage assetDetails = assetsPreviews.get(index).goToAssetDetails(assetType);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToAssetDetails method");

        return assetDetails;
    }

    /**
        * Method to navigate to the AssetDetails modal of the given asset.
        * 
        * @param index
        *            of the asset to take the AssetDetails modal.
        * @return AssetDetails modal ready to work with.
        */

    public synchronized String getAssetID(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getAssetID method");

        String assetDetails = assetsPreviews.get(index).getAssetId(index);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAssetID method");

        return assetDetails;
    }

    /**
     * @return list of assets IDs of every asset shown.
     */
    public List<String> getAssetIDsOfAssetsShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getAssetIDsOfAssetsShown method");

        ContainerAssetsPage containerAssetsPage = new ContainerAssetsPage(DriverManager.getDriver());

        // Scroll extreme down to last asset in search page
        containerAssetsPage.scrollToDown();
        if (assetsPreviews == null) {
            this.initializeList();
        }

        List<String> assetsIDs = new ArrayList<String>();

        // For every assetPreview we get its assetID.
        for (AssetPreviewPage assetPreview : assetsPreviews) {
            assetsIDs.add(assetPreview.getAssetId(assetsPreviews.lastIndexOf(assetPreview)));
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAssetIDsOfAssetsShown method");

        return assetsIDs;
    }

    /**
        * Method to give back the asset IDs of the given asset.
        * 
        * @param index
        *            of the asset position
        * @return asset IDs of the given asset.
        */
    public String getAssetIDsOfAsset(int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getAssetIDsOfAsset method");

        if (assetsPreviews == null) {
            this.initializeList();
        }

        String assetsIDs = assetsPreviews.get(index).getAssetId(index);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAssetIDsOfAsset method");

        return assetsIDs;
    }

    /**
     * Method to get all the selected assets ID`s
     * 
     * @return list of assets IDs of all selected assets.
     * @author Sowjanya Lankadasu <slankada@opentext.com>
     */
    public List<String> getAssetIDsOfAssetsSelected() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getAssetIDsOfAssetsSelected method");

        List<WebElement> selectedIDs = this.getElementsByXPath(LIST_SELECTED);
        List<String> assetsIDs = new ArrayList<String>();

        if (selectedIDs.size() != 0) {
            // For every assetPreview we get its assetID.
            for (WebElement selected : selectedIDs) {
                if (selected.getAttribute("class").contains("selected")) {
                    String assetID = selected.getAttribute("data-id");
                    assetsIDs.add(assetID);
                }
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getAssetIDsOfAssetsSelected method");

        return assetsIDs;
    }
}
