/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.folders;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.folders.folderAssets.FolderAssetsPage;
import com.opentext.pageObjects.folders.foldersSideBar.FoldersSideBar;
import com.opentext.pageObjects.footer.FooterPage;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.pageObjects.saveInCollection.SaveInCollectionPage;
import com.opentext.pageObjects.search.SearchPage;
import com.opentext.pageObjects.singleDownload.specificModal.MultiDownloadPage;
import com.opentext.pageObjects.sortBy.SortByPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Folder page.
 * 
 * @author Sowjanya Lankadasu <slankada@opentext.com>
 */
public class FoldersPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(FoldersPage.class);

    /**
     * Components
     */
    private HeaderPage header;
    private SaveInCollectionPage saveInCollection;
    private SortByPage sortBy;
    private ContainerAssetsPage containerAssets;
    private FoldersSideBar foldersSideBar;
    private FolderAssetsPage folderAssetsPage;
    private FooterPage footer;

    /**
     * Items keys selectors.
     */
    private final static String DOWNLOAD_BUTTON = "downloadButton";

    private final static String THUMBSVIEW_BUTTON = "thumbsViewButton";
    private final static String LISTVIEW_BUTTON = "listViewButton";

    private final static String FOLDER_BUTTON = "folderButton";
    private final static String BACK_TO_SEARCH_BUTTON = "backToSearchButton";

    /**
     * Constructor method
     * 
     * @param driver selenium webdriver
     */
    public FoldersPage(EmergyaWebDriver driver) {
        super(driver);
        header = new HeaderPage(driver);
        saveInCollection = new SaveInCollectionPage(driver);
        // foldersSideBar = new FoldersSideBar(driver);
        // folderAssetsPage = new FolderAssetsPage(driver, this.isThumbsViewActive());
        sortBy = new SortByPage(driver);
        footer = new FooterPage(driver);
        // this.isReady();
    }

    /**
     * Constructor method
     * 
     * @param driver selenium webdriver
     */
    public FoldersPage(EmergyaWebDriver driver, String clientName) {
        super(driver);

    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        foldersSideBar = new FoldersSideBar(driver);
        boolean isReady = false;
        for (int i = 0; i <= 3; i++) {
            if (header.isReady() && saveInCollection.isReady() && sortBy.isReady() && footer.isReady()
                    && foldersSideBar.isReady() /*&& folderAssets.isReady()*/
                    && this.isElementVisibleByXPath(THUMBSVIEW_BUTTON)
                    && this.isElementVisibleByXPath(LISTVIEW_BUTTON)) {
                isReady = true;
                break;
            }
            // this.driver.navigate().refresh();

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        foldersSideBar = new FoldersSideBar(driver);
        header.waitForReady();
        saveInCollection.waitForReady();
        foldersSideBar.waitForReady();
        sortBy.waitForReady();
        // folderAssets.waitForReady();
        footer.waitForReady();
        this.waitForByXPath(THUMBSVIEW_BUTTON);
        this.waitForByXPath(LISTVIEW_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to go to folder page.
     * 
     */
    public void clickOnFolderButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnFolderButton method");

        this.getElementByXPath(FOLDER_BUTTON).click();
        this.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnFolderButton method");
    }

    /**
    * Method to click on back to search button.
    * 
    * @return search page ready to work.
    */
    public SearchPage clickOnBackToSearchButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnBackToSearchButton method");

        this.getElementByXPath(BACK_TO_SEARCH_BUTTON).click();

        SearchPage searchPage = new SearchPage(driver);
        searchPage.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnBackToSearchButton method");

        return searchPage;
    }

    /**
     * Method to charge more assets using Scroll.
     */
    public synchronized void scrollToChargeMoreAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start scrollToChargeMoreAssets method");

        containerAssets.scrollToChargeMoreAssets();
        this.scrollTop();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End scrollToChargeMoreAssets method");
    }

    /**
     * @return True if is ThumbsView active, false if is ListView active
     */
    public boolean isThumbsViewActive() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isThumbsViewActive method");
        String thumbButtonClass = null;
        boolean thumbsViewActive = false;
        if (this.retryAndGetElementByXPath(THUMBSVIEW_BUTTON)) {
            thumbButtonClass = this.getElementByXPath(THUMBSVIEW_BUTTON).getAttribute("class").trim();
            thumbsViewActive = thumbButtonClass.contains("active");
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isThumbsViewActive method");

        return thumbsViewActive;
    }

    /**
     * @return Header page.
     */
    public HeaderPage getHeader() {
        return header;
    }

    /**
      * @return FolderAssets page.
      */
    public FolderAssetsPage getFolderContainerAssets() {
        folderAssetsPage = new FolderAssetsPage(driver, this.isThumbsViewActive());
        return folderAssetsPage;
    }

    /**
     * @return ContainerAssets page.
     */
    public FoldersSideBar getFolderSideBar() {
        return foldersSideBar;
    }

    /**
     * @return ContainerAssets page.
     */
    public ContainerAssetsPage getContainerAssets() {
        return containerAssets;
    }

    /**
      * Method to open the panel of the SaveInCollection component.
      * 
      * @return SaveInCollection ready to work with.
      */
    public synchronized SaveInCollectionPage openSaveInCollection() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start openSaveInCollection method");

        saveInCollection.openInFoldersPage();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End openSaveInCollection method");

        return saveInCollection;
    }

    /**
     * Method to navigate to the MultiDownload modal of the selected assets.
     * 
     * @param counter
     *            of the selected.
     * @return MultiDownloadPage ready to work with, or null if there was no
     *         selected assets.
     */
    public synchronized MultiDownloadPage goToMultiDownloadOfTheAssets(int counterSelected) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start goToMultiDownloadOfTheAssets method");

        MultiDownloadPage multiDownload = null;
        SearchPage searchPage = new SearchPage(driver, "folderPage");

        folderAssetsPage = new FolderAssetsPage(driver, this.isThumbsViewActive());
        ContainerAssetsPage containerAssetsPage = new ContainerAssetsPage(driver);
        if (containerAssetsPage.getCountOfSelected() > 0 && searchPage.isDownloadButtonShown()) {

            this.getElementByXPath(DOWNLOAD_BUTTON).click();

            multiDownload = new MultiDownloadPage(driver);
            multiDownload.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToMultiDownloadOfTheAssets method");

        return multiDownload;
    }

}
