/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.folders.foldersSideBar;

import static org.testng.AssertJUnit.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.folders.FoldersPage;
import com.opentext.pageObjects.folders.folderAssets.FolderAssetsPage;
import com.opentext.pageObjects.saveInCollection.SaveInCollectionPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Folder page.
 * 
 * @author Sowjanya Lankadasu <slankada@opentext.com>
 */
public class FoldersSideBar extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(FoldersSideBar.class);

    /**
     * Components
     */
    private volatile boolean isOpen;
    private FolderAssetsPage folderAssetsPage;
    private FoldersPage foldersPage;
    private SaveInCollectionPage saveInCollection;

    /**
     * Items keys selectors.
     */
    private final static String DOWNLOAD_BUTTON = "downloadButton";

    private final static String ALL_FOLDERS_LIST = "allFoldersList";
    private final static String HIDE_FOLDER_BUTTON = "hideFolderButton";
    private final static String SHOW_FOLDER_BUTTON = "showFolderButton";
    private final static String PUBLIC_FOLDER_LIST = "publicFolderList";
    private final static String EXPAND_BUTTON_PUBLIC_FOLDERS = "expandButtonPublicFolders";
    private final static String ALL_EXPAND_BTN = "allExpandBtn";
    private final static String FOLDER_WRAPPER = "folderWrapper";
    private final static String FOLDER_NAME_LIST = "folderNameList";
    private final static String PUBLIC_FOLDER_ARROW_BUTTON = "publicFolderArrowButton";
    private final static String PUBLIC_FOLDERS = "publicFolders";

    /**
     * Constructor method
     * 
     * @param driver selenium webdriver
     */
    public FoldersSideBar(EmergyaWebDriver driver) {
        super(driver);
        this.isOpen = this.isFoldersSideBarOpen();
        foldersPage = new FoldersPage(driver);
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 3; i++) {
            if (this.isOpen) {
                if (this.isElementVisibleByXPath(FOLDER_WRAPPER) && this.isElementVisibleByXPath(ALL_FOLDERS_LIST)
                        && this.isElementVisibleByXPath(HIDE_FOLDER_BUTTON)) {
                    isReady = true;
                    break;
                }
                // this.driver.navigate().refresh();
            } else if (this.isElementVisibleByXPath(SHOW_FOLDER_BUTTON)) {
                isReady = true;
                break;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        if (this.isOpen) {
            this.waitForByXPath(FOLDER_WRAPPER);
            this.waitForByXPath(ALL_FOLDERS_LIST);
            this.waitForByXPath(HIDE_FOLDER_BUTTON);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return true if the folder side bar is open, false if it is closed.
     */
    public synchronized boolean isFoldersSideBarOpen() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isFoldersSideBarOpen method");

        boolean isOpen = false;
        try {
            if (!(this.getElementByXPath(FOLDER_WRAPPER).getAttribute("class").contains("toggled"))) {
                isOpen = true;
            }
        } catch (Exception e) {
            isOpen = false;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isFoldersSideBarOpen method");

        return isOpen;
    }

    /**
     * Method to close the panel of the Folder panel component.
     */
    public synchronized void hide() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start hide method");

        if (this.isFoldersSideBarOpen()) {
            this.getElementByXPath(HIDE_FOLDER_BUTTON).click();
            this.driver.sleep(2);
        }
        // assertTrue("Folders component is not collapsed.", !this.isFoldersSideBarOpen());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End hide method");
    }

    /**
     * Method to open the panel of the Folder panel component.
     */
    public synchronized void show() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start show method");

        if (!this.isFoldersSideBarOpen()) {
            this.getElementByXPath(SHOW_FOLDER_BUTTON).click();
            this.driver.sleep(2);
        }
        /*        assertTrue("Folders component is not Expanded.", this.isFoldersSideBarOpen());*/

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End show method");
    }

    /**
    * @return the number of folders present in the side bar
    */
    public synchronized int getNumOfFoldersSize() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getNumOfFoldersSize method");

        int size = 0;
        if (this.getElementsByXPath(ALL_FOLDERS_LIST).size() != 0) {
            size = this.getElementsByXPath(ALL_FOLDERS_LIST).size();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getNumOfFoldersSize method");

        return size;

    }

    /**
     * Method to verify whether public folder is listed in the folder tree.
     * 
     * @return whether the folder is available or not.
     */
    public synchronized boolean isPublicFolderthere() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isPublicFolderthere method");

        boolean isThere = false;
        List<WebElement> folders = this.getElementsByXPath(ALL_FOLDERS_LIST);

        for (WebElement folder : folders) {
            if (folder.getText().contains("Public Folders")) {
                isThere = true;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isPublicFolderthere method");

        return isThere;

    }

    /**
     * Method to click on the expand arrow.
     */
    public synchronized void clickOnAllExpandArrows() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnAllExpandArrows method");

        List<WebElement> allArrows = this.getElementsByXPath(ALL_EXPAND_BTN);

        assertTrue("There should be folders to expand.", this.getNumOfFoldersSize() >= 2);

        for (WebElement arrow : allArrows) {
            arrow.click();
            this.driver.sleep(2);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnAllExpandArrows method");
    }

    /**
     * Method to verify whether the fodlers are expanded or not.
     * 
     * @return whether the root folders are expanded or not.
     */
    public synchronized boolean isAllFoldersExpanded() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isAllFoldersExpanded method");

        boolean isExpanded = false;
        List<WebElement> allArrows = this.getElementsByXPath(ALL_EXPAND_BTN);

        for (WebElement arrow : allArrows) {
            if (arrow.getAttribute("style").contains("rotate(90deg)")) {
                isExpanded = true;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isAllFoldersExpanded method");

        return isExpanded;
    }

    /**
     * Method to expand all the public sub fodlers.
     */
    public synchronized int expandAllPublicFolders() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start expandAllPublicFolders method");

        String name = null;
        List<WebElement> allArrows = this.getElementsByXPath(EXPAND_BUTTON_PUBLIC_FOLDERS);
        List<String> publicNameList = new ArrayList<String>();

        assertTrue("All the root folders should be expanded to expand the public folder.", this.isAllFoldersExpanded());

        if (allArrows.size() == 0 && !this.isAllFoldersExpanded()) {
            this.getElementByXPath(PUBLIC_FOLDER_ARROW_BUTTON).click();
        }

        List<WebElement> allPublicFolders = this.getElementsByXPath(PUBLIC_FOLDER_LIST);
        // click on public folder
        allPublicFolders.get(0).click();

        // Expand all the sub-folders in public folders.
        for (int i = 0; i < allArrows.size(); i++) {
            this.driver.sleep(2);
            allArrows.get(i).click();
            this.driver.sleep(2);
            this.scrollBottom();
            name = allPublicFolders.get(i).getAttribute("data-folder-name");
            publicNameList.add(name);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start expandAllPublicFolders method");

        return publicNameList.size();
    }

    /**
     * Method to get Public folders List
     */
    public synchronized List<String> getPublicFoldersList() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start expandAllPublicFolders method");

        List<WebElement> allArrows = this.getElementsByXPath(EXPAND_BUTTON_PUBLIC_FOLDERS);

        String name = null;
        List<String> publicNameList = new ArrayList<String>();

        if (allArrows.size() == 0) {
            this.getElementByXPath(PUBLIC_FOLDER_ARROW_BUTTON).click();
        }

        List<WebElement> allPublicFolders = this.getElementsByXPath(PUBLIC_FOLDERS);
        // click on public folder
        allPublicFolders.get(0).click();

        // Expand all the sub-folders in public folders.
        for (int i = 0; i < allArrows.size(); i++) {
            /*this.driver.sleep(2);
            allArrows.get(i).click();
            this.driver.sleep(2);
            this.scrollBottom();*/
            name = allPublicFolders.get(i).getAttribute("title");
            publicNameList.add(name);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start expandAllPublicFolders method");

        return publicNameList;
    }

    /**
     * Method to verify whether all the public folders are expanded or not.
     * @param folder name count.
     * 
     * @return whether the folders are expanded or not.
     */
    public synchronized boolean isPublicFoldersExpanded(int folderNamesCount) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isPublicFoldersExpanded method");

        boolean isExpanded = false;
        int arrowCount = 0;

        List<WebElement> allArrows = this.getElementsByXPath(EXPAND_BUTTON_PUBLIC_FOLDERS);

        for (WebElement arrow : allArrows) {
            if (arrow.getAttribute("style").contains("rotate(90deg)")) {
                arrowCount++;
            }
        }

        if (folderNamesCount == arrowCount) {
            isExpanded = true;
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isPublicFoldersExpanded method");

        return isExpanded;
    }

    /**
     * Method to expand the sub fodlers for a given foder.
     */
    public synchronized void expandAGivenFolders(String folderName, int index) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start expandAGivenFolders method");

        List<WebElement> allArrows = this.getElementsByXPath(EXPAND_BUTTON_PUBLIC_FOLDERS);
        List<WebElement> allPublicFolders = this.getElementsByXPath(PUBLIC_FOLDER_LIST);

        for (WebElement arrow : allArrows) {
            if (allPublicFolders.get(index).getAttribute("data-folder-name").equals(folderName))
                arrow.click();
            this.driver.sleep(2);
            this.scrollBottom();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start expandAGivenFolders method");
    }

    /**
     * Method to find the number of subfolders in public folders.
     * 
     * @return number of sub-folders present in the folder.
     */
    public synchronized int subFoldersCount(String folderName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start subFoldersCount method");

        int subFolderCount = 0;
        List<WebElement> allPublicFolders = this.getElementsByXPath(PUBLIC_FOLDER_LIST);

        for (WebElement subfolder : allPublicFolders) {
            if (subfolder.getAttribute("data-folder-name").equals(folderName)) {
                String subFolder = subfolder.getAttribute("data-subfolder-count");
                subFolderCount = Integer.parseInt(subFolder);
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start subFoldersCount method");

        return subFolderCount;

    }

    /**
     * Method to navigate to the last node in the folder list.
     * 
     * @return number of sub-folders present in the folder.
     */
    public synchronized void navigateToLastNode() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start navigateToLastNode method");

        String folderName = null, subFolder = null;
        int subFolderCount = 0;
        boolean isThere = false;

        // get the list of forder
        List<WebElement> allPublicFolders = this.getElementsByXPath(PUBLIC_FOLDER_LIST);

        // navigate to the folde which has sub-fodlers.
        /*for (WebElement subfolder : allPublicFolders) {
        folderName = subfolder.getAttribute("data-folder-name");
        subFolder = subfolder.getAttribute("data-subfolder-count");
        subFolderCount = Integer.parseInt(subFolder);
        */

        if (allPublicFolders.size() != 0) {
            isThere = true;
            for (int i = 0; i <= allPublicFolders.size(); i++) {
                folderName = allPublicFolders.get(i).getAttribute("data-folder-name");

                // get the subfolder count
                subFolderCount = this.subFoldersCount(folderName);
                // If there are sub-folders then expand further

                if (subFolderCount >= 0) {
                    this.expandAGivenFolders(folderName, i);
                    this.driver.sleep(2);
                    this.scrollBottom();
                }
            }
        }

        assertTrue("There should be atleast one sub-folder under public folders. Create a folder in OTMM site.", isThere);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start navigateToLastNode method");

    }

    /**
     * Method to navigating to the sub folder in public folder tree.
     * 
     * @return returns the name of the folder which has assets or null.
     */
    public synchronized String goToSubFolderWithAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToSubFolderWithAssets method");

        String folderName = null;
        boolean isThere = false;
        List<WebElement> rootFolders = this.getElementsByXPath(PUBLIC_FOLDER_LIST);

        for (WebElement folder : rootFolders) {
            folderName = folder.getAttribute("data-folder-name");
            assertTrue("Unable to find the folder.", this.clickOnFolderName(folderName));

            folderAssetsPage = foldersPage.getFolderContainerAssets();
            if (!folderAssetsPage.isNoResultsFoundTest()) {
                isThere = true;
                break;
            }
        }

        assertTrue("There should be atleast one folder with assets. Please add assets.", isThere);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToSubFolderWithAssets method");

        return folderName;
    }

    /**
     * Method to navigating to the sub folder in public folder tree which has more than 5 assets.
     * 
     * @return returns the name of the folder which has assets or null.
     */
    public synchronized String goToSubFolderWithMoreThan5Assets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start goToSubFolderWithMoreThan5Assets method");

        String folderName = null;
        boolean isThere = false;
        List<WebElement> allPublicFolders = this.getElementsByXPath(PUBLIC_FOLDER_LIST);

        for (WebElement folder : allPublicFolders) {
            folderName = folder.getAttribute("data-folder-name");
            assertTrue("Unable to find the folder.", this.clickOnFolderName(folderName));

            // folderAssetsPage = foldersPage.getFolderContainerAssets(); TODO
            ContainerAssetsPage containerAssets = new ContainerAssetsPage(driver);
            List<String> assetsIDs = containerAssets.getAssetIDsOfAssetsShown();

            if (!folderAssetsPage.isNoResultsFoundTest() && assetsIDs.size() >= 5) {
                isThere = true;
                break;
            }
        }

        assertTrue("There should be atleast one folder with more than 5 assets. Please add assets.", isThere);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End goToSubFolderWithMoreThan5Assets method");

        return folderName;
    }

    /**
     * Method to click on given folder name.
     * 
     * @return whether the fodler is present or not.
     * 
     */
    public synchronized boolean clickOnFolderName(String folderName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnFolderName method");

        boolean isPresent = false;
        if (this.getElementsByXPath(FOLDER_NAME_LIST).size() != 0) {
            List<WebElement> folderList = this.getElementsByXPath(FOLDER_NAME_LIST);

            for (WebElement folder : folderList) {
                if (folder.getText().contains(folderName)) {
                    isPresent = true;
                    folder.click();
                    break;
                }
            }
        }

        folderAssetsPage = foldersPage.getFolderContainerAssets();
        // List<String> assetsIDs = folderAssetsPage.getAssetIDsOfAssetsShown();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnFolderName method");

        return isPresent;
    }

    /**
     * Method to find the active folder.
     * 
     * @return the folder name which is active
     */
    private synchronized boolean isFolderActive(String folderName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isFolderActive method");

        boolean isActive = false;

        if (this.getElementsByXPath(FOLDER_NAME_LIST).size() != 0) {
            List<WebElement> folderList = this.getElementsByXPath(FOLDER_NAME_LIST);

            for (WebElement folder : folderList) {
                if (folder.getAttribute("class").contains("active-folder")
                        && folder.getAttribute("title").contains(folderName)) {
                    isActive = true;
                    break;
                }

            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isFolderActive method");

        return isActive;

    }

    /**
     * Method to click on the folder which has assets.
     * @return return folderAssetPage object.
     * 
     */
    public FolderAssetsPage expandPublicFoldersEnterWithAssets() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start expandAllPublicFoldersEnterWithAssets method");

        String folderName = null;
        boolean isPresent = false;
        List<WebElement> allPublicFolders = this.getElementsByXPath(PUBLIC_FOLDER_LIST);

        if (this.getElementsByXPath(PUBLIC_FOLDER_LIST).size() != 0) {
            for (WebElement folder : allPublicFolders) {
                folderName = folder.getAttribute("data-folder-name");
                folder.click();
                this.driver.sleep(2);
                assertTrue("Folder : " + folderName + "should be active.", this.isFolderActive(folderName));
                folderAssetsPage = foldersPage.getFolderContainerAssets();

                if (!folderAssetsPage.isNoResultsFoundTest()) {
                    isPresent = true;
                    break;
                }
            }
        }

        assertTrue("There should be atleast one folder with assets.", isPresent);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start expandAllPublicFoldersEnterWithAssets method");

        return folderAssetsPage;
    }
}
