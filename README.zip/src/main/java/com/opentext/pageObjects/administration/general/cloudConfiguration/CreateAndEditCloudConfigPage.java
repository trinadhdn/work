/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.general.cloudConfiguration;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.GeneralSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.ConfigCloudStorage;
import com.opentext.utils.ConfigCloudStorage.ConfigCloudDetails;
import com.opentext.utils.ConfigFactory;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class CreateAndEditCloudConfigPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(CreateAndEditCloudConfigPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String GDRIVE_PROXY_ENABLED = "gdriveproxyenabled";

    private final static String PROXY_SERVER_NAME = "proxyservername";
    private final static String PROXY_PORT_INPUT = "proxyportinput";
    private final static String GDRIVE_CLIENT_ID = "gdriveclientid";
    private final static String GDRIVE_SECRET_ID = "gdrivesecret";
    private final static String CLIENTID_REQUIRED_FIELD_MESSAGE = "clientidrequiredFieldMessage";
    private final static String SECRET_REQUIRED_FIELD_MESSAGE = "secretrequiredFieldMessage";

    private final static String SAVE_BUTTON = "saveButton";
    private final static String SUSSESSFULLY_SAVED_MESSAGE = "successfullySavedMessage";
    private final static String CHECK_STATUS_MESSAGE = "checkstatusmessage";
    private final static String CHECK_GDRIVE_STATUS = "checkgdrivestatus";
    private final static String BACK_BUTTON = "backbutton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public CreateAndEditCloudConfigPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new GeneralSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(GDRIVE_PROXY_ENABLED) && this.isElementVisibleByXPath(PROXY_SERVER_NAME)
                && this.isElementVisibleByXPath(PROXY_PORT_INPUT) && this.isElementVisibleByXPath(GDRIVE_CLIENT_ID)
                && this.isElementVisibleByXPath(GDRIVE_SECRET_ID) && this.isElementVisibleByXPath(SAVE_BUTTON)
                && this.isElementVisibleByXPath(CHECK_GDRIVE_STATUS)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(GDRIVE_PROXY_ENABLED);
        this.waitForByXPath(PROXY_SERVER_NAME);

        this.waitForByXPath(PROXY_PORT_INPUT);
        this.waitForByXPath(GDRIVE_CLIENT_ID);
        this.waitForByXPath(GDRIVE_SECRET_ID);

        this.waitForByXPath(SAVE_BUTTON);
        this.waitForByXPath(CHECK_GDRIVE_STATUS);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the Cloud Config page.
     * @return dashboard
     */

    public  DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new  DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to save the new/edited cloud gdrive details.
     * @return {@link Email Service} ready to work with or null if the form wasn't completed.
     */
    public CreateAndEditCloudConfigPage clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(SAVE_BUTTON).click();
        this.driver.sleep(1);

        CreateAndEditCloudConfigPage mediabinservice = null;

        if (!(this.isElementVisibleByXPath(CLIENTID_REQUIRED_FIELD_MESSAGE, 1)
                && this.isElementVisibleByXPath(SECRET_REQUIRED_FIELD_MESSAGE, 1))) {
            // If no error is shown:
            this.waitUntilDisappearByXPath(SAVE_BUTTON);
            this.waitUntilDisappearByXPath(SPINNER);
            mediabinservice = new CreateAndEditCloudConfigPage(driver, this.getSectionsVisible());
            mediabinservice.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

        return mediabinservice;
    }

    /**
     * @return boolean about if required field message is shown or not
     */
    public boolean isRequiredFieldsMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isRequiredFieldMessageShown method");

        boolean isshown = false;
        if (this.isElementVisibleByXPath(CLIENTID_REQUIRED_FIELD_MESSAGE)
                && this.isElementVisibleByXPath(SECRET_REQUIRED_FIELD_MESSAGE)) {
            isshown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequiredFieldsMessageShown method");

        return isshown;
    }

    /**
     * Method to Create new Library service.
    */
    public void fillCloudConfigDetails(ConfigCloudDetails CLOUDCLIENTID, ConfigCloudDetails CLOUDSECRETID) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillCloudConfigDetails method");

        // Clear exsting data
        this.clearDeatils();

        // Fill details
        ConfigCloudStorage Config = ConfigFactory.getCloudConfig(CLOUDCLIENTID, CLOUDSECRETID);

        this.getElementByXPath(GDRIVE_CLIENT_ID).sendKeys(Config.getCloudClientID());
        this.getElementByXPath(GDRIVE_SECRET_ID).sendKeys(Config.getCloudSecretID());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillCloudConfigDetails method");

    }

    /**
     * Method to clear data .
    */
    public void clearDeatils() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clearDeatils method");

        this.getElementByXPath(GDRIVE_CLIENT_ID).clear();
        this.getElementByXPath(GDRIVE_SECRET_ID).clear();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clearDeatils method");

    }

    /**
     * Method to check Successfully created message.
     * @return boolean about if cloud details SAVED successfully or not.
    */
    public boolean isSuccessfullyCreatedMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isSuccessfullyCreatedMessageShown method");

        boolean isShown = false;
        if (this.getElementByXPath(SUSSESSFULLY_SAVED_MESSAGE).isDisplayed()) {
            String message = this.getElementByXPath(SUSSESSFULLY_SAVED_MESSAGE).getText();
            if (message.equalsIgnoreCase("Configuration successfully saved.")) {
                isShown = true;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isSuccessfullyCreatedMessageShown method");

        return isShown;

    }

    /**
     * Method to check the Cloud gdrive service.
     * @return boolean about if cloud service is working fine or not
    */
    public boolean checkGDriveStatus() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkGDriveStatus method");

        boolean checkgdrive = false;
        String parentWindow = this.getCurrentWindow();

        this.driver.sleep(1);
        this.getElementByXPath(CHECK_GDRIVE_STATUS).click();
        this.getElementByXPath(CHECK_GDRIVE_STATUS).click();
        this.driver.sleep(5);

        // Switching from parent window to child window
        this.switchToGoogleDriveWindowAndInputUserNameAndPassword();
        driver.sleep(2);
        this.switchToWindow(parentWindow);
        driver.sleep(3);
        this.waitForByXPath(CHECK_STATUS_MESSAGE);

        String message = this.getElementByXPath(CHECK_STATUS_MESSAGE).getText();
        if (message.equalsIgnoreCase("Google Drive is working properly.")) {
            checkgdrive = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkGDriveStatus method");

        return checkgdrive;

    }

    /**
     * Method to check the Invalid g cloud details 
     * @return boolean about if gdrive details are working fine or not
    */
    public boolean checkInvalidGdriveDetails() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkInvalidGdriveDetails method");

        boolean checkInvalidclouddetails = false;
        this.clearDeatils();
        this.getElementByXPath(CHECK_GDRIVE_STATUS).click();
        if (!(this.getElementByXPath(CHECK_STATUS_MESSAGE)).getAttribute("style").contains("display: block;")) {
            this.getElementByXPath(CHECK_GDRIVE_STATUS).click();
            this.waitForByXPath(CHECK_STATUS_MESSAGE);
        }
        this.driver.sleep(2);
        String message = this.getElementByXPath(CHECK_STATUS_MESSAGE).getText();

        if (message.contains("Google Drive is not working. Please, review your configuration.")) {
            checkInvalidclouddetails = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkInvalidGdriveDetails method");

        return checkInvalidclouddetails;

    }
}
