/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.general.microsite;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.advanceSearch.AdvanceSearchPage;
import com.opentext.pageObjects.assetDetails.components.AssetDetailsMetadatasPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.containerAssets.assetPreview.specificViews.AssetPreviewThumbsViewPage;
import com.opentext.pageObjects.containerAssets.assetPreview.specificViews.overlay.OverlayPage;
import com.opentext.pageObjects.footer.FooterPage;
import com.opentext.pageObjects.search.SearchPage;
import com.opentext.pageObjects.sortBy.SortByPage;
import com.opentext.selenium.drivers.DriverManager;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Mavya Papishetty<mpapishe@opentext.com>
 */
public class MicrositePage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(MicrositePage.class);

    /**
     * Components
     */

    private static AdvanceSearchPage advanceSearch;
    private static SortByPage sortBy;
    private static ContainerAssetsPage containerAssets;
    private static FooterPage footer;
    private static SearchPage search;
    private static OverlayPage overlay;

    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private static final String ADVANCE_SEARCH_SIDEBAR = "advanceSearchSidebar";
    private static final String SEARCH_COUNTER = "searchCounter";
    private static final String SEARCH_BAR = "searchBar";
    private static final String SEARCH_BUTTON = "searchButton";
    private static final String LISTVIEW_BUTTON = "listViewButton";
    private static final String THUMBSVIEW_BUTTON = "listViewButton";
    private static final String LOGO = "logo";
    private static final String INBOX = "inbox";
    private static final String INBOX_COUNTER = "inboxCounter";
    private static final String INBOX_BUTTON = "inboxbutton";
    private static final String LOGOUT_BUTTON = "logoutButton";
    private static final String PROFILE_BUTTON = "profileButton";
    private static final String PROFILE_BUTTON_MOBILE = "profileButtonMobile";
    private static final String USERNAME = "username";
    private static final String WELCOME_MESSAGE = "welcomeMessage";
    private static final String LINK_BUTTON = "linkButton";
    private static final String BANNER = "banner";
    private static final String ACTIVE_BANNER = "activeBanner";
    private static final String ASSET_OVERLAY_KEYWORDS = "assetOverlayKeywords";
    private static final String LIST_VIEW = "listView";
    private static final String LIST_VIEW_ASSET_INFORMATION = "listViewAssetInformation";
    private static final String SEARCH_SORT_OPTIONS_ASCENDING = "searchSortOptionsAscendingOrder";
    private static final String SEARCH_SORT_OPTIONS_DESCENDING = "searchSortDescending";
    private static final String SORT_BY_BUTTON = "soryByButton";
    private static final String SORT_BY_DROPDOWN_BUTTON = "sortByDropdown";
    private static final String FACET_SELCTOR_ADVANCE_SEARCH_OPTIONS = "facetSelector";
    private static final String ASSET_METADATA_BUTTON = "metadataButton";
    private static final String ASSET_INFORMATION_TAB = "assetInformation";
    private static final String ASSET_INFORMATION_ROWS_LIST = "assetInformationRowsList";
    private static final String METADATA_TAB_CLOSE_BUTTON = "metadataTabClosebutton";
    private static final String RETURN_TO_SEARCH = "returnToSearch";
    private static final String MIME_TYPE_FIELD = "mimeTypeLable";
    private static final String MIME_TYPE_FIELD_LIST = "mimeTypeList";

    private static final String LINK_BUTTON_MOBILE = "linkButtonMobile";
    private static final String LINK_LIST_MOBILE = "linksListInMobileView";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @author mpapishe
     */
    public MicrositePage(EmergyaWebDriver driver) {
        super(driver);

        advanceSearch = new AdvanceSearchPage(driver);
        sortBy = new SortByPage(driver);
        // search.rechargeContainerAssets();
        footer = new FooterPage(driver);
        this.isReady();
    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(SEARCH_BAR);
        this.waitForByXPath(SEARCH_COUNTER);
        this.waitForByXPath(SEARCH_BUTTON);
        this.waitForByXPath(THUMBSVIEW_BUTTON);
        this.waitForByXPath(LISTVIEW_BUTTON);
        this.waitForByXPath(LOGO);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");

    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */
    @Override
    public boolean isReady() {
        boolean isReady = false;

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        if (this.isElementVisibleByXPath(SEARCH_BAR) && this.isElementVisibleByXPath(SEARCH_COUNTER)
                && this.isElementVisibleByXPath(SEARCH_BUTTON) && this.isElementVisibleByXPath(THUMBSVIEW_BUTTON)
                && this.isElementVisibleByXPath(LISTVIEW_BUTTON) && this.isElementVisibleByXPath(LOGO)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * Method to get the desktopLogo source location
     * @return src of DestopLogo
     * @author mpapishe
     */
    public String getDesktopLogo() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getDesktopLogo method");

        String src = this.getElementByXPath(LOGO).getAttribute("src").substring(0, 50).trim();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getDesktopLogo method");

        return src;

    }

    /**
     * Method to ocmparate miscrosite source and DesktopLogos
     * @param mssrc
     * @param src
     * @return isEqual boolean value
     * @author mpapishe
     */

    public boolean isCompare(String mssrc, String src) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isCompare method");

        boolean isEqual = false;

        if (mssrc.trim().contains(src.trim())) {
            isEqual = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isCompare method");

        return isEqual;

    }

    /**
     * Method to verify if Private Microsite page is ready
     * @return idReady boolean  value
     * @author mpapishe
     */

    public boolean isPrivateMicrositePageReady() {
        boolean isReady = false;

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isPrivateMicrositePageReady method");

        SearchPage search = new SearchPage(driver, "Microsite");
        ContainerAssetsPage containerAssets = new ContainerAssetsPage(driver, search.isThumbsViewActive(),
                search.getNumberOfAssetsShown());
        if (advanceSearch.isReady() && sortBy.isReady() && containerAssets.isReady() && footer.isReady()
                && this.isElementVisibleByXPath(SEARCH_BAR) && this.isElementVisibleByXPath(SEARCH_COUNTER)
                && this.isElementVisibleByXPath(SEARCH_BUTTON) && this.isElementVisibleByXPath(THUMBSVIEW_BUTTON)
                && this.isElementVisibleByXPath(LISTVIEW_BUTTON) && this.isElementVisibleByXPath(LOGO)
                && this.isElementVisibleByXPath(INBOX) && this.isElementVisibleByXPath(INBOX_COUNTER)
                && this.isElementVisibleByXPath(INBOX_BUTTON) && this.isElementVisibleByXPath(LOGOUT_BUTTON)
                && this.isElementVisibleByXPath(PROFILE_BUTTON)) {
            isReady = true;

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isPrivateMicrositePageReady method");

        return isReady;
    }

    /**
     * Method to verify that testuser  for a microsite
     * @param Testuser
     * @return boolean value is testuser is matched or not 
     * @author mpapishe
     */

    public boolean isTestUser(String Testuser) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isTestUser method");
        this.expandHeaderInMobileView();
        this.getElementByXPath(PROFILE_BUTTON_MOBILE).click();

        boolean isEqual = false;

        String testusername = this.getElementByXPath(USERNAME).getText();
        if (testusername.equalsIgnoreCase(Testuser))
            isEqual = true;

        this.getElementByXPath(LOGO).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isTestUser method");

        return isEqual;

    }

    /**
     * Method to verify if link is presnt or not 
     * @return boolean value of link if it is presnt or not
     * @author mpapishe
     */

    public boolean isLinkshown() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isLinkshown method");

        boolean isShown = false;
        if (this.isElementVisibleByXPath(LINK_BUTTON))
            isShown = true;

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isLinkshown method");

        return isShown;

    }

    /**
     * Method to get Link Name of the microsite
     * @return Linkname
     * @author mpapishe
     */

    public String getLinkName() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getLinkName method");

        this.getElementByXPath(LINK_BUTTON_MOBILE).click();

        String LinkName = this.getElementByXPath(LINK_LIST_MOBILE).getText();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getLinkName method");

        return LinkName;

    }

    /**
     * Method to Access the link from the microsite
     * @return defaultwindow object
     * @author mpapishe
     */

    public String accessingLink(String lINK) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start accessingLink method");

        WebElement link = this.getElementByXPath(LINK_LIST_MOBILE);
        String link1 = this.getElementByXPath(LINK_LIST_MOBILE).getText();

        Actions newwin = new Actions(driver);
        newwin.moveToElement(this.getElementByXPath(LINK_LIST_MOBILE)).contextClick().sendKeys(Keys.DOWN)
                .sendKeys(Keys.DOWN).sendKeys(Keys.ENTER).build().perform();

        this.driver.sleep(2);

        Set<String> win = this.driver.getWindowHandles();
        String defaultWindow = this.driver.getWindowHandle();
        Iterator<String> winIterator = win.iterator();
        while (winIterator.hasNext()) {
            String temp = winIterator.next();

            if (!(temp.equals(defaultWindow)))
                driver.switchTo().window(temp);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End accessingLink  method");

        return defaultWindow;

    }

    /**
     * Method to handle the windows for the microsites
     * @return defaultwindow
     * @author mpapishe
     */

    public String handleWindow() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start handleWindow method");

        Set<String> win = this.driver.getWindowHandles();
        String defaultWindow = this.driver.getWindowHandle();
        Iterator<String> winIterator = win.iterator();
        while (winIterator.hasNext()) {
            String temp = winIterator.next();
            if (!(temp.equals(defaultWindow)))
                driver.switchTo().window(temp);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End handleWindow  method");

        return defaultWindow;

    }

    /**
     * Method to verify if banner is shown 
     * @return isShown 
     * @author mpapishe
     */
    public boolean isBannerShown() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isBannerShown method");

        boolean isShown = false;
        this.waitForByElement(this.getElementByXPath(ACTIVE_BANNER));
        if (this.getElementByXPath(ACTIVE_BANNER).isDisplayed()) {
            isShown = true;
            String expectedBannerValue = "/mbportalclient/microsite/";
            if (this.getElementByXPath(ACTIVE_BANNER).getAttribute("style").contains(expectedBannerValue)) {
                isShown = true;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isBannerShown  method");

        return isShown;
    }

    /**
     * Method to acces the Asset Overlay
     * @return assetOverLayList
     * @author mpapishe
     */
    public List<String> accessAssetOverlay() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start accessAssetOverlay method");

        AssetPreviewThumbsViewPage assetPreview = new AssetPreviewThumbsViewPage(driver, 2);
        if (overlay == null) {
            assetPreview.moveMouseOverAsset(true); // Send "true" to initialize the overlay.
        }
        List<String> assetOverLayList = this.getList(ASSET_OVERLAY_KEYWORDS);
        for (String lis : assetOverLayList) {
            System.out.println(lis);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start accessAssetOverlay method");

        return assetOverLayList;
    }

    /**
     * Method to get Metadata for Assets
     * @return metadateList
     * @author mpapishe
     */
    public List<String> getMetadataForAsset() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getMetadataForAsset method");

        AssetPreviewThumbsViewPage assetPreview = new AssetPreviewThumbsViewPage(driver, 2);
        if (overlay == null) {
            assetPreview.moveMouseOverAsset(true); // Send "true" to initialize the overlay.
        }
        action.moveToElement(assetPreview.getTitle().get(2)).click().perform();
        this.driver.sleep(2);
        this.clickOnAssetActionsDropdownInMobile();
        this.clickonMetadatabutton();
        /*this.waitForByElement(this.getElementByXPath(ASSET_METADATA_BUTTON));
        this.getElementByXPath(ASSET_METADATA_BUTTON).click();*/

        AssetDetailsMetadatasPage metadatapage = new AssetDetailsMetadatasPage(DriverManager.getDriver());
        metadatapage.openGroup();

        this.driver.sleep(2);
        List<String> metadateList = this.getList(ASSET_INFORMATION_ROWS_LIST);
        for (String lis : metadateList) {
            System.out.println(lis);
        }
        this.getElementByXPath(METADATA_TAB_CLOSE_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getMetadataForAsset method");

        return metadateList;

    }

    /**
     * Method to Switch to ListView
     * @return listViewAssetInformation
     * @author mpapishe
     */
    public List<String> switchtoListView() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start switchtoListView method");
        this.expandSortOptionsInSearchPage();
        this.waitForByXPath(LISTVIEW_BUTTON);
        this.getElementByXPath(LISTVIEW_BUTTON).click();
        this.waitForByXPath(LIST_VIEW_ASSET_INFORMATION);
        List<String> listViewAssetInformation = this.getList(LIST_VIEW_ASSET_INFORMATION);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start switchtoListView method");

        return listViewAssetInformation;
    }

    /**
     * Method to get the list of Search of Sort Options
     * @return sortByOptions
     * @author mpapishe
     */
    public List<String> searchSortOptions() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start searchSortOptions method");

        // this.expandSortOptionsInSearchPage();
        this.getElementByXPath(SORT_BY_BUTTON).isDisplayed();
        this.getElementByXPath(SORT_BY_DROPDOWN_BUTTON).click();
        this.waitForByXPath(SEARCH_SORT_OPTIONS_ASCENDING);
        List<String> sortByOptions = this.getList(SEARCH_SORT_OPTIONS_ASCENDING);

        this.getElementByXPath(SORT_BY_DROPDOWN_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start searchSortOptions method");

        return sortByOptions;
    }

    /**
     * Method to List the facetSelectorOptions in Advance Search
     * @return facetSelectors
     * @author mpapishe
     */
    public List<String> facetSelectorOptionsInAdvanceSearch() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start facetSelectorOptionsInAdvanceSearch method");
        AdvanceSearchPage advancesearch = new AdvanceSearchPage(driver);
        advancesearch.open();
        this.getElementByXPath(FACET_SELCTOR_ADVANCE_SEARCH_OPTIONS).isDisplayed();
        List<String> facetSelectors = this.getList(FACET_SELCTOR_ADVANCE_SEARCH_OPTIONS);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End facetSelectorOptionsInAdvanceSearch  method");

        return facetSelectors;

    }

    /**
     * Method to verify if sigle asset type is shown
     * @return isSingleAssettype
     * @author mpapishe
     */
    public boolean isSingleeAssetTypeIsShown() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isSingleeAssetTypeIsShown method");

        AdvanceSearchPage advancesearch = new AdvanceSearchPage(driver);
        boolean isSingleAssettype = false;
        advancesearch.getAssetTypeFilterSize();
        if (advancesearch.getAssetTypeFilterSize() == 1) {
            isSingleAssettype = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isSingleeAssetTypeIsShown  method");
        return isSingleAssettype;

    }

    /**
     * Method to verify if Mime type Filed is Present
     * @return isMimeTypeFieldShown
     * @author mpapishe
     */
    public boolean isMimeTypeFieldPresent() {

        boolean isMimeTypeFieldShown = false;

        if (this.getElementByXPath(MIME_TYPE_FIELD).isDisplayed()) {

            isMimeTypeFieldShown = true;
        }

        return isMimeTypeFieldShown;

    }

    /**
     * Method to get Mime type Values
     * @return mimeTypeValues
     * @author mpapishe
     */
    public List<String> getMimeTypevalues() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getMimeTypevalues method");

        List<String> mimeTypeValues = this.getList(MIME_TYPE_FIELD_LIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getMimeTypevalues  method");

        return mimeTypeValues;
    }
}
