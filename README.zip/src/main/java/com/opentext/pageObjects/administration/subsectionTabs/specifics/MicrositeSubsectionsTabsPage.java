/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.subsectionTabs.specifics;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.SectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.SubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the General subsections tabs.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class MicrositeSubsectionsTabsPage extends SubsectionsTabsPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(MicrositeSubsectionsTabsPage.class);

    /**
     * Components
     */
    // Not necessary.

    /**
     * Items keys selectors.
     */
    private final static String GENERAL = "general";
    private final static String LINKS = "links";
    private final static String BANNERS = "banners";
    private final static String TESTUSERS = "testusers";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of visible {@link SectionPage}.
     */
    public MicrositeSubsectionsTabsPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = true;

        if (this.isKeyShown(GENERAL)) {
            if (!this.isElementVisibleByXPath(GENERAL, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(LINKS)) {
            if (!this.isElementVisibleByXPath(LINKS, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(BANNERS)) {
            if (!this.isElementVisibleByXPath(BANNERS, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(TESTUSERS)) {
            if (!this.isElementVisibleByXPath(TESTUSERS, 1)) {
                isReady = false;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        if (this.isKeyShown(GENERAL)) {
            this.waitForByXPath(GENERAL);
        }
        if (this.isKeyShown(LINKS)) {
            this.waitForByXPath(LINKS);
        }
        if (this.isKeyShown(BANNERS)) {
            this.waitForByXPath(BANNERS);
        }
        if (this.isKeyShown(TESTUSERS)) {
            this.waitForByXPath(TESTUSERS);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

}
