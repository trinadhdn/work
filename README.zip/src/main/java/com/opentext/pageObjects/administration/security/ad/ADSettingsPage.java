/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.security.ad;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.SecuritySubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.ConfigAD;
import com.opentext.utils.ConfigAD.ConfigADDetails;
import com.opentext.utils.ConfigFactory;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ADSettingsPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(ADSettingsPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String SERVER_NAME_INPUT = "serverInput";
    private final static String PORT_NUMBER_INPUT = "portNumberInput";

    private final static String DN_FOR_NON_ANONYMOUS_SEARCH = "dnForNonAnonymousSearch";
    private final static String PASSWORD_DN_FOR_NON_ANONYMOUS_SEARCH = "passwordDNForNonAnonymousSearch";
    private final static String DOMAIN_NAME_ATTRIBUTE = "domainNameAttribute";

    private final static String EMAIL_ATTRIBUTE = "emailAttribute";
    private final static String BASE_DN = "baseDN";

    private final static String ENABLE_TLS = "enableTLS";
    protected final static String SAVE_BUTTON = "saveButton";
    private final static String BACK_BUTTON = "backbutton";
    private final static String CHECK_SERVICE = "checkservice";
    private final static String CHECK_SERVICE_MESSAGE = "checkservicemessage";
    private final static String SUSSESSFULLY_SAVED_MESSAGE = "successfullySavedMessage";

    private final static String SERVERNAME_REQUIRED_FIELD_MESSAGE = "serverNameRequiredFieldMessage";
    private final static String DN_FOR_NON_ANONYMOUS_SEARCH_REQUIRED_FIELD_MESSAGE = "dnForNonAnonymousSearchRequiredFieldMessage";
    private final static String DOMAIN_NAME_ATTRIBUTE_REQUIRED_FIELD_MESSAGE = "domainNameAttributeRequiredFieldMessage";
    private final static String EMAIL_ATTRIBUTE_REQUIRED_FIELD_MESSAGE = "emailAttributeRequiredFieldMessage";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public ADSettingsPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new SecuritySubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(SERVER_NAME_INPUT) && this.isElementVisibleByXPath(PORT_NUMBER_INPUT)
                && this.isElementVisibleByXPath(DN_FOR_NON_ANONYMOUS_SEARCH)
                && this.isElementVisibleByXPath(PASSWORD_DN_FOR_NON_ANONYMOUS_SEARCH)
                && this.isElementVisibleByXPath(DOMAIN_NAME_ATTRIBUTE) && this.isElementVisibleByXPath(EMAIL_ATTRIBUTE)
                && this.isElementVisibleByXPath(BASE_DN) && this.isElementVisibleByXPath(ENABLE_TLS)
                && this.isElementVisibleByXPath(SAVE_BUTTON) && this.isElementVisibleByXPath(CHECK_SERVICE)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(SERVER_NAME_INPUT);
        this.waitForByXPath(PORT_NUMBER_INPUT);

        this.waitForByXPath(DN_FOR_NON_ANONYMOUS_SEARCH);
        this.waitForByXPath(PASSWORD_DN_FOR_NON_ANONYMOUS_SEARCH);
        this.waitForByXPath(DOMAIN_NAME_ATTRIBUTE);
        this.waitForByXPath(EMAIL_ATTRIBUTE);
        this.waitForByXPath(BASE_DN);
        this.waitForByXPath(ENABLE_TLS);

        this.waitForByXPath(SAVE_BUTTON);
        this.waitForByXPath(CHECK_SERVICE);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the MediaBin list page.
     * @return dashboard
     */

    public DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to save the new/edited server.
     * @return {@link ADSettingPage} ready to work with or null if the form wasn't completed.
     */
    public ADSettingsPage clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(SAVE_BUTTON).click();
        this.driver.sleep(1);

        ADSettingsPage adSettings = null;

        if (!this.isElementVisibleByXPath(SERVERNAME_REQUIRED_FIELD_MESSAGE, 1)
                && !this.isElementVisibleByXPath(DN_FOR_NON_ANONYMOUS_SEARCH_REQUIRED_FIELD_MESSAGE, 1)
                && !this.isElementVisibleByXPath(DOMAIN_NAME_ATTRIBUTE_REQUIRED_FIELD_MESSAGE, 1)
                && !this.isElementVisibleByXPath(EMAIL_ATTRIBUTE_REQUIRED_FIELD_MESSAGE, 1)) {
            // If no error is shown:
            this.waitUntilDisappearByXPath(SAVE_BUTTON);
            this.waitUntilDisappearByXPath(SPINNER);
            adSettings = new ADSettingsPage(driver, this.getSectionsVisible());
            adSettings.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

        return adSettings;
    }

    /**
     * @return boolean about if required field message is shown or not
     */
    public boolean isRequiredFieldMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isRequiredFieldMessageShown method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(SERVERNAME_REQUIRED_FIELD_MESSAGE, 1)
                && this.isElementVisibleByXPath(DN_FOR_NON_ANONYMOUS_SEARCH_REQUIRED_FIELD_MESSAGE, 1)
                && this.isElementVisibleByXPath(DOMAIN_NAME_ATTRIBUTE_REQUIRED_FIELD_MESSAGE, 1)
                && this.isElementVisibleByXPath(EMAIL_ATTRIBUTE_REQUIRED_FIELD_MESSAGE, 1)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequiredFieldMessageShown method");

        return isReady;
    }

    /**
     * Method to fill ADSettings 
    */
    public void fillADSettingsDetails(ConfigADDetails ADSERVERNAME, ConfigADDetails ADPORT, ConfigADDetails ADDN,
            ConfigADDetails ADDNPASSWORD, ConfigADDetails ADDOMAIN, ConfigADDetails ADEMAIL, ConfigADDetails ADBASEDN) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillADSettingsDetails method");

        // Clear exsting data
        this.clearDeatils();

        // Fill details
        ConfigAD Config = ConfigFactory
                .getADConfigDetils(ADSERVERNAME, ADPORT, ADDN, ADDNPASSWORD, ADDOMAIN, ADEMAIL, ADBASEDN);

        this.getElementByXPath(SERVER_NAME_INPUT).sendKeys(Config.getADServerName());
        this.getElementByXPath(PORT_NUMBER_INPUT).sendKeys(Config.getADPortNumberInput());
        this.getElementByXPath(DN_FOR_NON_ANONYMOUS_SEARCH).sendKeys(Config.getADdn());
        this.getElementByXPath(PASSWORD_DN_FOR_NON_ANONYMOUS_SEARCH).sendKeys(Config.getADDNPassword());
        this.getElementByXPath(EMAIL_ATTRIBUTE).sendKeys(Config.getADEmail());
        this.getElementByXPath(BASE_DN).sendKeys(Config.getADBaseDN());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillADSettingsDetails method");

    }

    /**
     * Method to clear data .
    */
    public void clearDeatils() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clearDeatils method");

        this.getElementByXPath(SERVER_NAME_INPUT).clear();
        this.getElementByXPath(PORT_NUMBER_INPUT).clear();
        this.getElementByXPath(DN_FOR_NON_ANONYMOUS_SEARCH).clear();
        this.getElementByXPath(PASSWORD_DN_FOR_NON_ANONYMOUS_SEARCH).clear();
        this.getElementByXPath(EMAIL_ATTRIBUTE).clear();
        this.getElementByXPath(BASE_DN).clear();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clearDeatils method");

    }

    /**
     * Method to check Successfully created message.
     * @return boolean about if server created successfully or not.
    */
    public boolean isSuccessfullyCreatedMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isSuccessfullyCreatedMessageShown method");

        boolean isShown = false;
        String message = this.getElementByXPath(SUSSESSFULLY_SAVED_MESSAGE).getText();
        if (message.equalsIgnoreCase("Configuration successfully saved.")) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isSuccessfullyCreatedMessageShown method");

        return isShown;

    }

    /**
     * Method to check the settings.
     * @return boolean about if setting is working fine or not
    */
    public synchronized boolean checkService() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkService method");

        boolean checkservice = false;
        this.getElementByXPath(CHECK_SERVICE).click();
        this.driver.sleep(3);
        if (!(this.getElementByXPath(CHECK_SERVICE_MESSAGE).getAttribute("style").contains("display: block;"))) {
            this.getElementByXPath(CHECK_SERVICE).click();
            this.driver.sleep(4);
        }
        String message = this.getElementByXPath(CHECK_SERVICE_MESSAGE).getText();
        if (message.contains("Active Directory server is working properly.")) {
            checkservice = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkService method");

        return checkservice;

    }

    /**
     * Method to check the Invalid settings
     * @return boolean about if settings is working fine or not
    */
    public boolean checkInvalidService() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkService method");

        boolean checkInvalidservice = false;
        this.getElementByXPath(CHECK_SERVICE).click();
        driver.sleep(3);
        if (!(this.getElementByXPath(CHECK_SERVICE_MESSAGE)).getAttribute("style").contains("display: block;")) {
            this.getElementByXPath(CHECK_SERVICE).click();
            driver.sleep(2);
        }
        String message = this.getElementByXPath(CHECK_SERVICE_MESSAGE).getText();
        System.out.println(message);
        if (message.contains("Active Directory server is not working. Please, review your configuration.")) {
            checkInvalidservice = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkService method");

        return checkInvalidservice;

    }
}
