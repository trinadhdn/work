/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.security.roleConfiguration;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.SecuritySubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class RoleConfiguration extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(RoleConfiguration.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String ROLE_NAMES = "roleNames";
    private final static String PERMISSIONS_NAMES = "permissionsNames";
    private final static String IND_PERMISSIONS_NAMES = "IndivudualPermissionsNames";

    private final static String EDIT_BUTTON = "editButton";
    private final static String SEARCH_INPUT = "shearchBox";
    private final static String SYNC_LDAP_GROUPS = "synchronizeLDAPGroups";
    private final static String BACK_BUTTON = "backbutton";

    private final static String EXPAND_BUTTON = "expandButton";
    private final static String CHECK_ALL_CHECKBOX = "checkAllCheckBox";
    private final static String PERMISSION_NAME = "permission";
    private final static String ROLE_PERMISSIONS = "rolePermissions";
    private final static String ADMIN_PERMISSIONS = "adminPermissions";
    private final static String COLLECTION_PERMISSIONS = "collectionPermissions";
    private final static String CUSTOM_PERMISSIONS = "customPermissions";
    private final static String INBOX_PERMISSIONS = "inboxPermissions";
    private final static String SAVE = "saveButton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public RoleConfiguration(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new SecuritySubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;

        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(ROLE_NAMES) && this.isElementVisibleByXPath(SEARCH_INPUT)
                && this.isElementVisibleByXPath(SEARCH_INPUT) && this.isElementVisibleByXPath(SYNC_LDAP_GROUPS)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * @return boolean about this PO is ready
     */
    public boolean isRoleEditPageReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;

        if (this.isElementVisibleByXPath(EXPAND_BUTTON) && this.isElementVisibleByXPath(ROLE_NAMES)
                && this.isElementVisibleByXPath(CHECK_ALL_CHECKBOX) && this.isElementVisibleByXPath(PERMISSION_NAME)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(ROLE_NAMES);
        this.waitForByXPath(SEARCH_INPUT);

        this.waitForByXPath(SYNC_LDAP_GROUPS);
        this.waitForByXPath(EDIT_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * This method will wait until this Role PO is ready
     */
    public void waitForRoleEditPageReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForRoleEditPageReady method");

        this.waitForByXPath(EXPAND_BUTTON);
        this.waitForByXPath(ROLE_NAMES);
        this.waitForByXPath(CHECK_ALL_CHECKBOX);

        this.waitForByXPath(PERMISSION_NAME);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForRoleEditPageReady method");
    }

    /**
     * Method to navigate back to dashboard
     * @return dashboard
     */

    public DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to check Content permissions matchs to Roles Permissions.
     * @param Name of the condition 
    */
    public boolean isRolePermissionsMatchWithContentPermissions(List<String> permissions, String roleName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteALLConditions method");

        this.getElementByXPath(SEARCH_INPUT).sendKeys(roleName);
        this.driver.sleep(2);
        boolean isShown = false;

        List<String> indivdualPermission = this.getList(IND_PERMISSIONS_NAMES);

        if (this.compareLists(permissions, indivdualPermission)) {

            isShown = true;

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteALLConditionS method");
        return isShown;

    }

    /**
     * Method to edit role.
     * @param Name of the role/group 
    */
    public void editRole(String groupName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start editRole method");

        this.getElementByXPath(SEARCH_INPUT).sendKeys(groupName);
        this.driver.sleep(2);
        this.getElementByXPath(EDIT_BUTTON).click();

        this.waitForRoleEditPageReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End editRole method");

    }

    /**
     * Method to save role.
    */
    public void clickOnsaveRole() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnsaveRole method");

        this.getElementByXPath(SAVE).click();

        this.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnsaveRole method");

    }

    /**
     * Method to uncheck admin Roles Permissions.
    */
    public void uncheckAdminRole() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start uncheckAdminRole method");

        if (this.getElementsByXPath(CHECK_ALL_CHECKBOX).get(0).isSelected()) {

            this.getElementsByXPath(CHECK_ALL_CHECKBOX).get(0).click();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End uncheckAdminRole method");

    }

    /**
     * Method to uncheck Asset Roles Permissions.
    */
    public void uncheckAssetRole() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start uncheckAssetRole method");

        if (this.getElementsByXPath(CHECK_ALL_CHECKBOX).get(1).isSelected()) {

            this.getElementsByXPath(CHECK_ALL_CHECKBOX).get(1).click();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End uncheckAssetRole method");

    }

    /**
     * Method to uncheck Collection Roles Permissions.
    */
    public void uncheckCollectionRole() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start uncheckCollectionRole method");

        if (this.getElementsByXPath(CHECK_ALL_CHECKBOX).get(2).isSelected()) {

            this.getElementsByXPath(CHECK_ALL_CHECKBOX).get(2).click();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End uncheckCollectionRole method");

    }

    /**
     * Method to uncheck Inbox Roles Permissions.
    */
    public void uncheckInboxRole() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start uncheckInboxRole method");

        if (this.getElementsByXPath(CHECK_ALL_CHECKBOX).get(4).isSelected()) {

            this.getElementsByXPath(CHECK_ALL_CHECKBOX).get(4).click();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End uncheckCollectionRole method");

    }

    /**
     * Method to uncheck admin Roles Permissions.
    */
    public void checkAdminRole() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkAdminRole method");

        this.waitForRoleEditPageReady();

        if (!this.getElementsByXPath(CHECK_ALL_CHECKBOX).get(0).isSelected()) {

            this.getElementsByXPath(CHECK_ALL_CHECKBOX).get(0).click();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkAdminRole method");

    }

    /**
     * Method to select All Role 
    */
    public void selectAllRole() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAllRole method");

        this.waitForRoleEditPageReady();

        List<WebElement> roleslist = this.getElementsByXPath(CHECK_ALL_CHECKBOX);

        for (WebElement list : roleslist) {

            if (!list.isSelected()) {
                list.click();
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAllRole method");

    }

    /**
     * Method to uncheck admin Roles Permissions.
    */
    public boolean checkAdminTabInLoginPage() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkAdminRole method");

        boolean isShown = true;

        if (this.getHeader().isAdminButtonShown()) {

            isShown = false;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkAdminRole method");
        return isShown;

    }

    /**
     * Method to Click on Sync Groups
    */
    public void clickOnSyncGroups() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSyncGroups method");

        this.getElementByXPath(SYNC_LDAP_GROUPS).click();
        this.waitForReady();
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSyncGroups method");

    }

    /**
     * Method to Click on Sync Groups
    */
    public boolean isGroupExistInList(String groupName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isGroupExistInList method");

        this.getElementByXPath(SEARCH_INPUT).sendKeys(groupName);
        this.driver.sleep(2);

        boolean isShown = false;

        List<String> list = this.getList(ROLE_NAMES);

        for (String name : list) {

            if (name.contains(groupName)) {

                isShown = true;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isGroupExistInList method");
        return isShown;

    }
}
