/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.security.contentPermissions;

import static org.testng.AssertJUnit.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.SecuritySubsectionsTabsPage;
import com.opentext.pageObjects.advanceSearch.AdvanceSearchPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers
 * subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ContentPermissionsPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(ContentPermissionsPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String CONTENT_PERMISSION_NAMES = "contentPermissionNames";
    private final static String CONTENT_PERMISSION_DESCRIPTIONS = "contentPermissionDescription";
    private final static String TYPE = "typeList";
    private final static String ENABLED = "enabled";
    private final static String EDIT_BUTTON = "editButton";
    private final static String DELETE_BUTTON = "deleteButton";
    private final static String ADD_FILTER_BUTTON = "addFilterButton";
    private final static String BACK_BUTTON = "backbutton";

    private final static String ENABLED_CHECK_BOX = "enabledCheckBox";
    private final static String SCOPE_DROPDOWN = "scopeDropdown";
    private final static String SCOPE_DROPDOWN_OPTIONS = "scopeDropdownOptions";
    private final static String FILTER_NAME = "//div[@id='filtersTable_filter']/label/input";
    private final static String FILTER_NAME_ISREQUIRED_MESSAGE = "filterIsRequiredMessage";
    private final static String FILTER_DESC = "filterDesc";
    private final static String CONDITION_DROPDOWN = "conditionsDropdown";
    private final static String CONDITION_DROPDOWN_OPTIONS = "conditionsDropdownOptions";
    private final static String CONDITION_NOT_OPTION = "conditionNOT";
    private final static String CONDITION_LESSTHAN_OPTION = "conditionLessthan";
    private final static String CONDITION_GREATERTHAN_OPTION = "conditionGreaterthan";
    private final static String CONDITION_EQUAL_OPTION = "conditionEqual";
    private final static String CONDITION_INTERVAL_OPTION = "conditionInterval";
    private final static String CONDITION_WILDCARD_OPTION = "conditionWildcard";
    private final static String CONDITION_TEXT_OPTION = "conditionText";
    private final static String SELECT_TYPE_DROPDOWN = "selectTypeDropdown";
    private final static String SELECT_TYPE_DROPDOWN_OPTIONS = "selectTypeDropdownOptions";
    private final static String ADD_CONDITION_BUTTON = "addConditionButton";
    private final static String PEMISSION_ID_DROPDOWN = "permissionIDDropdown";
    private final static String PEMISSION_ID_DROPDOWN_OPTIONS = "permissionIDDropdownOptions";
    private final static String SAVE_BUTTON = "saveButton";

    private final static String MODAL_OK_BUTTON = "modaldeleteButton";

    /**
     * Constructor method
     * 
     * @param driver
     *            selenium webdriver
     * @param list
     *            of {@link Section} visible.
     */
    public ContentPermissionsPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new SecuritySubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;

        if (this.isElementVisibleByXPath(CONTENT_PERMISSION_NAMES)) {

            if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                    && this.isElementVisibleByXPath(CONTENT_PERMISSION_NAMES)
                    && this.isElementVisibleByXPath(CONTENT_PERMISSION_DESCRIPTIONS)
                    && this.isElementVisibleByXPath(TYPE) && this.isElementVisibleByXPath(ENABLED)
                    && this.isElementVisibleByXPath(DELETE_BUTTON) && this.isElementVisibleByXPath(ADD_FILTER_BUTTON)) {
                isReady = true;
            }
        } else {

            if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)

                    && this.isElementVisibleByXPath(ADD_FILTER_BUTTON)) {
                isReady = true;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * @return boolean about this Add filter PO is ready
     */
    public boolean isAddFilterReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isAddFilterReady method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(ENABLED_CHECK_BOX) && this.isElementVisibleByXPath(SCOPE_DROPDOWN)
                && this.isElementVisibleByXPath(SAVE_BUTTON) && this.isElementVisibleByXPath(FILTER_NAME)
                && this.isElementVisibleByXPath(FILTER_DESC) && this.isElementVisibleByXPath(CONDITION_DROPDOWN)
                && this.isElementVisibleByXPath(PEMISSION_ID_DROPDOWN)
                && this.isElementVisibleByXPath(ADD_CONDITION_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isAddFilterReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(CONTENT_PERMISSION_NAMES);
        this.waitForByXPath(CONTENT_PERMISSION_DESCRIPTIONS);

        this.waitForByXPath(TYPE);
        this.waitForByXPath(EDIT_BUTTON);
        this.waitForByXPath(DELETE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * This method will wait until this Add filter PO is ready
     */
    public void waitForAddFilterReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForAddFilterReady method");

        this.waitForByXPath(ENABLED_CHECK_BOX);
        this.waitForByXPath(SCOPE_DROPDOWN);
        this.waitForByXPath(SAVE_BUTTON);

        this.waitForByXPath(FILTER_NAME);
        this.waitForByXPath(FILTER_DESC);
        this.waitForByXPath(CONDITION_DROPDOWN);
        this.waitForByXPath(PEMISSION_ID_DROPDOWN);
        this.waitForByXPath(ADD_FILTER_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForAddFilterReady method");
    }

    /**
     * Method to navigate back to dashboard
     * 
     * @return dashboard
     */

    public DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to SAVE
     * 
     * @return ContentPermissionsPage
     */

    public ContentPermissionsPage clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        if (this.retryAndGetElementByXPath(SAVE_BUTTON)) {
            this.waitUntilElementClickableByXPath(SAVE_BUTTON);
            this.getElementByXPath(SAVE_BUTTON).click();
        } else {
            assertTrue("Save button is not ready.", false);
        }

        this.driver.sleep(1);

        ContentPermissionsPage ContentPermissionsPage = null;

        if (!this.isElementVisibleByXPath(FILTER_NAME_ISREQUIRED_MESSAGE, 1)) {
            // If no error is shown:
            this.waitUntilDisappearByXPath(SAVE_BUTTON);
            this.waitUntilDisappearByXPath(SPINNER);
            ContentPermissionsPage = new ContentPermissionsPage(driver, this.getSectionsVisible());
            ContentPermissionsPage.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

        return ContentPermissionsPage;
    }

    /**
     * Method to CLick on new
     */
    public void clickOnAddFilterButton() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnAddFilterButton method");

        this.scrollBottom();
        this.getElementByXPath(ADD_FILTER_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnAddFilterButton method");

    }

    /**
     * Method to fill ManagePermissionsDetails
     */
    public void fillFilterDetails(String name, String description, String conditionType, String type,
            String filterType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillFilterDetails method");

        this.scrollBottom();
        // Fill details
        if (!this.getElementByXPath(ENABLED_CHECK_BOX).isSelected()) {
            this.getElementByXPath(ENABLED_CHECK_BOX).click();
        }

        // Selecting FilterType
        List<WebElement> filterScope = this.getElementsByXPath(SCOPE_DROPDOWN_OPTIONS);

        // Loop through the options and click the filtertype
        for (WebElement option : filterScope) {

            if (filterType.equalsIgnoreCase(option.getText().trim())) {
                option.click();
                break;
            }
        }

        this.getElementByXPath(FILTER_NAME).clear();
        this.getElementByXPath(FILENAME_TRJH).clear();

        this.getElementByXPath(FILTER_NAME).sendKeys(name);
        this.driver.sleep(1);
        this.getElementByXPath(FILTER_DESC).clear();
        this.getElementByXPath(FILTER_DESC).sendKeys(description);

        // Select Condition DropDown
        Select dropdown = new Select(this.getElementByXPath(CONDITION_DROPDOWN));
        this.driver.sleep(3);
        dropdown.selectByVisibleText(conditionType);

        this.driver.sleep(3);

        // Select Condition operator
        this.getElementByXPath(CONDITION_EQUAL_OPTION).click();

        this.driver.sleep(2);

        if (conditionType.equalsIgnoreCase("Content Type")) {
            // Select condition type
            Select selectdropdown = new Select(this.getElementByXPath(SELECT_TYPE_DROPDOWN));
            selectdropdown.selectByVisibleText(type);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillFilterDetails method");

    }

    /**
     * Method to Check whether condition is saved or not
     */
    public boolean isConditionExistsInList(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteAllCustomPermission method");

        List<String> condition = this.getList(CONTENT_PERMISSION_NAMES);

        boolean isShown = false;

        for (String cond : condition) {

            if (cond.equalsIgnoreCase(name)) {
                isShown = true;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteAllCustomPermission method");
        return isShown;

    }

    /**
     * Method to delete Condition .
     * 
     * @param Name
     *            of the condition
     */
    public void deleteCondition(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteCondition method");

        List<String> condition = this.getList(CONTENT_PERMISSION_NAMES);

        for (String cond : condition) {

            if (cond.equalsIgnoreCase(name)) {
                this.getElementsByXPath(DELETE_BUTTON).get(condition.indexOf(cond)).click();
                this.driver.sleep(2);
                this.getElementByXPath(MODAL_OK_BUTTON).click();
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteCondition method");

    }

    /**
     * Method to edit Condition .
     * 
     * @param Name
     *            of the condition
     */
    public void editCondition(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteCondition method");

        List<String> condition = this.getList(CONTENT_PERMISSION_NAMES);

        for (String cond : condition) {

            if (cond.equalsIgnoreCase(name)) {
                this.getElementsByXPath(EDIT_BUTTON).get(condition.indexOf(cond)).click();
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteCondition method");

    }

    /**
     * Method to delete Condition .
     * 
     * @param Name
     *            of the condition
     */
    public void deleteALLConditions() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteALLConditions method");

        List<String> condition = this.getList(CONTENT_PERMISSION_NAMES);

        for (String cond : condition) {
            List<String> condition2 = this.getList(CONTENT_PERMISSION_NAMES);
            this.getElementsByXPath(DELETE_BUTTON).get(condition2.lastIndexOf(cond)).click();
            this.driver.sleep(2);
            this.getElementByXPath(MODAL_OK_BUTTON).click();
            this.driver.sleep(2);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteALLConditionS method");

    }

    /**
     * Method to delete Condition .
     * 
     * @param Name
     *            of the condition
     */
    public void checkDataFilterWithUserLogin(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkDataWithFilter method");

        // Open Advanced search
        this.waitUntilDisappearByXPath(SPINNER);

        AdvanceSearchPage advanceSearch = new AdvanceSearchPage(driver);
        advanceSearch.open();
        assertTrue("Shown data is not as per created filter ", advanceSearch
                .isAssetTypeListShowningOnlyFilterData(name));

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkDataWithFilter method");

    }

    /**
     * Method to SignIn.
     * 
     * @param Name
     *            of the condition
     */
    public void clickOnSignIn() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkDataWithFilter method");

        // Open Advanced search
        AdvanceSearchPage advanceSearch = new AdvanceSearchPage(driver);
        advanceSearch.open();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkDataWithFilter method");

    }

    /**
     * Method to get permissions list
     * 
     * @return list of permissions names
     */
    public List<String> getDropdownOptions(String XPATH) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getDropdownOptions method");

        List<WebElement> dropdownList = this.getElementsByXPath(XPATH);
        List<String> list = new ArrayList<>();

        for (WebElement options : dropdownList) {
            list.add(options.getText());
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getDropdownOptions method");
        return list;

    }

    /**
     * @return boolean about if required field message is shown or not
     */
    public boolean isRequiredFieldMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isRequiredFieldMessageShown method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(FILTER_NAME_ISREQUIRED_MESSAGE, 1)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequiredFieldMessageShown method");

        return isReady;
    }

}
