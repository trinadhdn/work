/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.views.landingPage;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.ViewsSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka
 */
public class LandingAndAssetDetailsPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(LandingAndAssetDetailsPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String BACK_BUTTON = "backButton";

    private final static String ITEM_FOR_PAGE_DROPDOWN = "itemForPageDropDown";
    private final static String DEFAULT_VIEW_DROPDOWN = "defaultViewDropDown";

    private final static String SAVE_TO_COLLECTION_LIMIT = "saveToMyCollectionAssetLimit";
    private final static String SAVE_TO_COLLECTION_LIMIT_ISREQUIRED_MESSAGE = "saveToMyCollectionIsRequiredMessage";
    private final static String ENABLE_SEARCH_HISTORY_CHECKBOX = "enableSearchHistoryCheckBox";
    private final static String ENABLE_ADVANCED_SEARCH_BY_DEFAULT_CHECKBOX = "enableAdvancedSearchByDefaultCheckBox";
    private final static String SUGGESTED_SEARCH_TOTAL_ITEMS_INPUT = "suggestedSearchTotalItemsInput";

    private final static String SUGGESTED_SEARCH_TOTAL_ITEMS_INPUT_ISREQUIRED_MESSAGE = "suggestedSearchTotalItemsIsRequiredMessage";
    private final static String SUGGESTED_SEARCH_ITEMS_SHOWN_INPUT = "suggestedSearchItemsShownInput";
    private final static String MAX_TEMPLATES_EXPORT_ASSETS_INPUT = "maxTemplateExportAssetsInput";
    private final static String SORT_BY_AVAILABLE_OPTIONS = "sortByAvailableOptions";
    private final static String SORT_BY_AVAILABLE_OPTIONS_LIST = "sortByAvailableOptionsList";

    private final static String SORT_BY_SELECTED_OPTIONS = "sortBySelectedOptions";
    private final static String SORT_BY_SELECTED_OPTIONS_LIST = "sortBySelectedOptionsList";

    private final static String SELECT_OPTIONS_FOR_SORT_BY = "selectButtonForSortBy";
    private final static String DESELECT_OPTIONS_SORT_BY = "deSelectButtonForassetInformation";

    private final static String SAVE_BUTTON = "saveButton";

    // Asset Detail Tab selectors
    private final static String ASSET_DETAILS_TAB = "assetDetailsTab";
    private final static String ASSET_INFORMATION_ENABLE_SIMULAR_SEARCH_CHECKBOX = "assetDetailsTabEnableSimilarAssets";
    protected final String ASSET_INFORMATION_AVAILABLE_OPTIONS = "assetInformationAvailableOptions";
    private final static String ASSET_INFORMATION_AVAILABLE_OPTIONS_LIST = "assetInformationAvailableOptionsList";
    private final static String ASSET_INFORMATION_SELECTED_OPTIONS = "assetInformationSelectedOptions";
    private final static String ASSET_INFORMATION_SELECTED_OPTIONS_LIST = "assetInformationSelectedOptionsList";

    private final static String SELECT_OPTIONS_FOR_ASSET_INFORMATION = "selectButtonForassetInformation";
    private final static String DESELECT_OPTIONS_ASSET_INFORMATION = "deSelectButtonForassetInformation";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public LandingAndAssetDetailsPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new ViewsSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(ITEM_FOR_PAGE_DROPDOWN)
                && this.isElementVisibleByXPath(DEFAULT_VIEW_DROPDOWN)
                && this.isElementVisibleByXPath(SAVE_TO_COLLECTION_LIMIT)
                && this.isElementVisibleByXPath(ENABLE_SEARCH_HISTORY_CHECKBOX)
                && this.isElementVisibleByXPath(ENABLE_ADVANCED_SEARCH_BY_DEFAULT_CHECKBOX)
                && this.isElementVisibleByXPath(SUGGESTED_SEARCH_TOTAL_ITEMS_INPUT)
                && this.isElementVisibleByXPath(MAX_TEMPLATES_EXPORT_ASSETS_INPUT)
                && this.isElementVisibleByXPath(SORT_BY_AVAILABLE_OPTIONS)
                && this.isElementVisibleByXPath(SORT_BY_SELECTED_OPTIONS)
                && this.isElementVisibleByXPath(SELECT_OPTIONS_FOR_SORT_BY)
                && this.isElementVisibleByXPath(DESELECT_OPTIONS_SORT_BY)
                && this.isElementVisibleByXPath(SAVE_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);
        this.waitForByXPath(ITEM_FOR_PAGE_DROPDOWN);
        this.waitForByXPath(DEFAULT_VIEW_DROPDOWN);
        this.waitForByXPath(SAVE_TO_COLLECTION_LIMIT);
        this.waitForByXPath(ENABLE_SEARCH_HISTORY_CHECKBOX);
        this.waitForByXPath(ENABLE_ADVANCED_SEARCH_BY_DEFAULT_CHECKBOX);
        this.waitForByXPath(SUGGESTED_SEARCH_TOTAL_ITEMS_INPUT);
        this.waitForByXPath(MAX_TEMPLATES_EXPORT_ASSETS_INPUT);
        this.waitForByXPath(SORT_BY_AVAILABLE_OPTIONS);
        this.waitForByXPath(SORT_BY_SELECTED_OPTIONS);
        this.waitForByXPath(SELECT_OPTIONS_FOR_SORT_BY);
        this.waitForByXPath(DESELECT_OPTIONS_SORT_BY);
        this.waitForByXPath(SAVE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return boolean about this PO is ready
     */
    public boolean isAssetDetailsTabReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isAssetDetailsTabReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(ASSET_INFORMATION_AVAILABLE_OPTIONS)
                && this.isElementVisibleByXPath(ASSET_INFORMATION_SELECTED_OPTIONS)
                && this.isElementVisibleByXPath(SELECT_OPTIONS_FOR_ASSET_INFORMATION)
                && this.isElementVisibleByXPath(DESELECT_OPTIONS_ASSET_INFORMATION)

                && this.isElementVisibleByXPath(SAVE_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isAssetDetailsTabReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    public void waitForAssetDetailsTabReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start waitForAssetDetailsTabReady method");

        this.waitForByXPath(BACK_BUTTON);
        this.waitForByXPath(ASSET_INFORMATION_AVAILABLE_OPTIONS);
        this.waitForByXPath(ASSET_INFORMATION_SELECTED_OPTIONS);
        this.waitForByXPath(SELECT_OPTIONS_FOR_ASSET_INFORMATION);
        this.waitForByXPath(DESELECT_OPTIONS_ASSET_INFORMATION);
        this.waitForByXPath(SAVE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForAssetDetailsTabReady method");
    }

    /**
     * Method to navigate back to the View General page.
     * @return {@link ViewGeneralPage} ready to work with.
     */
    @Override
    public  DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new  DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to save the new/edited server.
     */
    public void clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(SAVE_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

    }

    /**
     * Method to Select options for TitleAttributesForDownloads
     */
    public void deselectAllOptions(String slectedOptionsxpath, String deslectButtonXpath) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deselectAllOptions method");

        Select se = new Select(this.getElementByXPath(slectedOptionsxpath));

        if (!(se.getOptions().size() == 0)) {
            for (int i = 0; i < se.getOptions().size(); i++) {

                this.getElementByXPath(slectedOptionsxpath).sendKeys(Keys.CONTROL);

                se.selectByIndex(i);
            }

            this.getElementByXPath(deslectButtonXpath).click();

            this.waitUntilDisappearByXPath(SPINNER);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deselectAllOptions method");

    }

    /**
     * Method to fill the data
     */
    public void fillLandingPageDetails() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillAllDetails method");

        this.selecPickListByVisibleText(ITEM_FOR_PAGE_DROPDOWN, "25");
        this.selecPickListByVisibleText(DEFAULT_VIEW_DROPDOWN, "Thumbnail view");

        this.getElementByXPath(SAVE_TO_COLLECTION_LIMIT).clear();
        this.getElementByXPath(SAVE_TO_COLLECTION_LIMIT).sendKeys("1000");

        if (!(this.getElementByXPath(ENABLE_SEARCH_HISTORY_CHECKBOX).isEnabled())) {
            this.getElementByXPath(ENABLE_SEARCH_HISTORY_CHECKBOX).click();
        }
        if (!(this.getElementByXPath(ENABLE_ADVANCED_SEARCH_BY_DEFAULT_CHECKBOX).isEnabled())) {
            this.getElementByXPath(ENABLE_ADVANCED_SEARCH_BY_DEFAULT_CHECKBOX).click();
        }
        this.getElementByXPath(SUGGESTED_SEARCH_TOTAL_ITEMS_INPUT).clear();
        this.getElementByXPath(SUGGESTED_SEARCH_TOTAL_ITEMS_INPUT).sendKeys("10");

        this.getElementByXPath(SUGGESTED_SEARCH_ITEMS_SHOWN_INPUT).clear();
        this.getElementByXPath(SUGGESTED_SEARCH_ITEMS_SHOWN_INPUT).sendKeys("10");

        this.getElementByXPath(MAX_TEMPLATES_EXPORT_ASSETS_INPUT).clear();
        this.getElementByXPath(MAX_TEMPLATES_EXPORT_ASSETS_INPUT).sendKeys("-1");

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillAllDetails method");

    }

    /**
     * Medtho dto fill the SavetoMyCollectionassetlimit filed
     * @param Limit
     */
    public void fillSavetoMyCollectionassetlimit(String Limit) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start fillSavetoMyCollectionassetlimit method");

        this.getElementByXPath(SAVE_TO_COLLECTION_LIMIT).clear();
        this.getElementByXPath(SAVE_TO_COLLECTION_LIMIT).sendKeys(Limit);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start fillSavetoMyCollectionassetlimit method");
    }

    /**
     * Method to Select options for SortBy .
     */
    public List<String> getListToBeselectedForSortBy() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getListToBeselectedForSortBy method");

        List<String> lists = new ArrayList<>();

        lists.add("Asset Type");
        lists.add("Name");
        lists.add("IDOL Summary");

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getListToBeselectedForSortBy method");
        return lists;

    }

    /**
     * Method to Select options for SortBy .
     */
    public synchronized void selectOptionsForSortByInLandingPage() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectOptionsSortBy method");

        this.deselectAllOptions(SORT_BY_SELECTED_OPTIONS, DESELECT_OPTIONS_SORT_BY);
        Select se = new Select(this.getElementByXPath(SORT_BY_AVAILABLE_OPTIONS));
        se.deselectAll();
        List<String> lists = this.getListToBeselectedForSortBy();

        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, SORT_BY_AVAILABLE_OPTIONS, SORT_BY_AVAILABLE_OPTIONS_LIST, SELECT_OPTIONS_FOR_SORT_BY);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectOptionsSortBy method");

    }

    /**
     * Method to configure AssetDetails Tab
     */
    public synchronized void configureAssetDetailsTab() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start configureAssetDetailsTab method");

        this.getElementByXPath(ASSET_DETAILS_TAB).click();

        this.waitForAssetDetailsTabReady();

        if (!(this.getElementByXPath(ASSET_INFORMATION_ENABLE_SIMULAR_SEARCH_CHECKBOX).isEnabled())) {
            this.getElementByXPath(ASSET_INFORMATION_ENABLE_SIMULAR_SEARCH_CHECKBOX).click();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End configureAssetDetailsTab method");

    }

    /**
     * Method to Select options for AssetInformation( .
     */
    public synchronized void selectOptionsForAssetInformation() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectOptionsForAssetInformation method");

        this.selectAllAvalibleOptionsFromMultiSelectBox(ASSET_INFORMATION_AVAILABLE_OPTIONS, SELECT_OPTIONS_FOR_ASSET_INFORMATION);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectOptionsForAssetInformation method");

    }
}
