/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText Technologies.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.links.microsite;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.MicrositeSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Microsite subsections.
 * 
 * @author MavyaPapishetty <mpapishe@opentext.com>
 */
public class MicrositeLinksPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(MicrositeLinksPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private static final String BACK_BUTTON = "backButton";
    private static final String SEARCH_INPUT = "searchInput";
    private static final String MICROSITE_LINK_TITLE = "micrositeLinkTitle";
    private static final String MICROSITE_LINK_TITLE_LIST = "micrositeLinTitleOptions";
    private static final String LINK_URL = "micrositeLinkURL";
    private static final String LINK_URL_LIST = "micrositeLinkURLoptions";
    private static final String LINK_OPERATIONS = "micrositeLinkOperations";
    private static final String EDIT_OPERATIONS = "micrositeLinkEditOperations";
    private static final String DELETE_OPERATION = "micrositeLinkDeleteOperation";
    private static final String ADD_LINK_BUTTON = "micrositeLinkAddButton";

    private static final String ADD_LINK_TEXTFIELD = "micrositeAddLinkTextField";
    private static final String REQUIRED_FIELD_MESSAGE = "requiredFieldMessage";
    private static final String LINK_URL_TEXTFIELD = "micrositeLinkURLTextfield";
    private static final String SUBMIT_LINK_BUTTON = "submitLinkButton";
    private static final String CANCEL_LINK_BUTTON = "cancelLinkButton";
    private static final String SUBMIT_BUTTON = "submitButton";
    private static final String CANCEL_BUTTON = "cancelButton";

    private static final String DELETE_ALERT_BOX = "deleteLinkAlertBox";
    private static final String ALERT_MESSAGE = "aleartMessage";
    private static final String ALERT_BOX_MODEL_OK = "confirmDeleteLinkButton";
    private static final String ALERT_BOX_CANCEL_BUTTON = "cancelDeleteLinkButton";
    private static final String NO_LINKS = "noLink";

    private static final String LINKS_TAB = "linksTab";
    private static final String SECURITY_TAB = "securityTab";
    private static final String TESTUSERS_TAB = "testUsersTab";
    private static final String GENERAL_TAB = "generalTab";

    private static final String EDIT_LINK_NAME = "linkNameEdit";
    private static final String EDIT_LINK_URL = "linkURLEdit";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     * @author mpapishe
     */
    public MicrositeLinksPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new MicrositeSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */
    @Override
    public boolean isReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;

        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(MICROSITE_LINK_TITLE) && this.isElementVisibleByXPath(SEARCH_INPUT)
                && this.isElementVisibleByXPath(LINK_URL) && this.isElementVisibleByXPath(LINK_OPERATIONS)
                && this.isElementVisibleByXPath(ADD_LINK_BUTTON) && this.isElementVisibleByXPath(LINKS_TAB)
                && this.isElementVisibleByXPath(SECURITY_TAB) && this.isElementVisibleByXPath(TESTUSERS_TAB)
                && this.isElementVisibleByXPath(GENERAL_TAB)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);
        this.waitForByXPath(MICROSITE_LINK_TITLE);
        this.waitForByXPath(SEARCH_INPUT);
        this.waitForByXPath(LINK_URL);
        this.waitForByXPath(LINK_OPERATIONS);
        this.waitForByXPath(ADD_LINK_BUTTON);
        this.waitForByXPath(LINKS_TAB);
        this.waitForByXPath(SECURITY_TAB);
        this.waitForByXPath(TESTUSERS_TAB);
        this.waitForByXPath(GENERAL_TAB);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to Add a newLink
     * @param link
     * @param URL
     * @author mpapishe
     */
    public void addLink(String link, String URL) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addLink method");

        this.getElementByXPath(ADD_LINK_BUTTON).click();
        this.waitForByXPath(ADD_LINK_TEXTFIELD);
        this.waitForByXPath(LINK_URL_TEXTFIELD);
        this.getElementByXPath(ADD_LINK_TEXTFIELD).sendKeys(link);
        this.getElementByXPath(LINK_URL_TEXTFIELD).sendKeys(URL);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End addLink method");

    }

    /**
     * Method to Save a Link
     * @author mpapishe
     */
    public void saveLink() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start saveLink method");

        this.waitForByXPath(SUBMIT_LINK_BUTTON);
        this.driver.sleep(2);
        this.getElementByXPath(SUBMIT_LINK_BUTTON).click();
        this.waitUntilDisappearByXPath(SUBMIT_LINK_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End saveLink method");

    }

    /**
     * Method to Cancel a Link
     * @author mpapishe
     */
    public void cancelLink() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start cancelLink method");

        this.waitForByXPath(CANCEL_LINK_BUTTON);
        this.getElementByXPath(CANCEL_LINK_BUTTON).click();
        this.waitUntilDisappearByXPath(CANCEL_LINK_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End cancelLink method");

    }

    /**
     * Method to check library List has newly created Microsite.
     * @return boolean about if Microsite created successfully or not.
     * @author mpapishe
    */
    public boolean isNewlyCreatedLinkNameShownInList(String link) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isNewlyCreatedLinkNameShownInList method");

        boolean isShown = false;
        this.waitForByXPath(MICROSITE_LINK_TITLE_LIST);
        List<String> linkNameList = this.getList(MICROSITE_LINK_TITLE_LIST);
        for (String linknames : linkNameList) {
            if (linknames.equalsIgnoreCase(link)) {
                isShown = true;
                break;
            }
        }

        this.driver.sleep(2);
        this.waitUntilDisappearByXPath(SPINNER);
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isNewlyCreatedLinkNameShownInList method");

        return isShown;

    }

    /**
     * Method to Check if RequiredMessage shown
     * @return isShown
     * @author mpapishe
     */
    public boolean isRequiredMessageshown() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isRequiredMessageshown method");

        boolean isShown = false;

        this.waitForByXPath(REQUIRED_FIELD_MESSAGE);

        if (this.isElementVisibleByXPath(REQUIRED_FIELD_MESSAGE, 1)) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequiredMessageshown method");

        return isShown;

    }

    /**
     * Method to Edit the Link
     * @return modifiedLinkName
     * @author mpapishe
    */
    public String editLink(String linkName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start delete Microsite method");

        String modifiedLinkName = linkName;
        List<String> linksList = this.getList(MICROSITE_LINK_TITLE_LIST);
        for (String link : linksList) {
            if (link.equalsIgnoreCase(linkName)) {
                this.getElementsByXPath(EDIT_OPERATIONS).get(linksList.indexOf(link)).click();
                this.waitForByXPath(EDIT_LINK_NAME);
                this.driver.sleep(3);
                this.getElementByXPath(EDIT_LINK_NAME).clear();
                modifiedLinkName = "edited" + linkName;
                this.getElementByXPath(EDIT_LINK_NAME).sendKeys(modifiedLinkName);
                this.getElementByXPath(SUBMIT_BUTTON).click();
                this.waitUntilDisappearByXPath(SPINNER);
                this.waitUntilDisappearByXPath(SUBMIT_BUTTON);
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End delete Microsite method");

        return modifiedLinkName;
    }

    /**
     * Method to Search For created Link
     * @param linkName
     * @author mpapishe
     */
    public void searchforLink(String linkName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start searchforLink method");

        this.getElementByXPath(SEARCH_INPUT).sendKeys(linkName);
        if (this.getList(MICROSITE_LINK_TITLE_LIST).size() == 1) {
            List<String> linksList = this.getList(MICROSITE_LINK_TITLE_LIST);
            assertTrue(linksList.toString().contains(linkName), "The Microsite link name is not matching");
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End searchforLink method");
    }

    /**
     * Method to empty the search tab
     * @author mpapishe
     */
    public void emptySearchTab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start emptySearchTab method");

        this.getElementByXPath(SEARCH_INPUT).clear();
        this.getElementByXPath(SEARCH_INPUT).sendKeys(Keys.BACK_SPACE);
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End emptySearchTab method");
    }

    /**
     * Method to Cancel the DeleteLink from the alert tab
     * @param linkName
     * @author mpapishe
    */
    public void cancelDeleteLink(String linkName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start cancelDeleteLink method");

        this.waitForByXPath(MICROSITE_LINK_TITLE_LIST);
        List<String> linksList = this.getList(MICROSITE_LINK_TITLE_LIST);

        for (String link : linksList) {
            if (link.equalsIgnoreCase(linkName)) {
                this.getElementsByXPath(DELETE_OPERATION).get(linksList.indexOf(link)).click();
                this.waitForByXPath(DELETE_ALERT_BOX);
                this.waitForByXPath(ALERT_BOX_CANCEL_BUTTON, 2);
                this.driver.sleep(2);
                this.getElementByXPath(ALERT_BOX_CANCEL_BUTTON).click();
                this.waitUntilDisappearByXPath(SPINNER);
                break;
            }
        }
        this.driver.sleep(2);
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End cancelDeleteLink method");

    }

    /**
     * Method to deleteLink
     * @param  linkName
     * @author mpapishe
    */
    public void deleteLink(String linkName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteLink method");

        List<String> linksList = this.getList(MICROSITE_LINK_TITLE_LIST);
        for (String link : linksList) {
            if (link.equalsIgnoreCase(linkName)) {
                this.getElementsByXPath(DELETE_OPERATION).get(linksList.indexOf(link)).click();
                this.waitForByXPath(DELETE_ALERT_BOX);
                this.waitForByXPath(ALERT_BOX_MODEL_OK, 2);
                this.driver.sleep(2);
                this.getElementByXPath(ALERT_BOX_MODEL_OK).click();
                this.waitUntilDisappearByXPath(DELETE_ALERT_BOX);
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteLink method");
    }

    /**
     * Method to navigate back to the Dashboard
     * @return {@link DashboardPage} ready to work with.
     */
    @Override
    public DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.waitForByElement(this.getElementByXPath(BACK_BUTTON));
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(BACK_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");

        return dashboard;
    }
}
