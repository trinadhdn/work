/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.general.microsite;

import static org.testng.AssertJUnit.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.banners.microsite.MicrositeBannersFromCollections;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.MicrositeSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Mavya Papishetty<mpapishe@opentext.com>
 */
public class CreateAndEditMicrositeGeneralPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(CreateAndEditMicrositeGeneralPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private static final String BACK_BUTTON = "backButton";

    private static final String GENERAL_TAB = "generalTab";
    private static final String ENABLE_MICROSITE_CHECKBOX = "enablemicrositeCheckbox";
    private static final String MICROSITE_NAME = "micrositeName";
    private static final String FRIENDLY_URL = "friendlyURL";
    private static final String MICROSITE_URL = "micrositeURL";
    private static final String SEO_METADATA = "seoMetadata";
    private static final String DESKTOP_LOGO = "desktopLogo";
    private static final String TABLET_LOGO = "tabletLogo";
    private static final String MOBILE_LOGO = "mobileLogo";
    private static final String DESKTOP_PREVIEW = "desktopPreview";
    private static final String TABLET_PREVIEW = "tabletPreview";
    private static final String MOBILE_PREVIEW = "mobilePreview";
    private static final String DESKTOP_CHANGE_IMAGE = "desktopChangeImage";
    private static final String TABLET_CHANGE_IMAGE = "tabletChangeImage";
    private static final String MOBILE_CHANGE_IMAGE = "mobileChangeImage";
    private static final String DESKTOP_SELECT_IMAGE = "desktopSelectImage";
    private static final String TABLET_SELECT_IMAGE = "tabletSelectImage";
    private static final String MOBILE_SELECT_IMAGE = "mobileSelectImage";
    private static final String FROMDATE_DATE_PICKER = "fromDateDatePicker";
    private static final String TODATE_DATE_PICKER = "toDateDatePicker";
    private static final String EXPIRYDATE_VALIDATION = "expiryDateValidation";

    private static final String SELECT_COLLECTION_CONTENT = "selectFromCollectionContent";
    private static final String SELECT_IMAGE_FROM_COLLECTION_TEXT = "selectImageFromCollectionText";
    private static final String CLOSE_BUTTON_SELECT_COLLECTION = "closeButtonSelectCollection";
    private static final String COLLECTION_SELECTOR_LABEL = "collectionSelectorLabel";
    private static final String COLLECTION_SELECT_DROPDOWN = "collectionSelectDropdown";
    private static final String COLLECTION_WRAPPER_AREA = "collectionWrapperArea";
    private static final String CANCEL_BUTTON_COLLECTION_SELECTOR = "cancelButtonCollectionSelector";
    private static final String SELECT_BUTTON_COLLECTION_SELECTOR = "selectButtonCollectionSelector";
    private static final String ASSETLIST_COLLECTION_WRAPPER = "assetsInCollectionWrapper";
    private static final String REMOVE_DESKTOP_lOGO_BUTTON = "removeDesktopLogoButton";
    private static final String REMOVE_TABLET_LOGO_BUTTON = "removeTabletLogoButton";
    private static final String REMOVE_MOBILE_LOGO_BUTTON = "removeMobileLogoButton";

    private static final String BROWSE_BUTTON_UPLOAD_WINDOW = "browseButton";
    private static final String ACCEPT_BUTTON_UPLOAD_WINDOW = "acceptButton";
    private static final String CANCEL_BUTTON_UPLOAD_WINDOW = "cancelButton";
    private static final String UPLOAD_PANEL = "uploadPanel";
    private static final String UPLOAD_TEXT = "uploadText";
    private static final String BROWSE_INPUT = "browseInput";

    private static final String SAVE_BUTTON = "saveButton";

    private static final String SECURITY_TAB = "securityTab";
    private static final String AUTHENTICATION_TYPE = "authenticationType";
    private static final String AUTHENTICATIONTYPE_DROPDOWN = "authenticationdropdown";
    private static final String AUTHENTICATIONTYPE_SELECTED = "authenticationTypeSelected";
    private static final String ROLE = "role";
    private static final String ROLES_DROPDOWN = "rolesDropdown";
    private static final String SELECTED_ROLE = "selectedRole";
    private static final String USER_ACCESS = "useraccess";
    private static final String AUTHORIZED_GROUP_AVAILABLE = "authorizedGrpAvailable";
    private static final String AUTHORIZED_GROUP_AVAILABLE_OPTIONS = "authorizedGrpAvailableOptions";

    private static final String AUTHORIZED_GROUP_SELECTED = "authorizedGrpSelected";
    private static final String AUTHORIZED_GROUP_ADD = "authorizedGrpAdd";
    private static final String AUTHORIZED_GROUP_REMOVE = "authorizedGrpRemove";
    private static final String AVAILABLE_TESTUSERS = "availableTestUsers";
    private static final String AVAILABLE_TESTUSERS_OPTIONS = "availableTestUsersOptions";
    private static final String SELECTED_TESTUSERS = "selectedTestUsers";
    private static final String ADD_TESTUSERS = "addTestUsers";
    private static final String REMOVE_TESTUSERS = "removeTestusers";

    private static final String ADD_USERS_BUTTON = "addusersButton";
    private static final String USERNAME_TEXTRBOX = "usernameTextbox";
    private static final String PASSWORD_TEXTBOX = "passwordTextbox";
    private static final String CONFIRM_PASSWORD_TEXTBOX = "confirmpasswordTextbox";
    private static final String ROLES_SECTION = "rolesSection";
    private static final String ROLES_AVAILABLE = "rolesAvailable";
    private static final String ROLES_AVAILABLE_OPTIONS = "rolesAvailableOptions";
    private static final String ADD_ROLES = "addRoles";
    private static final String REMOVE_ROLES = "removeRoles";
    private static final String ROLES_SELECTED = "rolesSelected";
    private static final String SUBMIT_USER = "submitUser";
    private static final String CLOSE_ADDUSER_WINDOW = "closeAdduserWindow";

    private static final String METADATA_TAB = "metadataTab";
    private static final String FACETS_SECTION = "facets";
    private static final String PARAMETRIC_FILTERS_AVAILABLE = "parametricFilterAvailable";
    private static final String PARAMETRIC_FILTERS_AVAILABLE_LIST = "parametricFilterAvailableList";
    private static final String PARAMETRIC_FILTERS_SELECTED = "parametricFiltersSelected";
    private static final String PARAMETRIC_FILTERS_SELECTED_LIST = "parametricFiltersSelectedList";
    private static final String ADD_PARAMETRIC_FILTERS = "addParametricFilters";
    private static final String REMOVE_PARAMETRIC_FILTERS = "removeParametricFilters";
    private static final String INFORMATION_SECTION = "information";
    private static final String THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE = "thumbnailsInformationdisplayOnHoverAvailable";
    private static final String THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_SELECTED = "thumbnailsInformationdisplayOnHoverSelected";
    private static final String THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE_LIST = "thumbnailsInformationdisplayOnHoverAvailableList";
    private static final String THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_SELECTED_LIST = "thumbnailsInformationdisplayOnHoverSelectedList";
    private static final String ADD_ASSET_THUMBNAILS_INFORMATION_ON_HOVER = "addAssetThumbnailsInformationOnHover";
    private static final String REMOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER = "removeAssetThumbnailInformationOnHover";
    private static final String MOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER_UP = "moveThumbnailInformationDisplayedOnHoverUp";
    private static final String MOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER_DOWN = "moveThumbnailInformationDisplayedOnHoverdown";
    private static final String LIST_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE = "listInformationdisplayOnHoverAvailable";
    private static final String LIST_INFORMATION_DISPLAY_ON_HOVER_SELECTED = "listInformationdisplayOnHoverSelected";
    private static final String LIST_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE_OPTIONS = "listInformationdisplayOnHoverAvailableOptions";
    private static final String LIST_INFORMATION_DISPLAY_ON_HOVER_SELECTED_OPTIONS = "listInformationdisplayOnHoverSelectedOptions";
    private static final String ADD_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER = "addAssetListInformationDisplayedOnHover";
    private static final String REMOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER = "removeAssetListInformationDisplayedOnHover";
    private static final String MOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER_UP = "moveListInformationDisplayedOnHoverUp";
    private static final String MOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER_DOWN = "moveListInformationDisplayedOnHoverdown";
    private static final String ASSET_INFORMATION_SECTION = "assettInformation";
    private static final String ASSET_INFORMATION_AVAILABLE = "assetInformationAvailable";
    private static final String ASSET_INFORMATION_SELECTED = "assetInformationSelected";
    private static final String ASSET_INFORMATION_AVAILABLE_LIST = "assetInformationAvailableList";
    private static final String ASSET_INFORMATION_SELECTED_LIST = "assetInformationSelectedList";
    private static final String ADD_ASSET_INFORMATION = "addAssetInformation";
    private static final String REMOVE_ASSET_INFORMATION = "removeAssetInformation";
    private static final String MOVE_ASSET_INFORMATION_SELECTION_UP = "moveAssetInformationSelectionUp";
    private static final String MOVE_ASSET_INFORMATION_SELECTION_DOWN = "moveAssetInformationSelectionDown";
    private static final String SORTBY_SECTION = "sortby";
    private static final String SORTBY_AVAILABLE = "sortbyAvailable";
    private static final String SORTBY_SELECTED = "sortbySelected";
    private static final String SORTBY_AVAILABLE_LIST = "sortbyAvailableList";
    private static final String SORTBY_SELECTED_LIST = "sortbySelectedList";
    private static final String ADD_SORTBY = "addSortBy";
    private static final String REMOVE_SORTBY = "removeSortby";
    private static final String MOVE_SORT_BY_SELECTION_UP = "moveSortbySelectionUp";
    private static final String MOVE_SORT_BY_SELECTION_DOWN = "moveSortbySelectionDown";

    private static final String LINKS_BANNER_TAB = "linksBannerTab";
    private static final String LINKS_SECTION = "linkssection";
    private static final String AVAILABLE_LINKS = "linksAvailable";
    private static final String AVAILABLE_LINK_OPTIONS = "availableLinkOptions";
    private static final String SELECTED_LINKS = "linksSelected";
    private static final String ADD_LINKS = "addLinks";
    private static final String REMOVE_LINKS = "removeLinks";
    private static final String MOVE_LINKS_UP = "moveLinksUp";
    private static final String MOVE_LINKS_DOWN = "moveLinksDown";
    private static final String ADD_LINK_BUTTON = "addLinksButton";
    private static final String ADD_NEWLINK_WINDOW = "addNewLinkwindow";
    private static final String ADD_LINK_TITLE = "addLinkTitle";
    private static final String ADD_LINK_URL = "addLinkURL";
    private static final String SUBMIT_BUTTON_FOR_ADD_LINK = "submitButtonforAddLink";
    private static final String CLOSE_BUTTON_ADD_LINK = "closebuttonAddLink";
    private static final String BANNER_SECTION = "bannerSection";
    private static final String AVAILABLE_BANNER = "availableBanner";
    private static final String AVAILABLE_BANNER_OPTIONS = "availableBannerOptions";
    private static final String CHANGE_IMAGE_BUTTON = "changeImageButton";
    private static final String SELECTED_BANNERS = "selctedBanners";
    private static final String ADD_BANNERS = "addBanner";
    private static final String REMOVE_BANNERS = "removeBanners";
    private static final String MOVE_BANNERS_UP = "moveBannersUp";
    private static final String MOVE_BANNERS_DOWN = "moveBannersDown";
    private static final String ADD_BANNER_BUTTON = "addBannerButton";
    private static final String ADD_NEW_BANNER_WINDOW = "addNewBannerWindow";
    private static final String BANNER_TITLE = "bannerTitle";
    private static final String BANNER_TYPE = "bannertype";
    private static final String BANNER_TYPE_OPTIONS = "bannertypeOptions";
    private static final String VALIDATE_ASPECT_RATIO = "validateAspectratio";
    private static final String BANNER_PREVIEW = "bannerPreview";
    private static final String SUBMIT_BANNER_BUTTON = "submitBannerButton";
    private static final String CLOSE_BANNER_WINDOW = "closeBannerwindow";
    private static final String EXTERNAL_IMAGE_URL = "externalImageURLField";
    private static final String IMAGE_PREVIEW_WRAPPER = "imagePreviewWrapper";
    private static final String BROWSE_BUTTON = "browseButtonBanner";
    private static final String UPLOAD_BANNER = "uploadBannerInputField";

    private static final String FOLDERS_FILTERS_TAB = "foldersFiltersTab";
    private static final String ROOT_FOLDER_SECTION = "rootfoldersection";
    private static final String PARENT_ELEMENT_SECTION = "parentElement";
    private static final String CHILD_FOLDER_SECTION = "childFolders";
    private static final String FILTERS_SECTION = "filtersSection";
    private static final String PORTAL_CLIENT_FILTERS = "portalclientFilters";
    private static final String AVAILABLE_FILTERS = "availableFilters";
    private static final String SELECTED_FILTERS = "selectedFilters";
    private static final String AVAILABLE_FILTERS_LIST = "availablefilterList";
    private static final String ADD_FILTERS = "addFilters";
    private static final String SELECTED_FILTERS_LIST = "selectedFilterList";
    private static final String REMOVE_FILTERS = "removefilters";

    private static final String CUSTOMIZATION_TAB = "customizationTab";
    private static final String ENABLE_ADVANCE_SEARCH_AREA = "enableAdvanceSearchArea";
    private static final String ENABLE_ADAVANCE_SEARCH_CHECKBOX = "enableAdvanceSearchCheckbox";
    private static final String HEADER_GRADIENT = "headerGradient";
    private static final String HEADER_GRADIENT_DROPDOWN = "headerGradientDropdown";
    private static final String HEADER_GRADIENT_BASIC_COLOR = "headerGradientBasiccolor";
    private static final String HEADER_GRADIENT_SAVED_COLOR = "headergradientSavedColors";
    private static final String HEADER_GRADIENT_ADVANCED_COLOR = "headerGradientAdvancedColor";
    private static final String HEADER_GRADIENT_BASIC_COLORS_LIST = "headerGradientBasicColorList";

    private static final String LINK_COLOR = "linkcloclor";
    private static final String LINK_COLOR_DROPDOWN = "linkcolorDropdown";
    private static final String LINK_COLOR_BASIC_COLOR = "linkBasicColor";
    private static final String LINK_COLOR_SAVED_COLOR = "linkSavedColor";
    private static final String LINK_COLOR_ADVANCED_COLOR = "linkAdvancecolor";
    private static final String LINK_COLOR_BASIC_COLORS_LIST = "linkBasiccolorsList";
    private static final String SEARCH_GRADIENT = "searchGradient";
    private static final String SEARCH_GRADIENT_DROPDOWN = "searchgradientDropdown";
    private static final String SEARCH_GRADIENT_BASIC_COLOR = "searchGradientBasicColor";
    private static final String SEARCH_GRADIENT_SAVED_COLOR = "searchGradientSavedColors";
    private static final String SEARCH_GRADIENT_ADVANCED_COLOR = "searchGradientAdvanceColor";
    private static final String SEARCH_GRADIENT_BASIC_COLORS_LIST = "searchGradientBasicColorsList";
    private static final String TEXT_SEARCH = "textsearch";
    private static final String TEXT_SEARCH_DROPDOWN = "textsearchdropdown";
    private static final String TEXT_SEARCH_BASIC_COLOR = "textSearchBasicColor";
    private static final String TEXT_SEARCH_SAVED_COLOR = "textSearchSavedColors";
    private static final String TEXT_SEARCH_ADVANCED_COLOR = "textSearchAdvancedColors";
    private static final String TEXT_SEARCH_BASIC_COLORS_LIST = "textSearchBasicColorsList";

    private static final String REQUIRED_FIELD_MESSAGE = "requiredFieldMessage";
    private static final String ERROR_MESSAGE_FOR_REQUIRED_PAGE = "errorMessageForRequiredPage";
    // private static final String SAVE_BUTTON = "saveButton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     * @author mpapishe
     */
    public CreateAndEditMicrositeGeneralPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new MicrositeSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(GENERAL_TAB) && this.isElementVisibleByXPath(SECURITY_TAB)
                && this.isElementVisibleByXPath(METADATA_TAB) && this.isElementVisibleByXPath(LINKS_BANNER_TAB)
                && this.isElementVisibleByXPath(FOLDERS_FILTERS_TAB) && this.isElementVisibleByXPath(CUSTOMIZATION_TAB)
                && this.isElementVisibleByXPath(ENABLE_MICROSITE_CHECKBOX)
                && this.isElementVisibleByXPath(MICROSITE_NAME) && this.isElementVisibleByXPath(FRIENDLY_URL)
                && this.isElementVisibleByXPath(MICROSITE_URL) && this.isElementVisibleByXPath(SEO_METADATA)
                && this.isElementVisibleByXPath(DESKTOP_LOGO) && this.isElementVisibleByXPath(TABLET_LOGO)
                && this.isElementVisibleByXPath(MOBILE_LOGO) && this.isElementVisibleByXPath(DESKTOP_PREVIEW)
                && this.isElementVisibleByXPath(TABLET_PREVIEW) && this.isElementVisibleByXPath(MOBILE_PREVIEW)
                && this.isElementVisibleByXPath(DESKTOP_CHANGE_IMAGE)
                && this.isElementVisibleByXPath(TABLET_CHANGE_IMAGE)
                && this.isElementVisibleByXPath(MOBILE_CHANGE_IMAGE)
                && this.isElementVisibleByXPath(DESKTOP_SELECT_IMAGE)
                && this.isElementVisibleByXPath(TABLET_SELECT_IMAGE)
                && this.isElementVisibleByXPath(MOBILE_SELECT_IMAGE) && this.isElementVisibleByXPath(SAVE_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(GENERAL_TAB);
        this.waitForByXPath(ENABLE_MICROSITE_CHECKBOX);

        this.waitForByXPath(MICROSITE_NAME);
        this.waitForByXPath(FRIENDLY_URL);
        this.waitForByXPath(MICROSITE_URL);
        this.waitForByXPath(SEO_METADATA);
        this.waitForByXPath(DESKTOP_LOGO);

        this.waitForByXPath(TABLET_LOGO);
        this.waitForByXPath(MOBILE_LOGO);
        this.waitForByXPath(DESKTOP_PREVIEW);
        this.waitForByXPath(TABLET_PREVIEW);
        this.waitForByXPath(MOBILE_PREVIEW);
        this.waitForByXPath(DESKTOP_CHANGE_IMAGE);
        this.waitForByXPath(TABLET_CHANGE_IMAGE);
        this.waitForByXPath(MOBILE_CHANGE_IMAGE);
        this.waitForByXPath(DESKTOP_SELECT_IMAGE);
        this.waitForByXPath(TABLET_SELECT_IMAGE);
        this.waitForByXPath(MOBILE_SELECT_IMAGE);
        this.waitForByXPath(SAVE_BUTTON);
        this.waitForByXPath(SECURITY_TAB);
        this.waitForByXPath(METADATA_TAB);
        this.waitForByXPath(LINKS_BANNER_TAB);
        this.waitForByXPath(FOLDERS_FILTERS_TAB);
        this.waitForByXPath(CUSTOMIZATION_TAB);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */
    public boolean isSecurityTabReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isSecurityTabReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(GENERAL_TAB) && this.isElementVisibleByXPath(SECURITY_TAB)
                && this.isElementVisibleByXPath(SECURITY_TAB) && this.isElementVisibleByXPath(LINKS_BANNER_TAB)
                && this.isElementVisibleByXPath(FOLDERS_FILTERS_TAB) && this.isElementVisibleByXPath(CUSTOMIZATION_TAB)
                && this.isElementVisibleByXPath(AUTHENTICATION_TYPE) && this.isElementVisibleByXPath(ROLE)
                && this.isElementVisibleByXPath(SAVE_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isSecurityTabReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */
    public void waitForSecurityTabReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForSecurityTabReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(GENERAL_TAB);
        this.waitForByXPath(SECURITY_TAB);

        this.waitForByXPath(LINKS_BANNER_TAB);
        this.waitForByXPath(FOLDERS_FILTERS_TAB);
        this.waitForByXPath(CUSTOMIZATION_TAB);
        this.waitForByXPath(AUTHENTICATION_TYPE);
        this.waitForByXPath(ROLE);

        this.waitForByXPath(SAVE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForSecurityTabReady method");
    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */
    public boolean isMetadataTabReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isMetadataTabReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(METADATA_TAB) && this.isElementVisibleByXPath(FACETS_SECTION)
                && this.isElementVisibleByXPath(PARAMETRIC_FILTERS_AVAILABLE)
                && this.isElementVisibleByXPath(PARAMETRIC_FILTERS_SELECTED)
                && this.isElementVisibleByXPath(ADD_PARAMETRIC_FILTERS)
                && this.isElementVisibleByXPath(REMOVE_PARAMETRIC_FILTERS)
                && this.isElementVisibleByXPath(INFORMATION_SECTION)
                && this.isElementVisibleByXPath(THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE)
                && this.isElementVisibleByXPath(THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_SELECTED)
                && this.isElementVisibleByXPath(ADD_ASSET_THUMBNAILS_INFORMATION_ON_HOVER)
                && this.isElementVisibleByXPath(REMOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER)
                && this.isElementVisibleByXPath(MOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER_UP)
                && this.isElementVisibleByXPath(MOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER_DOWN)
                && this.isElementVisibleByXPath(LIST_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE)
                && this.isElementVisibleByXPath(LIST_INFORMATION_DISPLAY_ON_HOVER_SELECTED)
                && this.isElementVisibleByXPath(ADD_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER)
                && this.isElementVisibleByXPath(REMOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER)
                && this.isElementVisibleByXPath(MOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER_UP)
                && this.isElementVisibleByXPath(MOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER_DOWN)
                && this.isElementVisibleByXPath(ASSET_INFORMATION_SECTION)
                && this.isElementVisibleByXPath(ASSET_INFORMATION_AVAILABLE)
                && this.isElementVisibleByXPath(ASSET_INFORMATION_SELECTED)
                && this.isElementVisibleByXPath(ADD_ASSET_INFORMATION)
                && this.isElementVisibleByXPath(REMOVE_ASSET_INFORMATION)
                && this.isElementVisibleByXPath(MOVE_ASSET_INFORMATION_SELECTION_UP)
                && this.isElementVisibleByXPath(MOVE_ASSET_INFORMATION_SELECTION_DOWN)
                && this.isElementVisibleByXPath(SORTBY_SECTION) && this.isElementVisibleByXPath(SORTBY_AVAILABLE)
                && this.isElementVisibleByXPath(SORTBY_SELECTED) && this.isElementVisibleByXPath(ADD_SORTBY)
                && this.isElementVisibleByXPath(REMOVE_SORTBY)
                && this.isElementVisibleByXPath(MOVE_SORT_BY_SELECTION_UP)
                && this.isElementVisibleByXPath(MOVE_SORT_BY_SELECTION_DOWN)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isMetadataTabReady method");
        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */
    public void waitForMetadataTabReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForMetadataTabReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(GENERAL_TAB);
        this.waitForByXPath(SECURITY_TAB);

        this.waitForByXPath(LINKS_BANNER_TAB);
        this.waitForByXPath(FOLDERS_FILTERS_TAB);
        this.waitForByXPath(CUSTOMIZATION_TAB);
        this.waitForByXPath(METADATA_TAB);
        this.waitForByXPath(FACETS_SECTION);
        this.waitForByXPath(PARAMETRIC_FILTERS_AVAILABLE);
        this.waitForByXPath(PARAMETRIC_FILTERS_SELECTED);
        this.waitForByXPath(ADD_PARAMETRIC_FILTERS);
        this.waitForByXPath(REMOVE_PARAMETRIC_FILTERS);
        this.waitForByXPath(INFORMATION_SECTION);
        this.waitForByXPath(THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE);
        this.waitForByXPath(THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_SELECTED);
        this.waitForByXPath(ADD_ASSET_THUMBNAILS_INFORMATION_ON_HOVER);
        this.waitForByXPath(REMOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER);
        this.waitForByXPath(MOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER_UP);
        this.waitForByXPath(MOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER_DOWN);
        this.waitForByXPath(LIST_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE);
        this.waitForByXPath(LIST_INFORMATION_DISPLAY_ON_HOVER_SELECTED);
        this.waitForByXPath(ADD_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER);
        this.waitForByXPath(REMOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER);
        this.waitForByXPath(MOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER_UP);
        this.waitForByXPath(MOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER_DOWN);
        this.waitForByXPath(ASSET_INFORMATION_SECTION);
        this.waitForByXPath(ASSET_INFORMATION_AVAILABLE);
        this.waitForByXPath(ASSET_INFORMATION_SELECTED);
        this.waitForByXPath(ADD_ASSET_INFORMATION);
        this.waitForByXPath(REMOVE_ASSET_INFORMATION);
        this.waitForByXPath(MOVE_ASSET_INFORMATION_SELECTION_UP);
        this.waitForByXPath(MOVE_ASSET_INFORMATION_SELECTION_DOWN);
        this.waitForByXPath(SORTBY_SECTION);
        this.waitForByXPath(SORTBY_AVAILABLE);
        this.waitForByXPath(SORTBY_SELECTED);
        this.waitForByXPath(ADD_SORTBY);
        this.waitForByXPath(REMOVE_SORTBY);
        this.waitForByXPath(MOVE_SORT_BY_SELECTION_UP);
        this.waitForByXPath(MOVE_SORT_BY_SELECTION_DOWN);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForMetadataTabReady method");

    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */
    public boolean isLinksAndBannersTabReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isLinksAndBannersTabReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(GENERAL_TAB) && this.isElementVisibleByXPath(SECURITY_TAB)
                && this.isElementVisibleByXPath(SECURITY_TAB) && this.isElementVisibleByXPath(LINKS_BANNER_TAB)
                && this.isElementVisibleByXPath(FOLDERS_FILTERS_TAB) && this.isElementVisibleByXPath(CUSTOMIZATION_TAB)
                && this.isElementVisibleByXPath(METADATA_TAB) && this.isElementVisibleByXPath(LINKS_SECTION)
                && this.isElementVisibleByXPath(AVAILABLE_LINKS) && this.isElementVisibleByXPath(SELECTED_LINKS)
                && this.isElementVisibleByXPath(ADD_LINKS) && this.isElementVisibleByXPath(REMOVE_LINKS)
                && this.isElementVisibleByXPath(MOVE_LINKS_UP) && this.isElementVisibleByXPath(MOVE_LINKS_DOWN)
                && this.isElementVisibleByXPath(ADD_LINK_BUTTON) && this.isElementVisibleByXPath(BANNER_SECTION)
                && this.isElementVisibleByXPath(AVAILABLE_BANNER) && this.isElementVisibleByXPath(SELECTED_BANNERS)
                && this.isElementVisibleByXPath(ADD_BANNERS) && this.isElementVisibleByXPath(REMOVE_BANNERS)
                && this.isElementVisibleByXPath(MOVE_BANNERS_UP) && this.isElementVisibleByXPath(MOVE_BANNERS_DOWN)
                && this.isElementVisibleByXPath(ADD_BANNER_BUTTON) && this.isElementVisibleByXPath(SAVE_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isLinksAndBannersTabReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */
    public void waitForLinksAndBannersTabReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start waitForLinksAndBannersTabReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);
        this.waitForByXPath(GENERAL_TAB);
        this.waitForByXPath(SECURITY_TAB);
        this.waitForByXPath(LINKS_BANNER_TAB);
        this.waitForByXPath(FOLDERS_FILTERS_TAB);
        this.waitForByXPath(CUSTOMIZATION_TAB);
        this.waitForByXPath(METADATA_TAB);
        this.waitForByXPath(LINKS_SECTION);
        this.waitForByXPath(AVAILABLE_LINKS);
        this.waitForByXPath(SELECTED_LINKS);
        this.waitForByXPath(ADD_LINKS);
        this.waitForByXPath(REMOVE_LINKS);
        this.waitForByXPath(MOVE_LINKS_UP);
        this.waitForByXPath(MOVE_LINKS_DOWN);
        this.waitForByXPath(ADD_LINK_BUTTON);
        this.waitForByXPath(BANNER_SECTION);
        this.waitForByXPath(AVAILABLE_BANNER);
        this.waitForByXPath(SELECTED_BANNERS);
        this.waitForByXPath(ADD_BANNERS);
        this.waitForByXPath(REMOVE_BANNERS);
        this.waitForByXPath(MOVE_BANNERS_UP);
        this.waitForByXPath(MOVE_BANNERS_DOWN);
        this.waitForByXPath(ADD_BANNER_BUTTON);
        this.waitForByXPath(SAVE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End waitForLinksAndBannersTabReady method");

    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */
    public boolean isFoldersAndFiltersTabReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isFoldersAndFiltersTabReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(GENERAL_TAB) && this.isElementVisibleByXPath(SECURITY_TAB)
                && this.isElementVisibleByXPath(SECURITY_TAB) && this.isElementVisibleByXPath(LINKS_BANNER_TAB)
                && this.isElementVisibleByXPath(FOLDERS_FILTERS_TAB) && this.isElementVisibleByXPath(CUSTOMIZATION_TAB)
                && this.isElementVisibleByXPath(METADATA_TAB) && this.isElementVisibleByXPath(ROOT_FOLDER_SECTION)
                && this.isElementVisibleByXPath(PARENT_ELEMENT_SECTION) && this.isElementVisibleByXPath(FILTERS_SECTION)
                && this.isElementVisibleByXPath(PORTAL_CLIENT_FILTERS)
                && this.isElementVisibleByXPath(AVAILABLE_FILTERS) && this.isElementVisibleByXPath(SELECTED_FILTERS)
                && this.isElementVisibleByXPath(ADD_FILTERS) && this.isElementVisibleByXPath(REMOVE_FILTERS)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isFoldersAndFiltersTabReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */
    public void waitForFoldersAndFiltersTabReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start waitForFoldersAndFiltersTabReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);
        this.waitForByXPath(GENERAL_TAB);
        this.waitForByXPath(SECURITY_TAB);
        this.waitForByXPath(LINKS_BANNER_TAB);
        this.waitForByXPath(FOLDERS_FILTERS_TAB);
        this.waitForByXPath(CUSTOMIZATION_TAB);
        this.waitForByXPath(METADATA_TAB);
        this.waitForByXPath(LINKS_SECTION);
        this.waitForByXPath(ROOT_FOLDER_SECTION);
        this.waitForByXPath(PARENT_ELEMENT_SECTION);
        // this.waitForByXPath(CHILD_FOLDER_SECTION);
        this.waitForByXPath(FILTERS_SECTION);
        this.waitForByXPath(PORTAL_CLIENT_FILTERS);
        this.waitForByXPath(AVAILABLE_FILTERS);
        this.waitForByXPath(SELECTED_FILTERS);
        this.waitForByXPath(ADD_FILTERS);
        this.waitForByXPath(REMOVE_FILTERS);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End waitForFoldersAndFiltersTabReady method");

    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */
    public boolean isCustomizationTabReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isCustomizationTabReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(GENERAL_TAB) && this.isElementVisibleByXPath(SECURITY_TAB)
                && this.isElementVisibleByXPath(SECURITY_TAB) && this.isElementVisibleByXPath(LINKS_BANNER_TAB)
                && this.isElementVisibleByXPath(FOLDERS_FILTERS_TAB) && this.isElementVisibleByXPath(CUSTOMIZATION_TAB)
                && this.isElementVisibleByXPath(METADATA_TAB)
                && this.isElementVisibleByXPath(ENABLE_ADVANCE_SEARCH_AREA)
                && this.isElementVisibleByXPath(ENABLE_ADAVANCE_SEARCH_CHECKBOX)
                && this.isElementVisibleByXPath(HEADER_GRADIENT)
                && this.isElementVisibleByXPath(HEADER_GRADIENT_DROPDOWN) && this.isElementVisibleByXPath(LINK_COLOR)
                && this.isElementVisibleByXPath(LINK_COLOR_DROPDOWN) && this.isElementVisibleByXPath(SEARCH_GRADIENT)
                && this.isElementVisibleByXPath(SEARCH_GRADIENT_DROPDOWN) && this.isElementVisibleByXPath(TEXT_SEARCH)
                && this.isElementVisibleByXPath(TEXT_SEARCH_DROPDOWN)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isCustomizationTabReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    public void waitForCustomizationTabTabReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(GENERAL_TAB);
        this.waitForByXPath(SECURITY_TAB);

        this.waitForByXPath(LINKS_BANNER_TAB);
        this.waitForByXPath(FOLDERS_FILTERS_TAB);
        this.waitForByXPath(CUSTOMIZATION_TAB);
        this.waitForByXPath(METADATA_TAB);
        this.waitForByXPath(ENABLE_ADVANCE_SEARCH_AREA);
        this.waitForByXPath(ENABLE_ADAVANCE_SEARCH_CHECKBOX);
        this.waitForByXPath(HEADER_GRADIENT);
        this.waitForByXPath(HEADER_GRADIENT_DROPDOWN);
        this.waitForByXPath(LINK_COLOR);
        this.waitForByXPath(LINK_COLOR_DROPDOWN);
        this.waitForByXPath(SEARCH_GRADIENT);
        this.waitForByXPath(SEARCH_GRADIENT_DROPDOWN);
        this.waitForByXPath(TEXT_SEARCH);
        this.waitForByXPath(TEXT_SEARCH_DROPDOWN);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");

    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */
    public boolean isUploadReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isUploadReady method");

        boolean isReady = false;

        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BROWSE_BUTTON_UPLOAD_WINDOW)
                && this.isElementVisibleByXPath(ACCEPT_BUTTON_UPLOAD_WINDOW)
                && this.isElementVisibleByXPath(CANCEL_BUTTON_UPLOAD_WINDOW)
                && this.isElementVisibleByXPath(UPLOAD_PANEL) && this.isElementVisibleByXPath(UPLOAD_TEXT)
                && this.isElementVisibleByXPath(BROWSE_INPUT)) {
            isReady = true;

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isUploadReady method");

        return isReady;

    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */
    public void waitForUploadPanel() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForUploadPanel method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BROWSE_BUTTON_UPLOAD_WINDOW);
        this.waitForByXPath(UPLOAD_PANEL);
        this.waitForByXPath(ACCEPT_BUTTON_UPLOAD_WINDOW);
        this.waitForByXPath(CANCEL_BUTTON_UPLOAD_WINDOW);
        this.waitForByXPath(UPLOAD_TEXT);
        this.waitForByXPath(BROWSE_INPUT);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForUploadPanel method");

    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */

    public boolean isCollectionSelectorTabReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isCollectionSelectorTabReady method");
        boolean isReady = false;

        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(SELECT_COLLECTION_CONTENT)
                && this.isElementVisibleByXPath(SELECT_IMAGE_FROM_COLLECTION_TEXT)
                && this.isElementVisibleByXPath(CLOSE_BUTTON_SELECT_COLLECTION)
                && this.isElementVisibleByXPath(COLLECTION_SELECTOR_LABEL)
                && this.isElementVisibleByXPath(COLLECTION_SELECT_DROPDOWN)
                && this.isElementVisibleByXPath(COLLECTION_WRAPPER_AREA)
                && this.isElementVisibleByXPath(CANCEL_BUTTON_COLLECTION_SELECTOR)
                && this.isElementVisibleByXPath(SELECT_BUTTON_COLLECTION_SELECTOR)) {
            isReady = true;

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isCollectionSelectorTabReady method");
        return isReady;

    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */

    public void waitForCollectionSelectorTab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start waitForCollectionSelectorTab method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(SELECT_COLLECTION_CONTENT);
        this.waitForByXPath(SELECT_IMAGE_FROM_COLLECTION_TEXT);
        this.waitForByXPath(CLOSE_BUTTON_SELECT_COLLECTION);
        this.waitForByXPath(COLLECTION_SELECTOR_LABEL);
        this.waitForByXPath(COLLECTION_SELECT_DROPDOWN);
        this.waitForByXPath(COLLECTION_WRAPPER_AREA);
        this.waitForByXPath(CANCEL_BUTTON_COLLECTION_SELECTOR);
        this.waitForByXPath(SELECT_BUTTON_COLLECTION_SELECTOR);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start waitForCollectionSelectorTab method");

    }

    /**
     * Method to navigate back to the Microsite General list page.
     * @return {@link Microsite Page} ready to work with.
     * @author mpapishe
     */
    @Override
    public MicrositeGeneralPage goBack() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        MicrositeGeneralPage dashboard = new MicrositeGeneralPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");

        return dashboard;
    }

    /**
     * Method to save the new/edited server.
     * @return {@link MicroSite GeneralPage} ready to work with or null if the form wasn't completed.
     * @author mpapishe
     */
    public MicrositeGeneralPage clickOnSave() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        // scroll to bottom of the page and click on save button
        this.scrollBottom();
        this.waitForByElement(this.getElementByXPath(SAVE_BUTTON));
        this.getElementByXPath(SAVE_BUTTON).click();

        this.driver.sleep(1);

        MicrositeGeneralPage genralPage = null;

        // check for the required message when the iste is saved with out fuilling the required fields
        if (!this.isElementVisibleByXPath(REQUIRED_FIELD_MESSAGE, 1)) {
            // If no error is shown:
            this.waitUntilDisappearByXPath(SAVE_BUTTON);
            this.waitUntilDisappearByXPath(SPINNER);
            genralPage = new MicrositeGeneralPage(driver, this.getSectionsVisible());
            genralPage.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

        return genralPage;
    }

    /**
     * Method to check if required Messsage is shown
     * @return boolean about if required field message is shown or not
     * @author mpapishe
     */
    public boolean isRequiredFieldMessageShown() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isRequiredFieldMessageShown method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(REQUIRED_FIELD_MESSAGE, 1)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequiredFieldMessageShown method");

        return isReady;
    }

    /**
     * @return boolean about if required field message is shown or not
     * @author mpapishe
     */
    public boolean isErrorMessageIsShownForRequiredField() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - isErrorMessageIsShownForRequiredField method");

        boolean isReady = false;
        // Check if error message is shown
        if (this.isElementVisibleByXPath(ERROR_MESSAGE_FOR_REQUIRED_PAGE, 1)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isErrorMessageIsShownForRequiredField method");

        return isReady;
    }

    /**
     * Filling the Details in microsite genral page
     * @param micrositeName
     * @author mpapishe
     */

    public void fillDetailsinGenaralPage(String micrositeName, String seoMetadata, String authenticationType) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillDetailsinGenaralPage method");

        // Filling the MicrositeName
        this.getElementByXPath(MICROSITE_NAME).sendKeys(micrositeName);

        // Filling the SEO Metadata
        this.getElementByXPath(SEO_METADATA).sendKeys(seoMetadata);

        // Enable microsite
        if (authenticationType.equalsIgnoreCase("Public"))
            this.enablingMicrosite();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillDetailsinGenaralPage  method");
    }

    /**
     * Selecting public as authentication type for creating the Microsite
     * @author mpapishe
     */

    public void selectAutheticationType(String type) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAutheticationType method");

        List<WebElement> authenticationtypes = this.getElementsByXPath(AUTHENTICATIONTYPE_DROPDOWN);
        // Loop through the options and click the first option
        log.info("[log-PageObjects -info] " + this.getClass().getSimpleName()
                + " - Total suggestions present in dropdown are : " + authenticationtypes.size());

        // Click on the type of authentication
        for (WebElement option : authenticationtypes) {

            if (type.equals(option.getText())) {
                option.click();
                break;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAutheticationType  method");
    }

    /**
     * @return boolean about if public authentication type shown or not
     * @author mpapishe
     */
    public boolean isPublicAuthenticationtypeeSelected() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isPublicAuthenticationtypeeSelected method");

        boolean isReady = false;

        if (this.getElementByXPath(AUTHENTICATIONTYPE_SELECTED).getText().equalsIgnoreCase("public")) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isPublicAuthenticationtypeeSelected method");

        return isReady;

    }

    /**
     * @return boolean about if public authentication type shown or not
     * @author mpapishe
     */
    public boolean isPrivateAuthenticationtypeeSelected() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isPrivateAuthenticationtypeeSelected method");

        boolean isReady = false;

        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(USER_ACCESS)
                && this.isElementVisibleByXPath(AUTHORIZED_GROUP_AVAILABLE)
                && this.isElementVisibleByXPath(AUTHORIZED_GROUP_SELECTED)
                && this.isElementVisibleByXPath(AUTHORIZED_GROUP_ADD)
                && this.isElementVisibleByXPath(AUTHORIZED_GROUP_REMOVE)
                && this.isElementVisibleByXPath(AVAILABLE_TESTUSERS) && this.isElementVisibleByXPath(SELECTED_TESTUSERS)
                && this.isElementVisibleByXPath(ADD_TESTUSERS) && this.isElementVisibleByXPath(REMOVE_TESTUSERS)
                && this.isElementVisibleByXPath(ADD_USERS_BUTTON)) {
            isReady = true;

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isPrivateAuthenticationtypeeSelected method");

        return isReady;

    }

    /**
     * @return boolean about if Role type is selected as Admin shown or not
     * @author mpapishe
     */
    public boolean isAdminRoleIsSelected() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isAdminRoleIsSelected method");

        boolean isReady = false;

        if (this.getElementByXPath(SELECTED_ROLE).getText().equalsIgnoreCase("Everyone")) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isAdminRoleIsSelected method");

        return isReady;

    }

    /**
     * @return Selecting authorized Groups for Security tab of Microsite
     * @author mpapishe
     */
    public void selectAuthorizedgroups() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectAuthorizedgroups method");

        List<String> lists = new ArrayList<>();

        // Adding the admin group to the list
        lists.add("Everyone");

        // Moving the options in the list to Selected tab from avialable tab
        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, AUTHORIZED_GROUP_AVAILABLE, AUTHORIZED_GROUP_AVAILABLE_OPTIONS, AUTHORIZED_GROUP_ADD);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectAuthorizedgroups method");

    }

    /**
     * Selecting the "admin" role for the public site
     * @author mpapishe
     */
    public void selectingAdminRoleforPublicType(String roleName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectingRoleforPublicType method");

        List<WebElement> roles = this.getElementsByXPath(ROLES_DROPDOWN);

        // Loop through the options and select the correct option
        log.info("[log-PageObjects -info] " + this.getClass().getSimpleName()
                + " - Total suggestions present in dropdown are : " + roles.size());

        for (WebElement option : roles) {

            if (roleName.equals(option.getText())) {
                option.click();
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectingRoleforPublicType  method");

    }

    /**
     * Enabling the micro site
     * @author mpapishe
     */
    public void enablingMicrosite() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start enablingMicrosite method");

        if (!(this.getElementByXPath(ENABLE_MICROSITE_CHECKBOX).isSelected())) {
            this.getElementByXPath(ENABLE_MICROSITE_CHECKBOX).click();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End enablingMicrosite  method");

    }

    /**
     * Method to navigate to Security Tab
     * @author mpapishe
     */

    public void navigateSecuritytab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start navigateSecuritytab method");

        this.driver.sleep(1);

        this.getElementByXPath(SECURITY_TAB).click();

        this.waitForSecurityTabReady();

        this.driver.sleep(3);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End navigateSecuritytab  method");

    }

    /**
     * Method to navigate to Metadata Tab
     */

    public void navigateMetadatatab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start navigateSecuritytab method");

        this.getElementByXPath(METADATA_TAB).click();

        this.waitForMetadataTabReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End navigateSecuritytab  method");

    }

    /**
     * Method to navigate to Folder and Filters Tab
     */
    public void navigateFoldersAndFilterstab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start navigatefoldersAndFilterstab method");

        this.getElementByXPath(FOLDERS_FILTERS_TAB).click();
        this.waitForFoldersAndFiltersTabReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End navigatefoldersAndFilterstab  method");

    }

    /**
     * Method to navigate to Links and Banners Tab
     * @author mpapishe
     */
    public void navigateLinksAndBannersstab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start navigateLinksAndBannersstab method");

        this.getElementByXPath(LINKS_BANNER_TAB).click();
        this.waitForLinksAndBannersTabReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End navigateLinksAndBannersstab  method");

    }

    /**
     * Method to navigate to Customization Tab
     * @author mpapishe
     */
    public void navigateCustomizationtab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start navigateCustomizationtab method");

        this.getElementByXPath(CUSTOMIZATION_TAB).click();
        this.waitForCustomizationTabTabReady();
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End navigateCustomizationtab  method");

    }

    /**
     * Method to enable Advance search in Microsite for Microsite tab of Adminitration
     * @author mpapishe
     */

    public void enableAdvancesearchInMicrosite() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start enableAdvancesearchInMicrosite method");

        boolean isSelected = this.getElementByXPath(ENABLE_ADAVANCE_SEARCH_CHECKBOX).isSelected();

        if (!(isSelected)) {
            this.getElementByXPath(ENABLE_ADAVANCE_SEARCH_CHECKBOX).click();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End enableAdvancesearchInMicrosite  method");

    }

    /**
     * Method to upload desktop Image
     * @param fileName
     * @return desktopsrc param
     * @throws IOException
     * @author mpapishe
     */
    public String uploadDesktopLogo(String fileName) throws IOException {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start uploadDesktopLogo method");

        // Click on change image
        this.waitForByElement(this.getElementByXPath(DESKTOP_CHANGE_IMAGE), 2);
        this.getElementByXPath(DESKTOP_CHANGE_IMAGE).click();
        this.waitForUploadPanel();
        assertTrue("Upload page is ready", this.isUploadReady());

        // click on browse image
        this.getElementByXPath(BROWSE_BUTTON_UPLOAD_WINDOW).click();

        // upload file
        this.uploadData(fileName);
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(10);
        // click on upload button
        this.getElementByXPath(ACCEPT_BUTTON_UPLOAD_WINDOW).click();

        this.driver.sleep(10);

        String desktopSrc = this.getImageSrc();

        this.driver.sleep(3);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End uploadDesktopLogo  method");

        return desktopSrc;

    }

    /**
     * Method to upload an Tablet Image
     * @param fileName
     * @throws IOException
     * @author mpapishe
     */

    public void uploadTabletLogo(String fileName) throws IOException {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start uploadTabletLogo method");

        this.waitForByXPath(TABLET_CHANGE_IMAGE);
        // Click on change image
        this.getElementByXPath(TABLET_CHANGE_IMAGE).click();
        this.waitForUploadPanel();
        assertTrue("Upload page is ready", this.isUploadReady());

        // click on browse image
        this.getElementByXPath(BROWSE_BUTTON_UPLOAD_WINDOW).click();
        //

        // upload file
        this.uploadData(fileName);
        this.driver.sleep(10);
        // click on upload button
        this.getElementByXPath(ACCEPT_BUTTON_UPLOAD_WINDOW).click();
        this.driver.sleep(10);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End uploadTabletLogo  method");

    }

    /**
     * Method to upload MobileImage
     * @param fileName
     * @throws IOException
     * @author mpapishe
     */
    public void uploadMobileLogo(String fileName) throws IOException {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start uploadMobileLogo method");

        // Click on change image
        this.getElementByXPath(MOBILE_CHANGE_IMAGE).click();
        this.waitForUploadPanel();
        assertTrue("Upload page is ready", this.isUploadReady());
        // click on browse image
        this.getElementByXPath(BROWSE_BUTTON_UPLOAD_WINDOW).click();
        // upload file
        this.uploadData(fileName);
        this.driver.sleep(8);
        this.waitForByElement(this.getElementByXPath(ACCEPT_BUTTON_UPLOAD_WINDOW));
        this.getElementByXPath(ACCEPT_BUTTON_UPLOAD_WINDOW).isEnabled();
        // click on upload button
        this.getElementByXPath(ACCEPT_BUTTON_UPLOAD_WINDOW).click();
        this.driver.sleep(10);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End uploadMobileLogo  method");

    }

    /**
     * Method to getImageSrc for Desktop Image
     * @return src param
     * @author mpapishe
     */
    public String getImageSrc() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getImageSrc method");

        this.waitForByElement(this.getElementByXPath(DESKTOP_PREVIEW));

        String src = this.getElementByXPath(DESKTOP_PREVIEW).getAttribute("src").toString().trim();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getImageSrc method");

        return src;
    }

    /**
     * Method to selectDestopLogo from collection
     * @param collectionName
     * @author mpapishe
     */

    public void selectDesktopLogoFromCollection(String collectionName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectDesktopLogoFromCollection method");

        this.getElementByXPath(DESKTOP_SELECT_IMAGE).click();
        this.waitForCollectionSelectorTab();
        assertTrue("The collection page is not ready", this.isCollectionSelectorTabReady());
        // Selecting collection
        List<WebElement> collections = this.getElementsByXPath(COLLECTION_SELECT_DROPDOWN);
        // Loop through the options and click the collection
        for (WebElement option : collections) {

            if (collectionName.equals(option.getText())) {
                option.click();
            }
        }
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(2);
        // Selecting the asset from collection wrapper
        List<WebElement> assets = this.getElementsByXPath(ASSETLIST_COLLECTION_WRAPPER);
        // Loop through the options and click the first option
        for (WebElement collectionasset : assets) {
            collectionasset.click();
            break;
        }
        // Click on slect button
        this.waitForByElement(getElementByXPath(SELECT_BUTTON_COLLECTION_SELECTOR));
        this.getElementByXPath(SELECT_BUTTON_COLLECTION_SELECTOR).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectDesktopLogoFromCollection method");
    }

    /**
     * Method to select tablet Logo from Collection 
     * @param collectionName
     * @author mpapishe
     */

    public void selectTabletLogoFromCollection(String collectionName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectTabletLogoFromCollection method");

        this.driver.sleep(1);
        this.waitForByElement(getElementByXPath(TABLET_SELECT_IMAGE));
        this.getElementByXPath(TABLET_SELECT_IMAGE).click();
        this.waitForCollectionSelectorTab();
        assertTrue("The collection page is not ready", this.isCollectionSelectorTabReady());
        // Selecting collection
        List<WebElement> collections = this.getElementsByXPath(COLLECTION_SELECT_DROPDOWN);
        // Loop through the options and click the collection
        for (WebElement option : collections) {

            if (collectionName.equals(option.getText())) {
                option.click();
            }
        }
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(2);
        // Selecting the asset from collection wrapper
        List<WebElement> assets = this.getElementsByXPath(ASSETLIST_COLLECTION_WRAPPER);
        // Loop through the options and click the first option
        for (WebElement collectionasset : assets) {
            collectionasset.click();
            break;
        }
        // Click on slect button
        this.getElementByXPath(SELECT_BUTTON_COLLECTION_SELECTOR).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectTabletLogoFromCollection method");
    }

    /**
     * Method to select a Mobile Logo from the collection
     * @param collectionName
     * @author mpapishe
     */
    public void selectMobileLogoFromCollection(String collectionName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectMobileLogoFromCollection method");

        this.driver.sleep(2);
        this.waitForByElement(this.getElementByXPath(MOBILE_SELECT_IMAGE));
        this.getElementByXPath(MOBILE_SELECT_IMAGE).click();
        this.waitForCollectionSelectorTab();
        assertTrue("The collection page is not ready", this.isCollectionSelectorTabReady());
        // Selecting collection
        List<WebElement> collections = this.getElementsByXPath(COLLECTION_SELECT_DROPDOWN);
        // Loop through the options and click the collection
        for (WebElement option : collections) {
            if (collectionName.equals(option.getText())) {
                option.click();
            }
        }
        this.waitUntilDisappearByXPath(SPINNER);
        // Selecting the asset from collection wrapper
        List<WebElement> assets = this.getElementsByXPath(ASSETLIST_COLLECTION_WRAPPER);
        this.driver.sleep(3);
        // Loop through the options and click the first option
        for (WebElement collectionasset : assets) {
            collectionasset.click();
            break;
        }
        // Click on slect button
        this.getElementByXPath(SELECT_BUTTON_COLLECTION_SELECTOR).click();

        this.driver.sleep(2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectMobileLogoFromCollection method");
    }

    /**
     * Method to Delete the Logos for the microsite
     * @author mpapishe
     */
    public void deleteLogos() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteLogos method");

        this.getElementByXPath(REMOVE_DESKTOP_lOGO_BUTTON).click();
        this.waitForByXPath(REMOVE_TABLET_LOGO_BUTTON);
        this.getElementByXPath(REMOVE_TABLET_LOGO_BUTTON).click();
        this.waitForByXPath(REMOVE_MOBILE_LOGO_BUTTON);
        this.getElementByXPath(REMOVE_MOBILE_LOGO_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteLogos method");
    }

    /**
     * Method to Fill the dates for Microsite check for Expiry date
     * @param fromDate param
     * @param toDate param
     * @author mpapishe
     */
    public void fillMicrositeExpirydate(String fromDate, String toDate) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillMicrpsiteExpirydate method");

        this.waitForByElement(getElementByXPath(FROMDATE_DATE_PICKER));
        this.getElementByXPath(FROMDATE_DATE_PICKER).clear();
        this.getElementByXPath(FROMDATE_DATE_PICKER).sendKeys(fromDate);
        this.waitForByElement(getElementByXPath(TODATE_DATE_PICKER));
        this.getElementByXPath(TODATE_DATE_PICKER).clear();
        this.getElementByXPath(TODATE_DATE_PICKER).sendKeys(toDate);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillMicrpsiteExpirydate method");

    }

    /**
     * Method to click on back Button
     * @author mpapishe
     */
    public void clickBackButton() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickBackButton method");

        this.getElementByXPath(BACK_BUTTON).click();
        this.driver.sleep(3);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickBackButton method");
    }

    /**
     * Method to verify if Expiry date validation is shown
     * @return isShown boolean value
     * @author mpapishe
     */
    public boolean isExpiryDateValidationShown() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isExpiryDateValidationShown method");
        boolean isShown = false;
        if (!this.isElementVisibleByXPath(EXPIRYDATE_VALIDATION, 1)) {
            isShown = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isExpiryDateValidationShown method");

        return isShown;

    }

    /**
     * Method to create the test user for microsite 
     * @param TestuserName
     * @param Password
     * @author mpapishe
     */

    public void createTestUser(String TestuserName, String Password) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start createTestUser method");
        // clicking on Add users button
        this.driver.sleep(1);
        this.getElementByXPath(ADD_USERS_BUTTON).click();
        // Filling User field
        this.driver.sleep(1);
        this.waitForByXPath(USERNAME_TEXTRBOX);
        this.getElementByXPath(USERNAME_TEXTRBOX).sendKeys(TestuserName);
        // Filling password field
        this.waitForByXPath(PASSWORD_TEXTBOX);
        this.getElementByXPath(PASSWORD_TEXTBOX).sendKeys(Password);
        // filling confirm password
        this.waitForByXPath(CONFIRM_PASSWORD_TEXTBOX);
        this.getElementByXPath(CONFIRM_PASSWORD_TEXTBOX).sendKeys(Password);
        // Selecting the Role for test user
        List<String> lists = new ArrayList<>();
        lists.add("Everyone");
        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, ROLES_AVAILABLE, ROLES_AVAILABLE_OPTIONS, ADD_ROLES);
        // Save the test user tab
        this.getElementByXPath(SUBMIT_USER).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start createTestUser method");

    }

    /**
     * Selecting created test user to selcted tab from available tab
     * @param testusers
     * @author mpapishe
     */
    public void selectTestusers(String testusers) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectTestusers method");

        List<String> lists = new ArrayList<>();
        lists.add(testusers);
        this.driver.sleep(1);
        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, AVAILABLE_TESTUSERS, AVAILABLE_TESTUSERS_OPTIONS, ADD_TESTUSERS);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectTestusers method");

    }

    /**
     * Method to create a Link for Microsite
     * @param Link
     * @param URL
     * @author mpapishe
     */

    public void createLink(String Link, String URL) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start createLink method");

        // clicking on Add Link button
        this.getElementByXPath(ADD_LINK_BUTTON).click();
        this.driver.sleep(1);
        assertTrue("Add Link window is not opened", this.getElementByXPath(ADD_NEWLINK_WINDOW).isDisplayed());
        this.driver.sleep(1);
        this.getElementByXPath(ADD_LINK_TITLE).sendKeys(Link);
        this.driver.sleep(1);
        this.getElementByXPath(ADD_LINK_URL).sendKeys(URL);
        this.driver.sleep(1);
        this.getElementByXPath(SUBMIT_BUTTON_FOR_ADD_LINK).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start createLink method");

    }

    /**
     * Method to Select a link from available tab to selected tab
     * @param Link
     * @author mpapishe
     */

    public void selectLink(String Link) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectLink method");

        List<String> lists = new ArrayList<>();
        lists.add(Link);
        this.driver.sleep(1);
        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, AVAILABLE_LINKS, AVAILABLE_LINK_OPTIONS, ADD_LINKS);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectLink method");

    }

    /**
     * Method to Add Banner From Collections
     * @param BannerTitle
     * @param collectionName
     * @author mpapishe
     */

    public void addBannerFromCollection(String BannerTitle, String collectionName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addBannerFromCollection method");

        this.getElementByXPath(ADD_BANNER_BUTTON).click();
        this.driver.sleep(1);
        assertTrue("Add Link window is not opened", this.getElementByXPath(ADD_NEW_BANNER_WINDOW).isDisplayed());
        this.driver.sleep(1);
        this.waitForByXPath(BANNER_TITLE);
        this.getElementByXPath(BANNER_TITLE).sendKeys(BannerTitle);
        // this.getElementByXPath(BANNER_TYPE_OPTIONS).click();
        this.selectBannerType("From collection");

        MicrositeBannersFromCollections bannerFromCollection = new MicrositeBannersFromCollections(driver);
        bannerFromCollection.isReady();

        // selecting a image and canceling without saving it
        bannerFromCollection.selectImage(collectionName);
        bannerFromCollection.clickCancel();
        this.driver.sleep(2);
        // Selecting image from change Image and saving it
        this.waitForByXPath(CHANGE_IMAGE_BUTTON);
        this.getElementByXPath(CHANGE_IMAGE_BUTTON).click();
        bannerFromCollection.isReady();
        // selecting a image and saving it
        bannerFromCollection.selectImage(collectionName);
        bannerFromCollection.clickSave();
        this.driver.sleep(3);
        this.waitForByElement(this.getElementByXPath(SUBMIT_BANNER_BUTTON));
        this.getElementByXPath(SUBMIT_BANNER_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End addBannerFromCollection method");

    }

    /**
     * Method to Add Basnners from External Image
     * @param bannerName
     * @param URL
     * @author mpapishe
     */
    public void addBannerFromExternalImage(String bannerName, String URL) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addBannerFromExternalImage method");

        this.getElementByXPath(ADD_BANNER_BUTTON).click();
        this.driver.sleep(1);
        assertTrue("Add Link window is not opened", this.getElementByXPath(ADD_NEW_BANNER_WINDOW).isDisplayed());
        this.driver.sleep(1);
        this.waitForByXPath(BANNER_TITLE);
        this.getElementByXPath(BANNER_TITLE).sendKeys(bannerName);
        this.selectBannerType("External image");
        this.getElementByXPath(EXTERNAL_IMAGE_URL).sendKeys(URL);
        this.waitForByXPath(SPINNER);
        this.getElementByXPath(BANNER_TITLE).click();
        this.driver.sleep(5);
        this.getElementByXPath(IMAGE_PREVIEW_WRAPPER).isDisplayed();
        this.waitForByElement(this.getElementByXPath(SUBMIT_BANNER_BUTTON));
        this.getElementByXPath(SUBMIT_BANNER_BUTTON).click();
        this.driver.sleep(2);
        this.waitUntilDisappearByXPath(SUBMIT_BANNER_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End addBannerFromExternalImage method");

    }

    /**
     * Method to Add Banners from Upload Image option
     * @param bannerName
     * @param Filename
     * @throws IOException
     * @author mpapishe
     */
    public void addBannerFromUploadImage(String bannerName, String Filename) throws IOException {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addBannerFromExternalImage method");

        this.getElementByXPath(ADD_BANNER_BUTTON).click();
        this.waitForByXPath(BANNER_TITLE);
        this.waitForByElement(this.getElementByXPath(BANNER_TITLE));
        this.getElementByXPath(BANNER_TITLE).sendKeys(bannerName);
        this.selectBannerType("Uploaded image");
        this.waitUntilDisappearByXPath(SPINNER);
        this.waitForByXPath(BROWSE_BUTTON);
        this.getElementByXPath(BROWSE_BUTTON).click();
        this.getElementByXPath(UPLOAD_BANNER).isDisplayed();
        this.uploadData(Filename);
        this.driver.sleep(5);
        this.waitUntilDisappearByXPath(SPINNER);
        this.waitForByXPath(IMAGE_PREVIEW_WRAPPER);
        this.getElementByXPath(IMAGE_PREVIEW_WRAPPER).click();
        this.getElementByXPath(IMAGE_PREVIEW_WRAPPER).isDisplayed();
        this.waitForByXPath(SUBMIT_BANNER_BUTTON);
        this.getElementByXPath(SUBMIT_BANNER_BUTTON).click();
        this.driver.sleep(2);
        this.waitUntilDisappearByXPath(SUBMIT_BANNER_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addBannerFromExternalImage method");
    }

    /**
     * Method to select Banner type  for microsite
     * @param type
     * @author mpapishe
     */
    public void selectBannerType(String type) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectBannerType method");

        List<WebElement> bannertypes = this.getElementsByXPath(BANNER_TYPE_OPTIONS);
        log.info("[log-PageObjects -info] " + this.getClass().getSimpleName()
                + " - Total suggestions present in dropdown are : " + bannertypes.size());

        // Click on the desired type option.
        for (WebElement option : bannertypes) {
            if (type.equalsIgnoreCase(option.getText().trim())) {
                option.click();
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectBannerType method");
    }

    /**
     * Method to select the banner for Microsite
     * @param Banner
     * @author mpapishe
     */
    public void selectBanner(String Banner) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectBanner method");

        List<String> lists = new ArrayList<>();
        lists.add(Banner);
        this.driver.sleep(1);
        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, AVAILABLE_BANNER, AVAILABLE_BANNER_OPTIONS, ADD_BANNERS);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectBanner method");

    }

    /**
     * Method to expand all sections in page
     * @author mpapishe
     */
    public void expandAllSections() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start expandAllSections method");

        this.getElementByXPath(SORTBY_SECTION).click();
        this.driver.sleep(2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End expandAllSections method");

    }

    /**
     * Method to Deselect all the options 
     * @author mpapishe
     */
    public void deselectAllOptions(String slectedOptionsxpath, String deslectButtonXpath) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deselectAllOptions method");

        Select se = new Select(this.getElementByXPath(slectedOptionsxpath));
        System.out.println(se.toString());
        if (!(se.getOptions().size() == 0)) {
            for (int i = 0; i < se.getOptions().size(); i++) {
                this.getElementByXPath(slectedOptionsxpath).sendKeys(Keys.CONTROL);
                se.selectByIndex(i);
            }
            this.getElementByXPath(deslectButtonXpath).click();
            this.waitUntilDisappearByXPath(SPINNER);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deselectAllOptions method");

    }

    /**
     * Method to pass the list to be Selected in ParametricFilters .
     * @author mpapishe
     */
    public List<String> getListToBeselectedInParametricFilters() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getListToBeselectedInParametricFilters method");

        List<String> lists = new ArrayList<>();
        lists.add("Content Type");
        lists.add("Imported By");
        lists.add("Mime Type");
        lists.add("Image Type");

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getListToBeselectedInParametricFilters method");
        return lists;

    }

    /**
     * Method to Select options for ParametricFilters .
     * @author mpapishe
     */
    public void selectOptionsForParametricFiltersDisplayedOnTable() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectOptionsForParametricFiltersDisplayedOnTable method");

        this.deselectAllOptions(PARAMETRIC_FILTERS_SELECTED, REMOVE_PARAMETRIC_FILTERS);
        Select se = new Select(this.getElementByXPath(PARAMETRIC_FILTERS_AVAILABLE));
        se.deselectAll();
        List<String> lists = this.getListToBeselectedInParametricFilters();
        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, PARAMETRIC_FILTERS_AVAILABLE, PARAMETRIC_FILTERS_AVAILABLE_LIST, ADD_PARAMETRIC_FILTERS);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectOptionsForParametricFiltersDisplayedOnTable method");

    }

    /**
     * Method to get selected LIST of AssetListInformationDisplayed
     * @author mpapishe
     */
    public List<String> getSelectedListParametricFiltersDisplayed() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start AssetListInformationDisplayed method");

        List<String> list = this.getList(PARAMETRIC_FILTERS_SELECTED_LIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End AssetListInformationDisplayed method");
        return list;
    }

    /**
     * Method to pass the list to be Selected in AssetThumbnailsInformationDisplayedOnHover .
     * @author mpapishe
     */
    public List<String> getListToBeselectedInAssetThumbnailsInformationDisplayedOnHover() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getListToBeselectedInAssetThumbnailsInformationDisplayedOnHover method");

        List<String> lists = new ArrayList<>();
        lists.add("Imported By");
        lists.add("Name");

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getListToBeselectedInAssetThumbnailsInformationDisplayedOnHover method");
        return lists;

    }

    /**
     * Method to Select options for ParametricFilters .
     * @author mpapishe
     */
    public void selectOptionsForAssetThumbnailsInformationDisplayedOnHover() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectOptionsForAssetThumbnailsInformationDisplayedOnHover method");

        this.deselectAllOptions(THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_SELECTED, REMOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER);
        Select se = new Select(this.getElementByXPath(THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE));
        se.deselectAll();
        List<String> lists = this.getListToBeselectedInAssetThumbnailsInformationDisplayedOnHover();
        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE, THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE_LIST, ADD_ASSET_THUMBNAILS_INFORMATION_ON_HOVER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectOptionsForAssetThumbnailsInformationDisplayedOnHover method");

    }

    /**
     * Method to get selected LIST of AssetThumbnailsInformationDisplayedOnHover
     * @author mpapishe
     */
    public List<String> getSelectedListForAssetThumbnailsInformationDisplayedOnHover() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getSelectedListForAssetThumbnailsInformationDisplayedOnHover method");

        List<String> list = this.getList(THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_SELECTED_LIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getSelectedListForAssetThumbnailsInformationDisplayedOnHover method");
        return list;
    }

    /**
     * Method to move the asset detial values  up and down in the table using controls
     * @author mpapishe
     */

    public void moveControlsOfSelectedListForAssetThumbnailsInformationDisplayedOnHover() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getSelectedListForAssetThumbnailsInformationDisplayedOnHover method");

        Select se = new Select(this.getElementByXPath(THUMBNAILS_INFORMATION_DISPLAY_ON_HOVER_SELECTED));
        se.deselectAll();
        se.selectByVisibleText("Name");
        this.getElementByXPath(MOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER_UP).click();
        this.getElementByXPath(MOVE_ASSET_THUMBNAIL_INFORMATION_ON_HOVER_DOWN).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getSelectedListForAssetThumbnailsInformationDisplayedOnHover method");

    }

    /**
     * Method to pass the list to be Selected in AssetListInformationDisplayedInTable .
     * @author mpapishe
     */
    public List<String> getListToBeselectedInAssetListInformationDisplayedInTable() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getListToBeselectedInAssetListInformationDisplayedInTable method");

        List<String> lists = new ArrayList<>();

        lists.add("Imported By");
        lists.add("Name");

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getListToBeselectedInAssetListInformationDisplayedInTable method");
        return lists;

    }

    /**
     * Method to get selected LIST of AssetListInformationDisplayedInTable
     * @author mpapishe
     */
    public List<String> getSelectedListForAssetListInformationDisplayedInTable() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getSelectedListForAssetListInformationDisplayedInTable( method");

        List<String> list = this.getList(LIST_INFORMATION_DISPLAY_ON_HOVER_SELECTED_OPTIONS);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getSelectedListForAssetListInformationDisplayedInTable( method");
        return list;
    }

    /**
     * Method to Select options for AssetListInformationDisplayedInTable .
     * @author mpapishe
     */
    public void selectOptionsForAssetListInformationDisplayedInTable() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectOptionsForAssetListInformationDisplayedInTable method");

        this.deselectAllOptions(LIST_INFORMATION_DISPLAY_ON_HOVER_SELECTED, REMOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER);
        Select se = new Select(this.getElementByXPath(LIST_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE));
        se.deselectAll();
        List<String> lists = this.getListToBeselectedInAssetListInformationDisplayedInTable();
        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, LIST_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE, LIST_INFORMATION_DISPLAY_ON_HOVER_AVAILABLE_OPTIONS, ADD_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectOptionsForAssetListInformationDisplayedInTable method");

    }

    /**
     * Method to move the asset List values  up and down in the table using controls
     * @author mpapishe
     */

    public void moveControlsOfSelectedListForAssetListInformationDisplayedInTable() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getSelectedListForAssetThumbnailsInformationDisplayedOnHover method");

        Select se = new Select(this.getElementByXPath(LIST_INFORMATION_DISPLAY_ON_HOVER_SELECTED));
        se.deselectAll();
        se.selectByVisibleText("Name");
        this.getElementByXPath(MOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER_UP).click();
        this.getElementByXPath(MOVE_ASSET_LIST_INFORMATION_DISPLAY_ON_HOVER_DOWN).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getSelectedListForAssetThumbnailsInformationDisplayedOnHover method");

    }

    /**
     * Method to pass the list to be Selected in Asset Information .
     * @author mpapishe
     */
    public List<String> getListToBeselectedInAssetInformation() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getListToBeselectedInAssetInformation method");

        List<String> lists = new ArrayList<>();
        lists.add("ID");
        lists.add("Original Asset ID");
        lists.add("Name");
        lists.add("Asset Version");
        lists.add("Is Latest Version");
        lists.add("Digital Object ID");

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getListToBeselectedInAssetInformation method");
        return lists;

    }

    /**
     * Method to get selected LIST of Asset Information tab
     * @author mpapishe
     */
    public List<String> getSelectedListForAssetInformation() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getSelectedListForAssetInformation method");

        List<String> list = this.getList(ASSET_INFORMATION_SELECTED_LIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End getSelectedListForAssetInformation method");
        return list;
    }

    /**
     * Method to Select options for Asset Information Tab .
     * @author mpapishe
     */
    public void selectOptionsForAssetInformation() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start selectOptionsForAssetInformation method");

        this.deselectAllOptions(ASSET_INFORMATION_SELECTED, REMOVE_ASSET_INFORMATION);
        Select se = new Select(this.getElementByXPath(ASSET_INFORMATION_AVAILABLE));
        se.deselectAll();
        List<String> lists = this.getListToBeselectedInAssetInformation();
        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, ASSET_INFORMATION_AVAILABLE, ASSET_INFORMATION_AVAILABLE_LIST, ADD_ASSET_INFORMATION);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End selectOptionsForAssetInformation method");

    }

    /**
     * Method to move the asset detial values  up and down in the table using controls for asset Information
     * @author mpapishe
     */

    public void moveControlsOfSelectedListForAssetInformation() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start moveControlsOfSelectedListForAssetInformation method");

        Select se = new Select(this.getElementByXPath(ASSET_INFORMATION_SELECTED));
        se.deselectAll();
        se.selectByVisibleText("Original Asset ID");
        this.getElementByXPath(MOVE_ASSET_INFORMATION_SELECTION_UP).click();
        this.getElementByXPath(MOVE_ASSET_INFORMATION_SELECTION_DOWN).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End moveControlsOfSelectedListForAssetInformation method");

    }

    /**
     * Method to pass the list to be Selected in Sort tab.
     * @author mpapishe
     */
    public List<String> getListToBeselectedInSortTab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start getListToBeselectedInSortTab method");

        List<String> lists = new ArrayList<>();

        lists.add("Mime Type");
        lists.add("Name");

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getListToBeselectedInSortTab method");
        return lists;

    }

    /**
     * Method to get selected LIST of Sort tab
     * @author mpapishe
     */
    public List<String> getSelectedListForSortTab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getSelectedListForSort method");

        List<String> list = this.getList(SORTBY_SELECTED_LIST);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getSelectedListForSort method");
        return list;
    }

    /**
     * Method to Select options for Sort Tab .
     * @author mpapishe
     */
    public void selectOptionsForSortTab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectOptionsForSort method");

        this.deselectAllOptions(SORTBY_SELECTED, REMOVE_SORTBY);
        Select se = new Select(this.getElementByXPath(SORTBY_AVAILABLE));
        se.deselectAll();
        List<String> lists = this.getListToBeselectedInSortTab();
        this.selectGivenAvalibleOptionsFromMultiSelectBox(lists, SORTBY_AVAILABLE, SORTBY_AVAILABLE_LIST, ADD_SORTBY);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectOptionsForSort method");

    }

    /**
     * Method to move the asset detial values  up and down in the table using controls
     * @author mpapishe
     */

    public void moveControlsOfSelectedListForSortTab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start moveControlsOfSelectedListForSortTab method");

        Select se = new Select(this.getElementByXPath(ASSET_INFORMATION_SELECTED));
        se.deselectAll();
        se.selectByVisibleText("Name");
        this.getElementByXPath(MOVE_SORT_BY_SELECTION_UP).click();
        this.getElementByXPath(MOVE_SORT_BY_SELECTION_DOWN).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End moveControlsOfSelectedListForSortTab method");

    }

    /**
     * Method to select the filter for Microsite
     * @param filtername
     * @author mpapishe
     */

    public void selectFilterForMicrosite(String filtername) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectFilterForMicrosite method");

        this.waitForByXPath(AVAILABLE_FILTERS);
        this.getElementByXPath(AVAILABLE_FILTERS_LIST).isDisplayed();
        List<WebElement> filters = this.getElementsByXPath(AVAILABLE_FILTERS_LIST);
        // Loop through the options and click the first option
        log.info("[log-PageObjects -info] " + this.getClass().getSimpleName()
                + " - Total suggestions present in dropdown are : " + filters.size());
        // Click on the first option.
        for (WebElement option : filters) {
            if (filtername.equals(option.getText())) {
                option.click();
                break;
            }
        }
        this.getElementByXPath(ADD_FILTERS).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectFilterForMicrosite method");

    }

    /**
     * Method to define the basic colours of Microsite
     * @author mpapishe
     * @return
     */
    public List<String> basicColors() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start basicColors method");
        List<String> lists = new ArrayList<>();

        lists.add("white");
        lists.add("red");
        lists.add("orange");
        lists.add("yellow");
        lists.add("green");
        lists.add("blue");
        lists.add("purple");
        lists.add("black");
        System.out.println(lists);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start basicColors method");
        return lists;
    }

    /**
     * Method to Select the header Gradient Colours
     * @param redColor
     * @return Basic colors for header gradient
     * @author mpapishe
     */
    public List<String> selectHeaderGradient(String redColor) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectHeaderGradient method");

        this.getElementByXPath(HEADER_GRADIENT).isDisplayed();
        this.getElementByXPath(HEADER_GRADIENT_DROPDOWN).click();
        List<String> basicColorsList = this.getList(HEADER_GRADIENT_BASIC_COLORS_LIST);
        this.getElementByXPath(HEADER_GRADIENT_BASIC_COLOR).isDisplayed();
        this.getElementByXPath(HEADER_GRADIENT_SAVED_COLOR).isDisplayed();
        this.getElementByXPath(HEADER_GRADIENT_ADVANCED_COLOR).isDisplayed();
        this.waitForByXPath(HEADER_GRADIENT_BASIC_COLORS_LIST);
        this.getElementByXPath(HEADER_GRADIENT).sendKeys(redColor);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectHeaderGradient method");

        return basicColorsList;

    }

    /**
     * Method to Select the search gardient colors
     * @param greenColor
     * @return basicColorsList of search gradient
     * @author mpapishe
     */
    public List<String> selectSearchGradientr(String greenColor) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectLinkColor method");

        this.getElementByXPath(SEARCH_GRADIENT).isDisplayed();
        this.waitForByXPath(SEARCH_GRADIENT_DROPDOWN);
        this.getElementByXPath(SEARCH_GRADIENT_DROPDOWN).click();
        this.driver.sleep(1);
        List<String> basicColorsList = this.getList(SEARCH_GRADIENT_BASIC_COLORS_LIST);
        this.getElementByXPath(SEARCH_GRADIENT_BASIC_COLOR).isDisplayed();
        this.getElementByXPath(SEARCH_GRADIENT_SAVED_COLOR).isDisplayed();
        this.getElementByXPath(SEARCH_GRADIENT_ADVANCED_COLOR).isDisplayed();
        this.getElementByXPath(SEARCH_GRADIENT).sendKeys(greenColor);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectLinkColor method");

        return basicColorsList;

    }

    /**
     * Method to Select the colors of Link
     * @param blueColor
     * @return basicColorsList for Linkcolors
     * @author mpapishe
     */

    public List<String> selectLinkColor(String blueColor) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectLinkColor method");

        this.getElementByXPath(LINK_COLOR).isDisplayed();
        this.getElementByXPath(LINK_COLOR_DROPDOWN).click();
        this.driver.sleep(1);
        List<String> basicColorsList = this.getList(LINK_COLOR_BASIC_COLORS_LIST);
        this.getElementByXPath(LINK_COLOR_BASIC_COLOR).isDisplayed();
        this.getElementByXPath(LINK_COLOR_SAVED_COLOR).isDisplayed();
        this.getElementByXPath(LINK_COLOR_ADVANCED_COLOR).isDisplayed();
        this.getElementByXPath(LINK_COLOR).sendKeys(blueColor);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectLinkColor method");

        return basicColorsList;

    }

    /**
     * Method to Select the color for Text
     * @param purpleColor
     * @return basicColorsList for Text colors
     * @author mpapishe
     */
    public List<String> selectTextColor(String purpleColor) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectTextColor method");

        this.getElementByXPath(TEXT_SEARCH).isDisplayed();
        this.getElementByXPath(TEXT_SEARCH_DROPDOWN).click();
        this.driver.sleep(1);
        List<String> basicColorsList = this.getList(TEXT_SEARCH_BASIC_COLORS_LIST);
        this.getElementByXPath(TEXT_SEARCH_BASIC_COLOR).isDisplayed();
        this.getElementByXPath(TEXT_SEARCH_SAVED_COLOR).isDisplayed();
        this.getElementByXPath(TEXT_SEARCH_ADVANCED_COLOR).isDisplayed();
        this.getElementByXPath(TEXT_SEARCH).sendKeys(purpleColor);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectTextColor method");

        return basicColorsList;

    }

}
