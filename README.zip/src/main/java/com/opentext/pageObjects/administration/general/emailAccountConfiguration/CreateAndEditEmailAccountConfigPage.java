/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.general.emailAccountConfiguration;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.GeneralSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.ConfigEmail;
import com.opentext.utils.ConfigEmail.ConfigEMailDetails;
import com.opentext.utils.ConfigFactory;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class CreateAndEditEmailAccountConfigPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(CreateAndEditEmailAccountConfigPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String AUTHENTICATION_REQUIRED = "authenticationrequired";

    private final static String MAIL_SERVER_NAME_INPUT = "mailservername";
    private final static String EMAIL_PORT_INPUT = "emailportinput";
    private final static String EMAIL_USERNAME_INPUT = "emailuserNameInput";
    private final static String EMAIL_USERPASS_INPUT = "emailuserPassInput";

    private final static String SENDER_EMAIL_ACCOUNT = "senderEmailAccount";
    private final static String SENDER_NAME = "sendername";

    private final static String MAIL_SERVERNAME_REQUIRED_FIELD_MESSAGE = "mailservernameRequiredFieldMessage";
    private final static String SENDER_EMAIL_ACCOUNT_REQUIRED_FIELD_MESSAGE = "senderEmailAccountRequiredFieldMessage";
    private final static String SENDER_NAME_REQUIRED_FIELD_MESSAGE = "sendernameRequiredFieldMessage";
    private final static String EMAIL_PORT_REQUIRED_FIELD_MESSAGE = "emailPortRequiredFieldMessage";

    private final static String BACK_BUTTON = "backbutton";
    private final static String SAVE_BUTTON = "saveButton";
    private final static String SUSSESSFULLY_SAVED_MESSAGE = "successfullySavedMessage";
    private final static String SEND_EMAIL_TEST = "sendtestemailinput";
    private final static String SEND_EMAIL_BUTTON = "sendtestemailbutton";
    private final static String SEND_TEST_EMAIL_MESSAGE = "sendTestEmailMessage";
    private final static String CHECK_SERVER_STATUS = "checkserverstatus";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public CreateAndEditEmailAccountConfigPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new GeneralSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(AUTHENTICATION_REQUIRED)
                && this.isElementVisibleByXPath(MAIL_SERVER_NAME_INPUT)
                && this.isElementVisibleByXPath(EMAIL_USERNAME_INPUT) && this.isElementVisibleByXPath(EMAIL_PORT_INPUT)
                && this.isElementVisibleByXPath(EMAIL_USERPASS_INPUT) && this.isElementVisibleByXPath(SAVE_BUTTON)
                && this.isElementVisibleByXPath(SENDER_EMAIL_ACCOUNT) && this.isElementVisibleByXPath(SENDER_NAME)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(AUTHENTICATION_REQUIRED);
        this.waitForByXPath(MAIL_SERVER_NAME_INPUT);

        this.waitForByXPath(EMAIL_USERNAME_INPUT);
        this.waitForByXPath(EMAIL_USERPASS_INPUT);
        this.waitForByXPath(EMAIL_PORT_INPUT);

        this.waitForByXPath(SAVE_BUTTON);
        this.waitForByXPath(SENDER_EMAIL_ACCOUNT);
        this.waitForByXPath(SENDER_NAME);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the EmailAccountConfig page.
     * @return dashboard
     */

    public  DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new  DashboardPage(driver,
                this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to save the new/edited server.
     * @return {@link Email Service} ready to work with or null if the form wasn't completed.
     */
    public CreateAndEditEmailAccountConfigPage clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(SAVE_BUTTON).click();
        this.driver.sleep(1);

        CreateAndEditEmailAccountConfigPage mediabinservice = null;

        if (!this.isElementVisibleByXPath(MAIL_SERVERNAME_REQUIRED_FIELD_MESSAGE, 1)) {
            // If no error is shown:
            this.waitUntilDisappearByXPath(SAVE_BUTTON);
            this.waitUntilDisappearByXPath(SPINNER);
            mediabinservice = new CreateAndEditEmailAccountConfigPage(driver, this.getSectionsVisible());
            mediabinservice.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

        return mediabinservice;
    }

    /**
     * @return boolean about if required field message is shown or not
     */
    public boolean isRequiredFieldsMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isRequiredFieldMessageShown method");
        this.driver.sleep(2);
        boolean isReady = false;
        if (this.isElementVisibleByXPath(MAIL_SERVERNAME_REQUIRED_FIELD_MESSAGE)
                && this.isElementVisibleByXPath(SENDER_EMAIL_ACCOUNT_REQUIRED_FIELD_MESSAGE)
                && this.isElementVisibleByXPath(EMAIL_PORT_REQUIRED_FIELD_MESSAGE)
                && this.isElementVisibleByXPath(SENDER_NAME_REQUIRED_FIELD_MESSAGE)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequiredFieldsMessageShown method");

        return isReady;
    }

    /**
     * Method to Create new Library service.
    */
    public void fillEmailConfigDetails(ConfigEMailDetails MAILSERVERNAMEINPUT, ConfigEMailDetails PORTINPUT,
            ConfigEMailDetails EMAILUSERNAMEINPUT, ConfigEMailDetails EMAILUSERPASSINPUT,
            ConfigEMailDetails SENDEREMAILACCOUNT, ConfigEMailDetails SENDERNAME, ConfigEMailDetails SENDEMAILTEST) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillEmailConfigDetails method");

        // Clear exsting data
        this.clearDeatils();

        // Fill details
        ConfigEmail Config = ConfigFactory
                .getEmailServiceConfigDetils(MAILSERVERNAMEINPUT, PORTINPUT, EMAILUSERNAMEINPUT, EMAILUSERPASSINPUT, SENDEREMAILACCOUNT, SENDERNAME, SENDEMAILTEST);

        System.out.println(Config.getMailServerName());
        this.getElementByXPath(MAIL_SERVER_NAME_INPUT).sendKeys(Config.getMailServerName());
        this.getElementByXPath(EMAIL_PORT_INPUT).sendKeys(Config.getEmailPortInput());
        this.getElementByXPath(EMAIL_USERNAME_INPUT).sendKeys(Config.getEmailUserNameInput());
        this.getElementByXPath(EMAIL_USERPASS_INPUT).sendKeys(Config.getEmailPassNameInput());
        this.getElementByXPath(SENDER_EMAIL_ACCOUNT).sendKeys(Config.getEmailAccountInput());
        this.getElementByXPath(SENDER_NAME).sendKeys(Config.getSenderName());
        this.getElementByXPath(SEND_EMAIL_TEST).sendKeys(Config.getSendEmailTest());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillEmailConfigDetails method");

    }

    /**
     * Method to clear data .
    */
    public void clearDeatils() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clearDeatils method");

        this.getElementByXPath(MAIL_SERVER_NAME_INPUT).clear();
        this.getElementByXPath(EMAIL_PORT_INPUT).clear();
        this.getElementByXPath(EMAIL_USERNAME_INPUT).clear();
        this.getElementByXPath(EMAIL_USERPASS_INPUT).clear();
        this.getElementByXPath(SENDER_EMAIL_ACCOUNT).clear();
        this.getElementByXPath(SENDER_NAME).clear();
        this.getElementByXPath(SEND_EMAIL_TEST).clear();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clearDeatils method");

    }

    /**
     * Method to expand Check server status section.
    */
    public void expandCheckServerStatus() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start expandCheckServerStatus method");

        this.getElementByXPath(CHECK_SERVER_STATUS).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End expandCheckServerStatus method");

    }

    /**
     * Method to click on Send test Email
    */
    public void clickOnSendTestEmail() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSendTestEmail method");

        this.waitForByXPath(SEND_EMAIL_BUTTON);

        // Click on Send Test email button
        this.getElementByXPath(SEND_EMAIL_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSendTestEmail method");

    }

    /**
     * Method to check Successfully created message.
     * @return boolean about if server created successfully or not.
    */
    public boolean isSuccessfullyCreatedMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isSuccessfullyCreatedMessageShown method");

        boolean isShown = false;
        if (this.getElementByXPath(SUSSESSFULLY_SAVED_MESSAGE).isDisplayed()) {
            String message = this.getElementByXPath(SUSSESSFULLY_SAVED_MESSAGE).getText();
            if (message.equalsIgnoreCase("Configuration successfully saved.")) {
                isShown = true;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isSuccessfullyCreatedMessageShown method");

        return isShown;

    }

    /**
     * Method to check the service.
     * @return boolean about if email service is working fine or not
    */
    public boolean checkEmailService() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkEmailService method");

        boolean checkemailservice = false;
        this.driver.sleep(2);
        String message = this.getElementByXPath(SEND_TEST_EMAIL_MESSAGE).getText();
        if (message
                .equalsIgnoreCase("E-mail sent. Check your inbox. If the message is not delivered, check your settings.")) {
            checkemailservice = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkEmailService method");

        return checkemailservice;

    }

    /**
     * Method to check the Invalid Email Service.
     * @return boolean about if email service is working fine or not
    */
    public boolean checkInvalidEmailService() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkInvalidEmailService method");

        this.driver.sleep(2);

        boolean checkInvalidemail = false;
        String message = this.getElementByXPath(SEND_TEST_EMAIL_MESSAGE).getText();
        if (message.contains("not valid.")) {
            checkInvalidemail = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkInvalidEmailService method");

        return checkInvalidemail;

    }
}
