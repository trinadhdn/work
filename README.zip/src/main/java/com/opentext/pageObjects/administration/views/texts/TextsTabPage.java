/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.views.texts;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.general.library.LibraryServersPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.ViewsSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka
 */
public class TextsTabPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(TextsTabPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String BACK_BUTTON = "backButton";

    private final static String DRM_TEXT_FOR_DOWNLOAD = "drmTextForDownload";
    private final static String LOGIN_TEXT_FOR_DOWNLOAD = "loginScreenMessage";

    private final static String COPYRIGHT_TEXT = "copyrightText";

    private final static String SAVE_BUTTON = "saveButton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public TextsTabPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new ViewsSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(DRM_TEXT_FOR_DOWNLOAD)
                && this.isElementVisibleByXPath(LOGIN_TEXT_FOR_DOWNLOAD) && this.isElementVisibleByXPath(COPYRIGHT_TEXT)
                && this.isElementVisibleByXPath(SAVE_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(DRM_TEXT_FOR_DOWNLOAD);
        this.waitForByXPath(COPYRIGHT_TEXT);

        this.waitForByXPath(LOGIN_TEXT_FOR_DOWNLOAD);

        this.waitForByXPath(SAVE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the View General page.
     * @return {@link ViewGeneralPage} ready to work with.
     */
    @Override
    public  DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new  DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to fill the data
     */
    public void fillDetails() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillDetails method");

        this.getElementByXPath(DRM_TEXT_FOR_DOWNLOAD).clear();

        this.getElementByXPath(DRM_TEXT_FOR_DOWNLOAD)
                .sendKeys("By checking this box you confirm that you are downloading and intending to use this file under the restrictions provided below. ");

        this.getElementByXPath(LOGIN_TEXT_FOR_DOWNLOAD).clear();

        this.getElementByXPath(LOGIN_TEXT_FOR_DOWNLOAD)
                .sendKeys("<div class='view-content'><div class='views-row views-row-1 views-row-odd views-row-first views-row-last'><div class='views-field-title'><span class='field-content'><h1>OpenText MediaBin Portal Client turns chaos into calm</h1></span></div><div class='views-field-body'><div class='field-content'><p>OpenText MediaBin Portal Client provides an across-the-board solution so you can take control of  content management, accelerate your time to market and champion your brand which  all adds up to huge cost and time savings. Create, access and store marketing content  and assets from across your organization in real time, driving increased effectiveness for  your entire marketing process.</p></div></div></div></div> ");

        this.getElementByXPath(COPYRIGHT_TEXT).clear();

        this.getElementByXPath(COPYRIGHT_TEXT).sendKeys("Copyright © 2017 Opentext. All Rights Reserved.");

        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillDetails method");

    }

    /**
     * Method to save the details
     */
    public void clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(SAVE_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

        this.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

    }

}
