/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText Technologies.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.banners.microsite;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.MicrositeSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Microsite subsections.
 * 
 * @author MavyaPapishetty <mpapishe@opentext.com>
 */
public class MicrositeBannersPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(MicrositeBannersPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private static final String BACK_BUTTON = "backButton";
    private static final String SEARCH_INPUT = "searchInput";
    private static final String MICROSITE_BANNER_TITLE = "micrositeBannerTitle";
    private static final String MICROSITE_BANNER_TITLE_LIST = "micrositeBannersTitleOptions";
    private static final String BANNER_TYPE = "micrositeBannersType";
    private static final String BANNER_TYPE_LIST = "micrositeBannersTypeOptions";
    private static final String BANNER_OPERATIONS = "micrositeBannersOperations";
    private static final String EDIT_OPERATIONS = "micrositeBannerEditOperations";
    private static final String DELETE_OPERATION = "micrositeBannerDeleteOperation";
    private static final String PREVIEW_OPERATION = "micrositeBannerPreviewOperations";
    private static final String ADD_BANNER_BUTTON = "micrositeBannerAddButton";

    private static final String ADD_BANNER_TITLE = "bannerTitle";
    private static final String ADD_BANNER_TYPE = "bannertype";
    private static final String ADD_BANNER_TYPE_OPTIONS = "bannertypeOptions";
    private static final String VALIDATE_ASPECT_RATIO_MSG = "validateAspectratio";
    private static final String ADD_BANNER_PREIVIEW = "bannerPreview";
    private static final String ADD_BANNER_SAVE_BUTTON = "saveButton";

    private static final String EXTERNAL_IMAGE_URL = "externalImageURLField";
    private static final String BROWSE_BUTTON = "browseButton";
    private static final String UPLOAD_BANNER = "uploadBannerInputField";

    private static final String LINKS_TAB = "linksTab";
    private static final String SECURITY_TAB = "securityTab";
    private static final String TESTUSERS_TAB = "testUsersTab";
    private static final String GENERAL_TAB = "generalTab";

    private static final String REQUIRED_FIELD_MESSAGE = "requiredFieldMessage";
    private static final String CHANGE_BUTTON = "changeButton";
    private static final String IMAGE_PREVIEW_WRAPPER = "imagePreviewWrapper";
    private static final String PREVIEW_COLLECTION_TYPE = "previewCollectionType";
    private static final String PREVIEW_COLLECTION_TITLE = "previewCollectionTitle";

    private static final String DELETE_ALERT_BOX = "deleteBannerAlertBox";
    private static final String ALERT_MESSAGE = "aleartMessage";
    private static final String ALERT_BOX_MODEL_OK = "confirmDeleteBannerButton";
    private static final String ALERT_BOX_CANCEL_BUTTON = "cancelDeleteBannerButton";
    private static final String MODAL_OK = "modelOkButton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     * @author mpapishe
     */
    public MicrositeBannersPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new MicrositeSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     * @author mpapishe
     */
    @Override
    public boolean isReady() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;

        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(MICROSITE_BANNER_TITLE) && this.isElementVisibleByXPath(SEARCH_INPUT)
                && this.isElementVisibleByXPath(BANNER_TYPE) && this.isElementVisibleByXPath(BANNER_OPERATIONS)
                && this.isElementVisibleByXPath(ADD_BANNER_BUTTON) && this.isElementVisibleByXPath(LINKS_TAB)
                && this.isElementVisibleByXPath(SECURITY_TAB) && this.isElementVisibleByXPath(TESTUSERS_TAB)
                && this.isElementVisibleByXPath(GENERAL_TAB)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     * @author mpapishe
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(MICROSITE_BANNER_TITLE);
        this.waitForByXPath(SEARCH_INPUT);

        this.waitForByXPath(BANNER_TYPE);
        this.waitForByXPath(BANNER_OPERATIONS);
        this.waitForByXPath(ADD_BANNER_BUTTON);
        this.waitForByXPath(LINKS_TAB);
        this.waitForByXPath(SECURITY_TAB);
        this.waitForByXPath(TESTUSERS_TAB);
        this.waitForByXPath(GENERAL_TAB);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the Dashboard
     * @return {@link DashboardPage} ready to work with.
     * @author mpapishe
     */
    @Override
    public DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(BACK_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");

        return dashboard;
    }

    /**
     * Method to Add Banners from Collection
     * @param BannerTitle
     * @param collectionName
     * @author mpapishe
     */

    public void addBannerFromCollection(String BannerTitle, String collectionName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addBannerFromCollection method");

        this.getElementByXPath(ADD_BANNER_BUTTON).click();
        this.waitForByXPath(ADD_BANNER_TITLE);
        this.getElementByXPath(ADD_BANNER_TITLE).sendKeys(BannerTitle);
        this.getElementByXPath(ADD_BANNER_TYPE).click();
        this.selectBannerType("From collection");

        MicrositeBannersFromCollections bannerFromCollection = new MicrositeBannersFromCollections(driver);
        bannerFromCollection.isReady();

        // selecting a image and canceling without saving it
        bannerFromCollection.selectImage(collectionName);
        bannerFromCollection.clickCancel();

        this.driver.sleep(2);

        // Selecting image from change Image and saving it
        this.waitForByXPath(CHANGE_BUTTON);
        this.getElementByXPath(CHANGE_BUTTON).click();
        bannerFromCollection.isReady();

        // selecting a image and saving it
        bannerFromCollection.selectImage(collectionName);
        bannerFromCollection.clickSave();

        this.waitForByElement(this.getElementByXPath(ADD_BANNER_SAVE_BUTTON));
        this.driver.sleep(2);
        this.getElementByXPath(ADD_BANNER_SAVE_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End addBannerFromCollection method");

    }

    /**
     * Method to Add ?Banner without filling Required fields
     * @param BannerTitle
     * @param type
     * @author mpapishe
     */
    public void addBanner(String BannerTitle, String type) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start AddBanner method");

        this.getElementByXPath(ADD_BANNER_BUTTON).click();
        this.waitForByXPath(ADD_BANNER_TITLE);
        this.getElementByXPath(ADD_BANNER_TITLE).sendKeys(BannerTitle);
        this.getElementByXPath(ADD_BANNER_TYPE).click();

        this.selectBannerType(type);

        this.waitForByElement(this.getElementByXPath(ADD_BANNER_SAVE_BUTTON));
        this.driver.sleep(2);
        this.getElementByXPath(ADD_BANNER_SAVE_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End AddBanner method");

    }

    /**
     * Method to Select the Banner type from dropdown
     * @param type
     * @author mpapishe
     */
    public void selectBannerType(String type) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectBannerType method");

        List<WebElement> bannertypes = this.getElementsByXPath(ADD_BANNER_TYPE_OPTIONS);
        log.info("[log-PageObjects -info] " + this.getClass().getSimpleName()
                + " - Total suggestions present in dropdown are : " + bannertypes.size());
        // Click on the desired type option.
        for (WebElement option : bannertypes) {
            if (type.equalsIgnoreCase(option.getText().trim())) {
                option.click();
                // break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectBannerType method");
    }

    /**
     * Method to verify that required Message is shown or not
     * @return isShown boolean parameter
     * @author mpapishe
     */
    public boolean isRequiredMessageshown() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isRequiredMessageshown method");

        boolean isShown = false;
        this.waitForByXPath(REQUIRED_FIELD_MESSAGE);
        if (this.isElementVisibleByXPath(REQUIRED_FIELD_MESSAGE, 1)) {
            isShown = true;
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequiredMessageshown method");

        return isShown;

    }

    /**
     * Method to GoBack to Banners Tab
     * @author mpapishe
     */
    public void goBackToBannersTab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBackToBannersTab method");

        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(BACK_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBackToBannersTab method");

    }

    /**
     * Method to check if Image Previe wrapper is shown
     * @param bannername
     * @return isShown
     * @author mpapishe
     */
    public boolean isImagePreviewWrapperShown(String bannername) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isImagePreviewWrapperShown method");

        boolean isShown = false;
        List<String> bannersList = this.getList(MICROSITE_BANNER_TITLE_LIST);
        for (String banner : bannersList) {
            if (banner.equalsIgnoreCase(bannername)) {
                this.getElementsByXPath(EDIT_OPERATIONS).get(bannersList.indexOf(banner)).click();
                this.waitForByXPath(IMAGE_PREVIEW_WRAPPER);
                if (this.isElementVisibleByXPath(IMAGE_PREVIEW_WRAPPER, 1)) {
                    isShown = true;
                }
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isImagePreviewWrapperShown method");

        return isShown;

    }

    /**
     * Method to check Banners List has newly created Banner.
     * @return boolean about if Bannere created successfully
     * @author mpapishe
    */
    public boolean isNewlyCreatedBannerNameShownInList(String banner) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isNewlyCreatedBannerNameShownInList method");

        boolean isShown = false;
        this.waitForByXPath(MICROSITE_BANNER_TITLE_LIST);
        List<String> bannerNameList = this.getList(MICROSITE_BANNER_TITLE_LIST);
        for (String bannernames : bannerNameList) {
            if (bannernames.equalsIgnoreCase(banner)) {
                isShown = true;
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isNewlyCreatedBannerNameShownInList method");

        return isShown;

    }

    /**
     * Method to edit the banner
     * @param bannername
     * @return modifiedBannerName
     * @author mpapishe
     */

    public String editBanner(String bannername) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start editBanner method");

        String modifiedBannerName = bannername;
        List<String> bannersList = this.getList(MICROSITE_BANNER_TITLE_LIST);
        for (String banner : bannersList) {
            if (banner.equalsIgnoreCase(bannername)) {

                this.getElementsByXPath(EDIT_OPERATIONS).get(bannersList.indexOf(banner)).click();
                this.waitUntilDisappearByXPath(SPINNER);
                this.waitForByXPath(ADD_BANNER_TITLE);
                this.getElementByXPath(ADD_BANNER_TITLE).clear();
                modifiedBannerName = "Edited" + bannername;
                this.getElementByXPath(ADD_BANNER_TITLE).sendKeys(modifiedBannerName);
                this.getElementByXPath(ADD_BANNER_SAVE_BUTTON).click();
                this.waitUntilDisappearByXPath(SPINNER);
                this.waitUntilDisappearByXPath(ADD_BANNER_SAVE_BUTTON);
                break;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End editBanner method");

        return modifiedBannerName;

    }

    /**
     * Method to get edited banners SRC
     * @param bannername
     * @return src of edited banner
     * @author mpapishe
     */

    public String getEditBannersrc(String bannername) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getEditBannersrc method");

        List<String> bannersList = this.getList(MICROSITE_BANNER_TITLE_LIST);
        for (String banner : bannersList) {
            if (banner.equalsIgnoreCase(bannername)) {
                this.getElementsByXPath(EDIT_OPERATIONS).get(bannersList.indexOf(banner)).click();
                this.waitUntilDisappearByXPath(SPINNER);
                break;
            }
        }

        String src = this.getElementByXPath(IMAGE_PREVIEW_WRAPPER).getAttribute("src").trim();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getEditBannersrc method");

        return src;

    }

    /**
     * Method to get Preview Banner
     * @param bannername
     * @param type
     * @return getPreviewSrc
     * @author mpapishe
     */
    public String getPreviewBanner(String bannername, String type) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getPreviewBanner method");

        List<String> bannersList = this.getList(MICROSITE_BANNER_TITLE_LIST);
        for (String banner : bannersList) {
            if (banner.equalsIgnoreCase(bannername)) {
                this.getElementsByXPath(PREVIEW_OPERATION).get(bannersList.indexOf(banner)).click();
                break;
            }
        }

        assertTrue(bannername.equalsIgnoreCase(this.getElementByXPath(PREVIEW_COLLECTION_TITLE)
                .getText()), " both the collection name must match");
        assertTrue(type.equalsIgnoreCase(this.getElementByXPath(PREVIEW_COLLECTION_TYPE)
                .getText()), " both the collection type must match");

        String getPreviewSrc = this.getElementByXPath(IMAGE_PREVIEW_WRAPPER).getAttribute("src").trim();
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getPreviewBanner method");

        return getPreviewSrc;

    }

    /**
     * Method to Cancel dateletbanner from delete alert
     * @param bannername
     * @author mpapishe
     */
    public void cancelDeleteBanner(String bannername) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start cancelDeleteBanner method");

        List<String> bannersList = this.getList(MICROSITE_BANNER_TITLE_LIST);
        for (String banner : bannersList) {
            if (banner.equalsIgnoreCase(bannername)) {
                this.getElementsByXPath(DELETE_OPERATION).get(bannersList.indexOf(banner)).click();
                this.waitForByXPath(DELETE_ALERT_BOX);
                this.waitForByXPath(ALERT_MESSAGE);
                this.waitForByXPath(ALERT_BOX_CANCEL_BUTTON, 2);
                this.driver.sleep(2);
                this.getElementByXPath(ALERT_BOX_CANCEL_BUTTON).click();
                break;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End cancelDeleteBanner method");

    }

    /**
     * Method to Delete a banner
     * @param bannername
     * @author mpapishe
     */
    public void deleteBanner(String bannername) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteBanner method");

        List<String> bannersList = this.getList(MICROSITE_BANNER_TITLE_LIST);
        for (String banner : bannersList) {
            if (banner.equalsIgnoreCase(bannername)) {
                this.driver.sleep(2);
                this.getElementsByXPath(DELETE_OPERATION).get(bannersList.indexOf(banner)).click();
                this.waitForByXPath(DELETE_ALERT_BOX);
                this.waitForByXPath(ALERT_MESSAGE);
                this.waitForByXPath(ALERT_BOX_MODEL_OK, 2);
                this.driver.sleep(2);
                this.getElementByXPath(ALERT_BOX_MODEL_OK).click();
                this.waitUntilDisappearByXPath(DELETE_ALERT_BOX);
                break;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteBanner method");

    }

    /**
     * Method to Add banner from external Image
     * @param bannerName
     * @param URL
     * @author mpapishe
     */

    public void addBannerFromExternalImage(String bannerName, String URL) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addBannerFromExternalImage method");

        this.getElementByXPath(ADD_BANNER_BUTTON).click();
        this.waitForByXPath(ADD_BANNER_TITLE);
        this.getElementByXPath(ADD_BANNER_TITLE).sendKeys(bannerName);
        this.selectBannerType("External image");
        this.getElementByXPath(EXTERNAL_IMAGE_URL).sendKeys(URL);
        this.waitForByXPath(SPINNER);
        this.getElementByXPath(ADD_BANNER_TITLE).click();
        this.driver.sleep(5);
        this.getElementByXPath(IMAGE_PREVIEW_WRAPPER).isDisplayed();
        this.waitForByElement(this.getElementByXPath(ADD_BANNER_SAVE_BUTTON));
        this.getElementByXPath(ADD_BANNER_SAVE_BUTTON).click();
        this.driver.sleep(2);
        this.waitUntilDisappearByXPath(ADD_BANNER_SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End addBannerFromExternalImage method");

    }

    /**
     * Method to Add Banner from upload Image
     * @param bannerName
     * @param Filename
     * @throws IOException
     * @author mpapishe
     */

    public void addBannerFromUploadImage(String bannerName, String Filename) throws IOException {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addBannerFromUploadImage method");

        this.getElementByXPath(ADD_BANNER_BUTTON).click();
        this.waitForByXPath(ADD_BANNER_TITLE);
        this.getElementByXPath(ADD_BANNER_TITLE).sendKeys(bannerName);
        this.selectBannerType("Uploaded image");
        this.waitUntilDisappearByXPath(SPINNER);
        this.waitForByXPath(BROWSE_BUTTON);
        this.getElementByXPath(BROWSE_BUTTON).click();
        this.uploadData(Filename);
        this.driver.sleep(5);
        this.waitUntilDisappearByXPath(SPINNER);
        this.waitForByXPath(IMAGE_PREVIEW_WRAPPER);
        this.getElementByXPath(IMAGE_PREVIEW_WRAPPER).click();
        this.getElementByXPath(IMAGE_PREVIEW_WRAPPER).isDisplayed();
        this.waitForByXPath(ADD_BANNER_SAVE_BUTTON);
        this.getElementByXPath(ADD_BANNER_SAVE_BUTTON).click();
        this.driver.sleep(2);
        this.waitUntilDisappearByXPath(ADD_BANNER_SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start addBannerFromUploadImage method");
    }

    /**
     * Method to Search for a Banner
     * @param BannerName
     * @author mpapishe
     */

    public void searchforBanner(String BannerName) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start searchforBanner method");

        this.getElementByXPath(SEARCH_INPUT).sendKeys(BannerName);
        if (this.getList(MICROSITE_BANNER_TITLE_LIST).size() == 1) {
            List<String> bannersList = this.getList(MICROSITE_BANNER_TITLE_LIST);
            assertTrue(bannersList.toString().contains(BannerName), "The Microsite link name is not matching");
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End searchforBanner method");
    }

    /**
     * Method to Empty a search tab
     * @author mpapishe
     */
    public void emptySearchTab() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start emptySearchTab method");

        this.getElementByXPath(SEARCH_INPUT).clear();
        this.getElementByXPath(SEARCH_INPUT).sendKeys(Keys.BACK_SPACE);
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End emptySearchTab method");

    }

    /**
     * Method to click on OK button for the warning message
     * @author mpapishe
     */
    public void selectOKButton() {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectOKButton method");

        this.getElementByXPath(MODAL_OK).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectOKButton  method");
    }

}
