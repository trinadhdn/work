/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the commons methods to interact with the Sections page.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public abstract class GeneralResumePage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(GeneralResumePage.class);

    /**
     * Items keys selectors.
     */
    protected final static String SECTION_DYNAMIC = "sectionDynamic";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public GeneralResumePage(EmergyaWebDriver driver) {
        super(driver);
    }

    /**
     * Method to navigate to the proper section main page.
     * @param list of {@link Section} visible.
     * @return specific {@link SectionPage} or {@link SubsectionPage} ready to work with.
     */
    public abstract SectionPage goToSection(List<Section> sections);

}
