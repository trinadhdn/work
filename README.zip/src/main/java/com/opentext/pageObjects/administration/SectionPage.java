/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.administration.subsectionTabs.SubsectionsTabsPage;
import com.opentext.pageObjects.header.HeaderPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the commons methods to interact with the Sections page.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 * @author Estefania Barrera <ebarrera@emergya.com>
 */
public abstract class SectionPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(SectionPage.class);

    /**
     * Components
     */
    private HeaderPage header;
    private List<Section> sectionsVisible;
    protected SubsectionsTabsPage subsectionsTabs;

    /**
     * Items keys selectors.
     */
    private final static String DASHBOARD = "dashboardSection";
    private final static String GENERAL = "generalSection";
    private final static String METADATA = "metadataSection";
    private final static String VIEWS = "viewsSection";
    private final static String SECURITY = "securitySection";
    private final static String MICROSITES = "micrositesSection";

    private final String ACTIVE = "activeSection";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public SectionPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver);
        header = new HeaderPage(driver);
        this.sectionsVisible = sectionsVisible;
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;

        if (header.isReady() && this.isElementVisibleByXPath(DASHBOARD) && this.isElementVisibleByXPath(ACTIVE)) {
            isReady = true;

            if (subsectionsTabs.isPcIdShown(this.getPcIdOfAKeySelector(GENERAL))) {
                if (!this.isElementVisibleByXPath(GENERAL, 5)) {
                    isReady = false;
                }
            }
            if (subsectionsTabs.isPcIdShown(this.getPcIdOfAKeySelector(METADATA))) {
                if (!this.isElementVisibleByXPath(METADATA, 1)) {
                    isReady = false;
                }
            }
            if (subsectionsTabs.isPcIdShown(this.getPcIdOfAKeySelector(VIEWS))) {
                if (!this.isElementVisibleByXPath(VIEWS, 1)) {
                    isReady = false;
                }
            }
            if (subsectionsTabs.isPcIdShown(this.getPcIdOfAKeySelector(SECURITY))) {
                if (!this.isElementVisibleByXPath(SECURITY)) {
                    isReady = false;
                }
            }
            if (subsectionsTabs.isPcIdShown(this.getPcIdOfAKeySelector(MICROSITES))) {
                if (!this.isElementVisibleByXPath(MICROSITES, 1)) {
                    isReady = false;
                }
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        header.waitForReady();
        this.waitForByXPath(DASHBOARD);
        this.waitForByXPath(ACTIVE);

        if (subsectionsTabs.isPcIdShown(this.getPcIdOfAKeySelector(GENERAL))) {
            this.waitForByXPath(GENERAL);
        }
        if (subsectionsTabs.isPcIdShown(this.getPcIdOfAKeySelector(METADATA))) {
            this.waitForByXPath(METADATA);
        }
        if (subsectionsTabs.isPcIdShown(this.getPcIdOfAKeySelector(VIEWS))) {
            this.waitForByXPath(VIEWS);
        }
        if (subsectionsTabs.isPcIdShown(this.getPcIdOfAKeySelector(SECURITY))) {
            this.waitForByXPath(SECURITY);
        }
        if (subsectionsTabs.isPcIdShown(this.getPcIdOfAKeySelector(MICROSITES))) {
            this.waitForByXPath(MICROSITES);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return the header
     */
    public HeaderPage getHeader() {
        return header;
    }

    /**
     * @return the subsectionsTabs, a cast will be needed for the caller.
     */
    public SubsectionsTabsPage getSubsectionsTabs() {
        return subsectionsTabs;
    }

    /**
     * @return the sectionsVisible
     */
    protected List<Section> getSectionsVisible() {
        return sectionsVisible;
    }

    /**
     * Method to obtain the pc-id of the key selector by its xpath.
     * @param key selector to get the pc-id.
     * @return the pc-id of the given selector.
     */
    private String getPcIdOfAKeySelector(String key) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getPcIdOfAKeySelector method");

        String pcid = null;
        for (int i = 0; i <= 5; i++) {
            if (this.getXPath(key).split("pc-id = '")[1].split("'")[0].trim() != null) {
                pcid = this.getXPath(key).split("pc-id = '")[1].split("'")[0].trim();
                break;
            }

        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getPcIdOfAKeySelector method");

        return pcid;
    }

    /**
     * Method to navigate to the previous page
     * @return {@link PCBasePage} object that could be a {@link DashboardPage} or a specific {@link SectionPage}/{@link SubSectionPage}.
     */
    public abstract PCBasePage goBack();

}
