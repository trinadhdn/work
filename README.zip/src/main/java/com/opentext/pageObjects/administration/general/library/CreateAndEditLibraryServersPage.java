/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.general.library;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.GeneralSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.ConfigFactory;
import com.opentext.utils.ConfigLibrary;
import com.opentext.utils.ConfigLibrary.ConfigDetails;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class CreateAndEditLibraryServersPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(CreateAndEditLibraryServersPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String BACK_BUTTON = "backButton";

    private final static String SERVER_CHECKBOX = "enableServerCheckbox";
    private final static String NAME_INPUT = "nameInput";

    private final static String HOSTNAME_INPUT = "hostNameInput";
    private final static String USERNAME_INPUT = "userNameInput";
    private final static String USERPASS_INPUT = "userPassInput";
    private final static String PORT_INPUT = "portInput";
    private final static String PROTOCOL_INPUT = "protocolInput";

    private final static String INDEX_SERVICE_CHECKBOX = "indexServiceCheckbox";
    private final static String CONTENMODEL_SERVICE_CHECKBOX = "contenModelServiceCheckbox";
    private final static String RENDITION_SERVICE_CHECKBOX = "renditionServiceCheckbox";
    private final static String CLOUDSTORAGE_SERVICE_CHECKBOX = "cloudStorageServiceCheckbox";

    private final static String PROXY_COLLAPSABLE = "proxyCollapsable";
    private final static String PROXY_CHECKBOX = "enableProxyCheckbox";
    private final static String PROXY_SERVER_INPUT = "proxyServerInput";
    private final static String PROXY_PORT_INPUT = "proxyPortInput";
    private final static String PROXY_USER_INPUT = "proxyUserInput";
    private final static String PROXY_PASS_INPUT = "proxyPasswordInput";

    private final static String REQUIRED_FIELD_MESSAGE = "requiredFieldMessage";
    private final static String SAVE_BUTTON = "saveButton";
    private final static String SUSSESSFULLY_SAVED_MESSAGE = "successfullySavedMessage";
    private final static String CHECK_SERVICE = "checkservice";
    private final static String CHECK_SERVICE_MESSAGE = "checkservicemessage";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public CreateAndEditLibraryServersPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new GeneralSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 2; i++) {
            if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                    && this.isElementVisibleByXPath(SERVER_CHECKBOX) && this.isElementVisibleByXPath(NAME_INPUT)
                    && this.isElementVisibleByXPath(HOSTNAME_INPUT) && this.isElementVisibleByXPath(USERNAME_INPUT)
                    && this.isElementVisibleByXPath(USERPASS_INPUT) && this.isElementVisibleByXPath(PORT_INPUT)
                    && this.isElementVisibleByXPath(PROTOCOL_INPUT) && this.isElementVisibleByXPath(PROXY_COLLAPSABLE)
                    && this.isElementVisibleByXPath(SAVE_BUTTON)) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(SERVER_CHECKBOX);
        this.waitForByXPath(NAME_INPUT);

        this.waitForByXPath(HOSTNAME_INPUT);
        this.waitForByXPath(USERNAME_INPUT);
        this.waitForByXPath(USERPASS_INPUT);
        this.waitForByXPath(PORT_INPUT);
        this.waitForByXPath(PROTOCOL_INPUT);

        this.waitForByXPath(PROXY_COLLAPSABLE);

        this.waitForByXPath(SAVE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the Library Servers list page.
     * @return {@link LibraryServersPage} ready to work with.
     */
    @Override
    public LibraryServersPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SAVE_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        LibraryServersPage dashboard = new LibraryServersPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");

        return dashboard;
    }

    /**
     * Method to save the new/edited server.
     * @return {@link LibraryServersPage} ready to work with or null if the form wasn't completed.
     */
    public LibraryServersPage clickOnSave() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(SAVE_BUTTON).click();

        LibraryServersPage libraryServers = null;

        if (!this.isElementVisibleByXPath(REQUIRED_FIELD_MESSAGE, 1)) {
            // If no error is shown:
            this.waitUntilDisappearByXPath(SAVE_BUTTON);
            this.waitUntilDisappearByXPath(SPINNER);
            libraryServers = new LibraryServersPage(driver, this.getSectionsVisible());
            libraryServers.waitForReady();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnSave method");

        return libraryServers;
    }

    /**
     * @return boolean about if required field message is shown or not
     */
    public boolean isRequiredFieldMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isRequiredFieldMessageShown method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(REQUIRED_FIELD_MESSAGE, 1)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRequiredFieldMessageShown method");

        return isReady;
    }

    /**
     * Method to Create new Library service.
    */
    public void fillLibraryServerDetails(String SERVERNAME, ConfigDetails SERVERHOSTNAME, ConfigDetails USER,
            ConfigDetails PASSWORD, ConfigDetails PORT) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start fillLibraryServerDetails method");

        ConfigLibrary Config = ConfigFactory.getLibraryConfigDetils(SERVERNAME, SERVERHOSTNAME, USER, PASSWORD, PORT);

        if (!this.getElementByXPath(SERVER_CHECKBOX).isSelected()) {

            this.getElementByXPath(SERVER_CHECKBOX).click();
        }
        this.getElementByXPath(NAME_INPUT).sendKeys(SERVERNAME);
        this.getElementByXPath(HOSTNAME_INPUT).sendKeys(Config.getServerHostName());
        this.getElementByXPath(USERNAME_INPUT).sendKeys(Config.getUser());
        this.getElementByXPath(USERPASS_INPUT).sendKeys(Config.getPassword());
        this.getElementByXPath(PORT_INPUT).sendKeys(Config.getPort());

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillLibraryServerDetails method");

    }

    /**
     * Method to Create new Library service.
    */
    public void disableLibraryServer() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start disableLibraryServer method");

        if (this.getElementByXPath(SERVER_CHECKBOX).isSelected()) {

            this.getElementByXPath(SERVER_CHECKBOX).click();
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End disableLibraryServer method");

    }

    /**
     * Method to Create new Library service with inactive status.
    */
    public void disabledAndFillLibraryServerDetails(String SERVERNAME, ConfigDetails SERVERHOSTNAME, ConfigDetails USER,
            ConfigDetails PASSWORD, ConfigDetails PORT) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start disabledAndFillLibraryServerDetails method");

        ConfigLibrary Config = ConfigFactory.getLibraryConfigDetils(SERVERNAME, SERVERHOSTNAME, USER, PASSWORD, PORT);

        this.disableLibraryServer();
        this.getElementByXPath(NAME_INPUT).sendKeys(SERVERNAME);
        this.getElementByXPath(HOSTNAME_INPUT).sendKeys(Config.getServerHostName());
        this.getElementByXPath(USERNAME_INPUT).sendKeys(Config.getUser());
        this.getElementByXPath(USERPASS_INPUT).sendKeys(Config.getPassword());
        this.getElementByXPath(PORT_INPUT).sendKeys(Config.getPort());

        this.driver.sleep(3);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End disabledAndFillLibraryServerDetails method");

    }

    /**
     * Method to check Successfully created message.
     * @return boolean about if server created successfully or not.
    */
    public boolean isSuccessfullyCreatedMessageShown() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isSuccessfullyCreatedMessageShown method");

        boolean isShown = false;
        if (this.retryAndGetElementByXPath(SUSSESSFULLY_SAVED_MESSAGE)) {
            String message = this.getElementByXPath(SUSSESSFULLY_SAVED_MESSAGE).getText();
            if (message.equalsIgnoreCase("Configuration successfully saved.")) {
                isShown = true;
            }
        } else {
            assertTrue("SUSSESSFULLY_SAVED_MESSAGE is not shown", false);

        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isSuccessfullyCreatedMessageShown method");

        return isShown;

    }

    /**
     * Method to check the service.
     * @return boolean about if service is working fine or not
    */
    public boolean checkService() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkService method");

        boolean checkservice = false;
        this.getElementByXPath(CHECK_SERVICE).click();
        driver.sleep(5);
        String message = this.getElementByXPath(CHECK_SERVICE_MESSAGE).getText();
        if (message.contains("Library is working properly.")) {
            checkservice = true;
        }
        this.driver.sleep(5);
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkService method");

        return checkservice;

    }

    /**
     * Method to check the InvalidService service.
     * @return boolean about if service is working fine or not
    */
    public boolean checkInvalidService() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start checkService method");

        boolean checkInvalidservice = false;
        this.getElementByXPath(CHECK_SERVICE).click();
        driver.sleep(2);
        String message = this.getElementByXPath(CHECK_SERVICE_MESSAGE).getText();
        if (message.contains("Library is not working. Please, review your configuration.")) {
            checkInvalidservice = true;
        }
        this.driver.sleep(5);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End checkService method");

        return checkInvalidservice;

    }
}
