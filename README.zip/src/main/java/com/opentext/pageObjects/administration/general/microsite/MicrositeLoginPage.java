/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.general.microsite;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.advanceSearch.AdvanceSearchPage;
import com.opentext.pageObjects.containerAssets.ContainerAssetsPage;
import com.opentext.pageObjects.footer.FooterPage;
import com.opentext.pageObjects.sortBy.SortByPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Mavya Papishetty<mpapishe@opentext.com>
 */
public class MicrositeLoginPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(MicrositeLoginPage.class);

    /**
     * Components
     */

    private static AdvanceSearchPage advanceSearch;
    private static SortByPage sortBy;
    private static ContainerAssetsPage containerAssets;
    private static FooterPage footer;
    private static AdvanceSearchPage advanceSearchpage;

    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */

    private static final String TEXT = "text";

    private static final String EMAIL_INPUT = "emaiInput";

    private static final String PASS_INPUT = "passInput";

    private static final String LOGO_SINGIN_PAGE = "logoSignInPage";

    private static final String SIGNIN_BUTTON = "signInButton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public MicrositeLoginPage(EmergyaWebDriver driver) {
        super(driver);
        // TODO Auto-generated constructor stub
    }

    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(TEXT);
        this.waitForByXPath(EMAIL_INPUT);
        this.waitForByXPath(PASS_INPUT);
        this.waitForByXPath(LOGO_SINGIN_PAGE);
        this.waitForByXPath(SIGNIN_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");

    }

    @Override
    public boolean isReady() {
        boolean isReady = false;

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        if (this.isElementVisibleByXPath(TEXT) && this.isElementVisibleByXPath(EMAIL_INPUT)
                && this.isElementVisibleByXPath(PASS_INPUT) && this.isElementVisibleByXPath(LOGO_SINGIN_PAGE)
                && this.isElementVisibleByXPath(SIGNIN_BUTTON)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    public void micrositeLogin(String username, String Password) {

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start micrositeLogin method");
        this.driver.sleep(1);
        this.waitForByElement(this.getElementByXPath(EMAIL_INPUT));
        this.getElementByXPath(EMAIL_INPUT).sendKeys(username);
        this.driver.sleep(1);
        this.getElementByXPath(PASS_INPUT).sendKeys(Password);
        this.driver.sleep(1);

        this.getElementByXPath(SIGNIN_BUTTON).click();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End micrositeLogin method");

    }

}
