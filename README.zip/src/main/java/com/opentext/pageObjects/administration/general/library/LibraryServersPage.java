/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.general.library;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.GeneralSubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class LibraryServersPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(LibraryServersPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String BACK_BUTTON = "backButton";

    private final static String SERVERS_TAB = "serversTab";
    private final static String SERVICES_TAB = "servicesTab";

    private final static String ADD_SERVER = "addServer";
    private final static String SEARCH_INPUT = "searchInput";

    private final static String SERVER_NAME = "serverName";
    private final static String HOST_NAME = "hostName";
    private final static String PORT = "port";
    private final static String PROTOCOL = "protocol";
    private final static String SERVICES = "services";
    private final static String PROXY = "proxy";
    private final static String AVAILABILITY = "availability";
    private final static String EDIT_BUTTONS = "editButtons";
    private final static String DELETE_BUTTONS = "deleteButtons";
    private final static String MODAL_DELETE_BUTTON = "modaldeleteButton";
    private final static String SERVICES_SERVER_NAME = "sevicesservername";
    private final static String SERVICES_SERVER_NAME_OPTIONS = "sevicesservernameoptions";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public LibraryServersPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new GeneralSubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        for (int i = 0; i <= 5; i++) {

            if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                    && this.isElementVisibleByXPath(SERVERS_TAB) && this.isElementVisibleByXPath(SERVICES_TAB)
                    && this.isElementVisibleByXPath(ADD_SERVER) && this.isElementVisibleByXPath(SEARCH_INPUT)
                    && this.isElementVisibleByXPath(SERVER_NAME) && this.isElementVisibleByXPath(HOST_NAME)
                    && this.isElementVisibleByXPath(PORT) && this.isElementVisibleByXPath(PROTOCOL)
                    && this.isElementVisibleByXPath(SERVICES) && this.isElementVisibleByXPath(PROXY)
                    && this.isElementVisibleByXPath(AVAILABILITY) && this.isElementVisibleByXPath(EDIT_BUTTONS)
                    && this.isElementVisibleByXPath(DELETE_BUTTONS)) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * @return boolean about this PO is ready
     */
    public boolean serviceTabIsReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start serviceTabIsReady method");

        this.waitForByXPath(SERVICES_SERVER_NAME);
        this.waitUntilDisappearByXPath(SPINNER);

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(SERVICES_SERVER_NAME)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End serviceTabIsReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(SERVERS_TAB);
        this.waitForByXPath(SERVICES_TAB);

        this.waitForByXPath(ADD_SERVER);
        this.waitForByXPath(SEARCH_INPUT);

        this.waitForByXPath(SERVER_NAME);
        this.waitForByXPath(HOST_NAME);
        this.waitForByXPath(PORT);
        this.waitForByXPath(PROTOCOL);
        this.waitForByXPath(SERVICES);
        this.waitForByXPath(PROXY);
        this.waitForByXPath(AVAILABILITY);
        this.waitForByXPath(EDIT_BUTTONS);
        this.waitForByXPath(DELETE_BUTTONS);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate to the Create Library Server page.
     * @return {@link CreateAndEditLibraryServersPage} ready to work with.
     */
    public CreateAndEditLibraryServersPage goToAddServer() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goToAddServer method");

        this.getElementByXPath(ADD_SERVER).click();
        this.waitUntilDisappearByXPath(ADD_SERVER);
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(1);

        CreateAndEditLibraryServersPage createLibraryServerPage = new CreateAndEditLibraryServersPage(driver,
                this.getSectionsVisible());
        createLibraryServerPage.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goToAddServer method");

        return createLibraryServerPage;
    }

    /**
     * Method to navigate back to the Dashboard
     * @return {@link DashboardPage} ready to work with.
     */
    @Override
    public DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(BACK_BUTTON);
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new DashboardPage(driver, this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");

        return dashboard;
    }

    /**
     * Method to check library List has newly created server.
     * @return boolean about if server created successfully or not.
    */
    public boolean isNewlyCreatedServerShownInList(String serverName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start isNewlyCreatedServerShownInList method");

        boolean isShown = false;
        List<String> serversList = this.getList(SERVER_NAME);

        for (String servers : serversList) {

            if (servers.equalsIgnoreCase(serverName)) {

                isShown = true;

            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - End isNewlyCreatedServerShownInList method");

        return isShown;

    }

    /**
     * Method to edit existing server .
    */
    public void editExistingServer(String serverName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start editExistingServer method");

        List<String> serversList = this.getList(SERVER_NAME);
        int i = 0;
        for (String servers : serversList) {

            if (servers.equalsIgnoreCase(serverName)) {
                this.getElementsByXPath(EDIT_BUTTONS).get(i).click();
            }
            i++;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End editExistingServer method");

    }

    /**
     * Method to Delete all servers except enabled.
    */
    public void deleteAllDisabledServers() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteAllDisabledServers method");

        List<String> availabilityList = this.getList(AVAILABILITY);

        for (String servers : availabilityList) {

            if (servers.equalsIgnoreCase("Disabled")) {
                this.getElementsByXPath(DELETE_BUTTONS).get(availabilityList.indexOf(servers)).click();
                this.driver.sleep(2);
                this.getElementByXPath(MODAL_DELETE_BUTTON).click();
                this.waitUntilDisappearByXPath(MODAL_DELETE_BUTTON);
                this.waitUntilDisappearByXPath(SPINNER);

            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteAllDisabledServers method");

    }

    /**
     * Method to Delete specific server
    */
    public void deleteServer(String servername) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteServer method");

        List<String> serverlist = this.getList(SERVER_NAME);

        for (String server : serverlist) {

            if (server.equalsIgnoreCase(servername)) {
                this.getElementsByXPath(DELETE_BUTTONS).get(serverlist.indexOf(server)).click();
                this.driver.sleep(2);
                this.getElementByXPath(MODAL_DELETE_BUTTON).click();
                this.waitUntilDisappearByXPath(MODAL_DELETE_BUTTON);
                this.waitUntilDisappearByXPath(SPINNER);
                break;
            }

        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteServer method");

    }

    /**
     * Method to Click on Services Tab
    */
    public void goToServicesTab() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnServicesTab method");

        if (this.retryAndGetElementByXPath(SERVICES_TAB)) {
            this.getElementByXPath(SERVICES_TAB).click();
        } else {
            assertTrue("SaveInCollection component is not open.", false);

        }
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clickOnServicesTab method");

    }

    /**
     * Method to compare list
     * @return boolean
    */
    public boolean isServerNamesDropDownListMatchedWithActualServersList(List<String> actualServerList) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getServerNamesDropDownList method");

        boolean isMatched = false;

        List<String> serverlist = this.getList(SERVICES_SERVER_NAME_OPTIONS);

        isMatched = this.compareTwoLists(actualServerList, serverlist);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getServerNamesDropDownList method");
        return isMatched;

    }

    /**
     * Method to get list
     * @return list
    */
    public List<String> getServerList() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getServerNamesDropDownList method");

        List<String> serverlist = this.getList(SERVER_NAME);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getServerNamesDropDownList method");
        return serverlist;

    }

}
