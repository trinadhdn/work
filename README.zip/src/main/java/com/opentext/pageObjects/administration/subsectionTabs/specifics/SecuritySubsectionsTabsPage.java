/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.subsectionTabs.specifics;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.SectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.SubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Security subsections tabs.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class SecuritySubsectionsTabsPage extends SubsectionsTabsPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(SecuritySubsectionsTabsPage.class);

    /**
     * Components
     */
    // Not necessary.

    /**
     * Items keys selectors.
     */
    private final static String CONTENT_PERMISSION_MAPPINGS = "contentPermissionMappings";
    private final static String MANAGE_PERMISSIONS = "managePermissions";
    private final static String OTDS = "otds";
    private final static String AD = "activeDirectory";
    private final static String LDAP = "ldap";
    private final static String ROLE_CONFIG = "roleConfiguration";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of visible {@link SectionPage}.
     */
    public SecuritySubsectionsTabsPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = true;

        if (this.isKeyShown(CONTENT_PERMISSION_MAPPINGS)) {
            if (!this.isElementVisibleByXPath(CONTENT_PERMISSION_MAPPINGS, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(MANAGE_PERMISSIONS)) {
            if (!this.isElementVisibleByXPath(MANAGE_PERMISSIONS, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(OTDS)) {
            if (!this.isElementVisibleByXPath(OTDS, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(AD)) {
            if (!this.isElementVisibleByXPath(AD, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(LDAP)) {
            if (!this.isElementVisibleByXPath(LDAP, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(ROLE_CONFIG)) {
            if (!this.isElementVisibleByXPath(ROLE_CONFIG, 1)) {
                isReady = false;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        if (this.isKeyShown(CONTENT_PERMISSION_MAPPINGS)) {
            this.waitForByXPath(CONTENT_PERMISSION_MAPPINGS);
        }
        if (this.isKeyShown(MANAGE_PERMISSIONS)) {
            this.waitForByXPath(MANAGE_PERMISSIONS);
        }
        if (this.isKeyShown(OTDS)) {
            this.waitForByXPath(OTDS);
        }
        if (this.isKeyShown(AD)) {
            this.waitForByXPath(AD);
        }
        if (this.isKeyShown(LDAP)) {
            this.waitForByXPath(LDAP);
        }
        if (this.isKeyShown(ROLE_CONFIG)) {
            this.waitForByXPath(ROLE_CONFIG);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

}
