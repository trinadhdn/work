/**
 *
 * Copyright (c) 2017 Opentext.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Opentext.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.subsectionTabs.specifics;

import java.util.List;

import org.apache.log4j.Logger;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.SectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.SubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the General subsections tabs.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ViewsSubsectionsTabsPage extends SubsectionsTabsPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(ViewsSubsectionsTabsPage.class);

    /**
     * Components
     */
    // Not necessary.

    /**
     * Items keys selectors.
     */
    private String GENERAL_VIEWS = "generalViews";
    private String TEXTS = "texts";
    private String LANDING_PAGES = "landingPages";
    private String ASSET_DETAILS = "assetDetails";
    private String EXPORT_TEMPLATES = "exportTemplates";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of visible {@link SectionPage}.
     */
    public ViewsSubsectionsTabsPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = true;

        if (this.isKeyShown(GENERAL_VIEWS)) {
            if (!this.isElementVisibleByXPath(GENERAL_VIEWS, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(TEXTS)) {
            if (!this.isElementVisibleByXPath(TEXTS, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(LANDING_PAGES)) {
            if (!this.isElementVisibleByXPath(LANDING_PAGES, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(ASSET_DETAILS)) {
            if (!this.isElementVisibleByXPath(ASSET_DETAILS, 1)) {
                isReady = false;
            }
        }
        if (this.isKeyShown(EXPORT_TEMPLATES)) {
            if (!this.isElementVisibleByXPath(EXPORT_TEMPLATES, 1)) {
                isReady = false;
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        if (this.isKeyShown(GENERAL_VIEWS)) {
            this.waitForByXPath(GENERAL_VIEWS);
        }
        if (this.isKeyShown(TEXTS)) {
            this.waitForByXPath(TEXTS);
        }
        if (this.isKeyShown(LANDING_PAGES)) {
            this.waitForByXPath(LANDING_PAGES);
        }
        if (this.isKeyShown(ASSET_DETAILS)) {
            this.waitForByXPath(ASSET_DETAILS);
        }
        if (this.isKeyShown(EXPORT_TEMPLATES)) {
            this.waitForByXPath(EXPORT_TEMPLATES);
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

}
