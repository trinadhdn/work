/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.administration.security.mappingPermissions;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.dto.Section;
import com.opentext.pageObjects.administration.DashboardPage;
import com.opentext.pageObjects.administration.SubSectionPage;
import com.opentext.pageObjects.administration.subsectionTabs.specifics.SecuritySubsectionsTabsPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the list of Library Servers subsections.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class MappingPermissionsSettingsPage extends SubSectionPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(MappingPermissionsSettingsPage.class);

    /**
     * Components
     */
    // subsectionsTabs inherited from SubSectionPage

    /**
     * Items keys selectors.
     */
    private final static String PERMISSIONS = "permissions";
    private final static String DESCRIPTION = "description";
    private final static String SYSTEM_PERMISSIONS = "systemPermission";
    private final static String EDIT_BUTTON = "editButton";
    private final static String DELETE_BUTTON = "deleteButton";
    private final static String SUBMIT_PERMISSIONS_BUTTON = "submitPermissionsButton";
    private final static String ADD_NEW_PERMISSIONS_BUTTON = "addNewPermission";
    private final static String SEACRH_INPUT = "searchInput";
    private final static String EDIT_SUBMIT_PERMISSIONS_BUTTON = "editSubmitPermissionsButton";
    private final static String CUSTOM_PERMISSIONS_LIST = "customPermissionsList";

    private final static String PERMISSION_NAME = "permissionName";
    private final static String PERMISSION_DESC = "permissionDesc";
    private final static String EDIT_PERMISSION_NAME = "editPermissionName";
    private final static String EDIT_PERMISSION_DESC = "editPermissionDesc";
    private final static String CANCEL_BUTTON = "cancelbutton";
    private final static String BACK_BUTTON = "backbutton";
    private final static String MANAGE_PERMISSION = "managePermission";

    private final static String MODAL_OK = "modalConfirm";

    /**
     * Constructor method
     * @param driver selenium webdriver
     * @param list of {@link Section} visible.
     */
    public MappingPermissionsSettingsPage(EmergyaWebDriver driver, List<Section> sectionsVisible) {
        super(driver, sectionsVisible);
        subsectionsTabs = new SecuritySubsectionsTabsPage(driver, sectionsVisible);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady() && subsectionsTabs.isReady() && this.isElementVisibleByXPath(BACK_BUTTON)
                && this.isElementVisibleByXPath(PERMISSIONS) && this.isElementVisibleByXPath(DESCRIPTION)
                && this.isElementVisibleByXPath(SEACRH_INPUT)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();
        subsectionsTabs.waitForReady();

        this.waitForByXPath(BACK_BUTTON);

        this.waitForByXPath(PERMISSIONS);
        this.waitForByXPath(DESCRIPTION);

        this.waitForByXPath(SYSTEM_PERMISSIONS);
        this.waitForByXPath(EDIT_BUTTON);
        this.waitForByXPath(DELETE_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to navigate back to the MappingPermissions list page.
     * @return dashboard
     */

    public  DashboardPage goBack() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start goBack method");

        this.scrollTop();
        this.getElementByXPath(BACK_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

        DashboardPage dashboard = new  DashboardPage(driver,
                this.getSectionsVisible());
        dashboard.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End goBack method");
        return dashboard;

    }

    /**
     * Method to save the new/edited server.
     */
    public void clickOnSubmit() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.getElementByXPath(SUBMIT_PERMISSIONS_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(5);

    }

    /**
     * Method to save the new/edited server.
     */
    public void clickOnEditSubmit() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.getElementByXPath(EDIT_SUBMIT_PERMISSIONS_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);
        this.driver.sleep(5);
        this.getElementByXPath(MANAGE_PERMISSION).click();

    }

    /**
     * Method to CLick on new
     */
    public void clickOnNew() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clickOnSave method");

        this.scrollBottom();
        this.getElementByXPath(ADD_NEW_PERMISSIONS_BUTTON).click();
        this.waitUntilDisappearByXPath(SPINNER);

    }

    /**
     * Method to fill ManagePermissionsDetails 
    */
    public void fillMPDetails(String permission, String description) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName()
                + " - Start fillManagePermissionsDetails method");

        this.scrollBottom();
        // Fill details
        this.getElementByXPath(PERMISSION_NAME).sendKeys(permission);
        this.driver.sleep(1);
        this.getElementByXPath(PERMISSION_DESC).sendKeys(description);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End fillManagePermissionsDetails method");

    }

    /**
     * Method to Edit ManagePermissionsDetails 
    */
    public void editMPDetails(String permission, String description) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start editMPDetails method");

        // Fill details
        this.getElementByXPath(EDIT_PERMISSION_NAME).clear();
        this.getElementByXPath(EDIT_PERMISSION_NAME).sendKeys(permission);
        this.getElementByXPath(EDIT_PERMISSION_DESC).clear();
        this.getElementByXPath(EDIT_PERMISSION_DESC).sendKeys(description);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End editMPDetails method");

    }

    /**
     * Method to clear data .
    */
    public void clearDeatils() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start clearDeatils method");

        this.getElementByXPath(PERMISSION_NAME).clear();
        this.getElementByXPath(PERMISSION_DESC).clear();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End clearDeatils method");

    }

    /**
     * Method to edit data .
    */
    public void editPermissionDeatils(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start editPermissionDeatils method");

        this.getElementByXPath(MANAGE_PERMISSION).click();
        this.getElementByXPath(SEACRH_INPUT).sendKeys(name);

        this.getElementByXPath(EDIT_BUTTON).click();
        this.driver.sleep(2);
        this.waitUntilDisappearByXPath(SPINNER);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End editPermissionDeatils method");

    }

    /**
     * Method to check updated permission data .
    */
    public boolean isPermissionAndDescUpdated(String name, String desc) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isPermissionAndDescUpdated method");

        List<String> permissionsList = this.getPermissions();
        boolean isUpdated = false;

        for (String permission : permissionsList) {
            int i = permissionsList.indexOf(permission);
            if (permission.equalsIgnoreCase(name)) {
                String Updated_Desc = this.getElementsByXPath(DESCRIPTION).get(i).getText();
                log.info("[log-TestSet] " + Updated_Desc);

                if (Updated_Desc.equalsIgnoreCase(desc)) {
                    isUpdated = true;
                }
            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isPermissionAndDescUpdated method");
        return isUpdated;

    }

    /**
     * Method to delete data .
    */
    public void deletePermission(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deletePermission method");

        this.getElementByXPath(SEACRH_INPUT).sendKeys(name);
        this.driver.sleep(1);
        this.getElementByXPath(DELETE_BUTTON).click();
        this.driver.sleep(2);
        this.getElementByXPath(MODAL_OK).click();
        this.driver.sleep(2);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deletePermission method");

    }

    /**
     * Method to delete data .
    */
    public boolean isRecorddeleted(String name) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isRecorddeleted method");

        this.getElementByXPath(MANAGE_PERMISSION).click();

        List<String> permissionsList = this.getPermissions();
        boolean isShown = true;

        for (String permission : permissionsList) {

            if (permission.contains(name)) {

                isShown = false;
                break;

            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isRecorddeleted method");
        return isShown;

    }

    /**
     * Method to delete all custom permissions data .
    */
    public void deleteAllCustomPermission() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start deleteAllCustomPermission method");

        List<WebElement> syspermissions = this.getElementsByXPath(CUSTOM_PERMISSIONS_LIST);

        for (WebElement sysper : syspermissions) {
            List<WebElement> syspermissionslist = this.getElementsByXPath(CUSTOM_PERMISSIONS_LIST);

            int i = syspermissionslist.indexOf(sysper);

            if (sysper.getText().equalsIgnoreCase("No")) {

                this.getElementsByXPath(DELETE_BUTTON).get(i).click();
                this.driver.sleep(2);
                this.getElementByXPath(MODAL_OK).click();
                this.driver.sleep(3);

            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End deleteAllCustomPermission method");

    }

    /**
     * Method to get permissions list
     * @return list of permissions names 
    */
    public List<String> getPermissions() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getPermissions method");

        List<WebElement> permissionsList = this.getElementsByXPath(PERMISSIONS);
        List<String> list = new ArrayList<>();

        for (WebElement permissions : permissionsList) {
            list.add(permissions.getText());
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getPermissions method");
        return list;

    }

    /**
     * Method to 
     * @return boolean if particular Permission exits in list or not
     * @param permissionName
    */
    public boolean isPermissionExistsInList(String permissionName) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isPermissionExitsInList method");

        this.getElementByXPath(MANAGE_PERMISSION).click();

        List<String> permissionsList = this.getPermissions();
        boolean isShown = false;

        for (String permission : permissionsList) {

            if (permission.contains(permissionName)) {

                isShown = true;
                break;

            }
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isPermissionExitsInList method");
        return isShown;

    }
}
