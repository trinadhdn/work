/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.footer;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Footer page.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class FooterPage extends PCBasePage {

    /**
     * Items keys selectors.
     */
    private final static String BAR = "bar";
    private final static String LOCATION = "location";
    private final static String COPYRIGHT = "copyright";

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(FooterPage.class);

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public FooterPage(EmergyaWebDriver driver) {
        super(driver);
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        this.waitForReady();
        for (int i = 0; i <= 5; i++) {

            if (this.isElementVisibleByXPath(BAR) && this.isElementVisibleByXPath(LOCATION)
                    && this.isElementVisibleByXPath(COPYRIGHT)) {
                isReady = true;
                break;
            }
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(BAR);
        this.waitForByXPath(LOCATION);
        this.waitForByXPath(COPYRIGHT);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    // /**
    // * @return Title of the asset by action menu.
    // */
    // public String getTitle() {
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getTitle method");
    //
    // String title = this.getElementByXPath(TITLE).getText();
    //
    // log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getTitle method");
    //
    // return title;
    // }

}
