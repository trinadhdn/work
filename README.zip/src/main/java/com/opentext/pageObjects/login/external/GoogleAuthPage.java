/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.login.external;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.createAndEditionCollection.specific.CreateCollectionPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Authorization Google page.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class GoogleAuthPage extends ExternalLoginPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(GoogleAuthPage.class);

    /**
     * Items keys selectors.
     */
    private final static String SUBMIT_BUTTON = "submitButton";
    private final static String DENY_BUTTON = "denyButton";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public GoogleAuthPage(EmergyaWebDriver driver) {
        super(driver);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(SUBMIT_BUTTON, 1) && this.isElementVisibleByXPath(DENY_BUTTON, 1)) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(SUBMIT_BUTTON);
        this.waitForByXPath(DENY_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to perform a Login action:
     * 
     * @return HomePage
     */
    public CreateCollectionPage authorize() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start login method");

        this.getElementByXPath(SUBMIT_BUTTON).click();
        this.driver.switchToMainwindow();
        this.waitUntilDisappearByXPath(SUBMIT_BUTTON);

        CreateCollectionPage createCollection = new CreateCollectionPage(driver);
        createCollection.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End login method");

        return createCollection;
    }

}
