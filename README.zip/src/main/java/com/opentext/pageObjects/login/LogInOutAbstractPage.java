/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.login;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Login page.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public abstract class LogInOutAbstractPage extends PCBasePage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(LogInOutAbstractPage.class);

    /**
     * Items keys selectors.
     */
    private final static String LOGO = "logo";
    protected final static String SIGNIN_BUTTON = "signInButton";
    protected final static String INFO_MESSAGE = "infoMessage";

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public LogInOutAbstractPage(EmergyaWebDriver driver) {
        super(driver);
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (this.isElementVisibleByXPath(LOGO) && this.isElementVisibleByXPath(SIGNIN_BUTTON)) {
            isReady = true;
        }
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        this.waitForByXPath(LOGO);
        this.waitForByXPath(SIGNIN_BUTTON);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * @return if the Info message is visible.
     */
    public synchronized boolean isInfoMessageShown() {
        boolean shown = false;
        for (int i = 0; i <= 5; i++) {
            if (this.isElementVisibleByXPath(INFO_MESSAGE)) {
                shown = true;
                break;
            }
        }
        return shown;
    }

}
