/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.login;

import org.apache.log4j.Logger;

import com.opentext.pageObjects.search.SearchPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;
import com.opentext.utils.UserTest.UserDomain;
import com.opentext.utils.UserTest.UserType;

/**
 * This PO contains the methods to interact with the Login page.
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class LogoutPage extends LogInOutAbstractPage {

    /**
     * Logger class initialization.
     */
    static Logger log = Logger.getLogger(LogoutPage.class);

    /**
     * Items keys selectors.
     */
    // Nothing extra

    /**
     * Constructor method
     * @param driver selenium webdriver
     */
    public LogoutPage(EmergyaWebDriver driver) {
        super(driver);
        this.isReady();
    }

    /**
     * @return boolean about this PO is ready
     */
    @Override
    public synchronized boolean isReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

        boolean isReady = false;
        if (super.isReady()) {
            isReady = true;
        }

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

        return isReady;
    }

    /**
     * This method will wait until this PO is ready
     */
    @Override
    public synchronized void waitForReady() {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

        super.waitForReady();

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
    }

    /**
     * Method to perform a Login action from logout page:
     * 
     * @param userDomain to be used for login.
     * @param userType to be used for login.
     * @return HomePage {@link SearchPage} instance.
     */
    public synchronized SearchPage login(UserDomain userDomain, UserType userType) {
        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start login method");

        // To change from this logout page to the login page.
        this.getElementByXPath(SIGNIN_BUTTON).click();
        this.driver.sleep(1);

        LoginPage loginPage = new LoginPage(driver);
        loginPage.waitForReady();

        // Perform the loginPage.login() action.
        SearchPage searchPage = loginPage.login(userDomain, userType);

        log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End login method");

        return searchPage;
    }

}
