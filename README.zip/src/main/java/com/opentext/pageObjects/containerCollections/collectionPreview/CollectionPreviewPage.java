/**
 *
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.pageObjects.containerCollections.collectionPreview;

import static org.testng.AssertJUnit.assertTrue;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.opentext.pageObjects.PCBasePage;
import com.opentext.pageObjects.collection.CollectionPage;
import com.opentext.pageObjects.collection.types.GDriveCollectionPage;
import com.opentext.pageObjects.collection.types.StandardCollectionPage;
import com.opentext.selenium.drivers.EmergyaWebDriver;

/**
 * This PO contains the methods to interact with the Commons assets' previews.
 * 
 * @author Ivan Gomez <igomez@emergya.com>
 */
public class CollectionPreviewPage extends PCBasePage {

	/**
	 * Logger class initialization.
	 */
	static Logger log = Logger.getLogger(CollectionPreviewPage.class);

	/**
	 * Components
	 */
	public volatile int index;

	private volatile boolean isSelected;

	/**
	 * Items keys selectors.
	 */
	private final static String COLLECTIONS = "collections";

	private final static String IMAGE = "image";
	private final static String SYNC_ICON = "syncIcon";

	private final static String TITLE = "title";
	private final static String LAST_UPDATE = "lastUpdate";

	/**
	 * Constructor method
	 * 
	 * @param driver
	 *            selenium webdriver
	 */
	public CollectionPreviewPage(EmergyaWebDriver driver, int index) {
		super(driver);
		this.index = index;
		this.isSelected = this.isSelected();
		// this.isReady();
	}

	/**
	 * @return boolean about this PO is ready
	 */
	@Override
	public synchronized boolean isReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isReady method");

		this.waitUntilDisappearByXPath(SPINNER);

		boolean isReady = false;
		if (this.retryAndGetElementsByXPath(IMAGE) && this.retryAndGetElementsByXPath(TITLE)) {
			isReady = true;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isReady method");

		return isReady;
	}

	/**
	 * This method will wait until this PO is ready
	 */
	@Override
	public synchronized void waitForReady() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start waitForReady method");

		this.waitUntilDisappearByXPath(SPINNER);

		this.waitForByElement(this.getElementByXPath(IMAGE));
		this.waitForByElement(this.getElementByXPath(TITLE));
		this.waitForByElement(this.getElementByXPath(LAST_UPDATE));

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End waitForReady method");
	}

	/**
	 * @return the index of this asset.
	 */
	protected synchronized int getIndex() {
		return index;
	}

	/**
	 * @return Image element in the position index.
	 */
	public synchronized List<WebElement> getImage() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getImage method");

		List<WebElement> element = null;
		if (this.retryAndGetElementsByXPath(IMAGE)) {
			element = this.getElementsByXPath(IMAGE);
		} else {
			assertTrue("IMAGEs are not loaded.", false);

		}
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getImage method");

		return element;
	}

	/**
	 * @return SyncIcon element in the position index.
	 */
	public synchronized List<WebElement> getSyncIcon() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getSyncIcon method");

		List<WebElement> element = null;
		if (this.retryAndGetElementsByXPath(SYNC_ICON)) {
			element = this.getElementsByXPath(SYNC_ICON);
		} else {
			assertTrue("IMAGEs are not loaded.", false);
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getSyncIcon method");
		return element;
	}

	/**
	 * @return Title element in the position index.
	 */
	public synchronized List<WebElement> getTitle() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getTitle method");

		List<WebElement> element = null;
		if (this.retryAndGetElementsByXPath(TITLE)) {
			element = this.getElementsByXPath(TITLE);
		} else {
			assertTrue("IMAGEs are not loaded.", false);
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getTitle method");

		return element;
	}

	/**
	 * @return Last update date element in the position index.
	 */
	public synchronized List<WebElement> getLastUpdate() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getLastUpdate method");

		List<WebElement> element = null;
		for (int i = 0; i <= 5; i++) {
			if (this.getElementsByXPath(LAST_UPDATE).size() != 0) {
				element = this.getElementsByXPath(LAST_UPDATE);
				break;
			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getLastUpdate method");

		return element;
	}

	/**
	 * @return collection element in the position index.
	 */
	private synchronized WebElement getCollection() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCollection method");

		WebElement element = null;

		for (int i = 0; i <= 5; i++) {
			if (this.retryAndGetElementsByXPath(COLLECTIONS) && this.getElementsByXPath(COLLECTIONS).size() != 0) {
				element = this.getElementsByXPath(COLLECTIONS).get(this.getIndex());
				break;
			}
		}
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCollection method");

		if (element == null) {

			assertTrue("Collections are NOT loaded.", false);

		}
		return element;

	}

	/**
	 * @return Title text of this collection.
	 */
	public String getTitleText(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getTitleText method");

		String title = null;

		for (int i = 0; i <= 5; i++) {
			if (getTitle().size() != 0) {
				title = this.getTitle().get(index).getText().trim();
				break;
			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getTitleText method");

		return title;
	}

	/**
	 * @return if this collection is selected or not.
	 */
	private synchronized boolean isSelected() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start isSelected method");

		boolean isSelected = false;
		for (int i = 0; i <= 5; i++) {
			if (this.getCollection().getAttribute("class") != null) {
				if (this.getCollection().getAttribute("class").contains("selected")) {
					isSelected = true;
					break;
				}
			}
		}
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End isSelected method");

		return isSelected;
	}

	/**
	 * Method to Select this collection.
	 */
	public synchronized void selectCollection(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start selectCollection method");

		// If is not selected -> select
		if (!this.isSelected) {
			this.scrollTo(this.getImage().get(index));
			this.waitUntilDisappearByXPath(SPINNER);
			this.waitUntilElementClickableByXPath(this.getImage().get(index), 30);
			this.getImage().get(index).click();
			this.driver.sleep(4);

			this.isSelected = true;
			assertTrue("This collection should be selected.", this.isSelected());
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End selectCollection method");
	}

	/**
	 * Method to enter in this collection.
	 * 
	 * @return CollectionPage ready to work with.
	 */
	public synchronized CollectionPage enterCollection(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start enterCollection method");

		String ctype = null;
		for (int i = 0; i <= 5; i++) {
			if ((this.getImage().size() != 0) && (this.getCollectionType() != null)) {
				ctype = this.getCollectionType();
				this.waitUntilDisappearByXPath(SPINNER);
				this.scrollTo(this.getImage().get(index));
				this.getImage().get(index).click();
				this.driver.sleep(1);
				this.waitUntilDisappearByXPath(SPINNER);
				break;

			}
		}

		CollectionPage collection = null;
		switch (ctype) {
		case "Albums":
			collection = new StandardCollectionPage(driver);
			break;
		case "Personal":
			collection = new StandardCollectionPage(driver);
			break;
		case "Gdrive":
			collection = new GDriveCollectionPage(driver);
			break;
		case "MediaBin":
			collection = new StandardCollectionPage(driver); // TODO: change to
																// MB type
			break;
		default:
			collection = new StandardCollectionPage(driver);
			break;
		}
		collection.waitForReady();

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End enterCollection method");

		return collection;
	}

	/**
	 * @return the collection type.
	 */
	private String getCollectionType() {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getCollectionType method");

		String cType = null;
		for (int i = 0; i <= 5; i++) {

			if (this.getCollection().getAttribute("data-target") != null) {
				cType = this.getCollection().getAttribute("data-target").trim();
				break;
			}
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getCollectionType method");

		return cType;
	}

	/**
	 * @return src attribute of the cover of this collection.
	 */
	public synchronized String getImageSrc(int index) {
		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - Start getImageSrc method");

		String src = "";
		try {
			src = this.getImage().get(index).getAttribute("src").split("cacheKey=")[1].trim();
			// Options: <div pc-id="collection-image"
			// class="mbpc-thumbnail-image mbpc-collection-selector no-image">
			// src="http://ec2-52-207-254-89.compute-1.amazonaws.com:8000/library/sms/cache/cacheFile?cacheType=thumbCache&amp;expires=1485941898072&amp;cacheKey={591F1237-365A-41F2-91E3-39F0F106AAEB}"
		} catch (Exception e) {
			src = null;
		}

		log.info("[log-PageObjects] " + this.getClass().getSimpleName() + " - End getImageSrc method");

		return src;
	}

}
