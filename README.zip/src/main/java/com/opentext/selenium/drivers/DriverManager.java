package com.opentext.selenium.drivers;

public class DriverManager {
    private static EmergyaWebDriver driver =null ;  

    public static EmergyaWebDriver getDriver() {
        return driver;
    }

    public static void setWebDriver(EmergyaWebDriver driver) {
    	DriverManager.driver = driver;

    }

    public static void closeDriver(EmergyaWebDriver driver) {

        if (driver != null) {
            try {
                driver.manage().deleteAllCookies();
                driver.quit();
            } catch (Exception e) {

                e.printStackTrace();
            }

        }
      //  threadLocal.remove();

    }
}