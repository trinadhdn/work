/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils;

/**
 * Abstraction that represents an Configuration.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ConfigRMM {

    public enum ConfigRMMDetails {
        RMMURL;
    }

    /**
     * RMM url.
     */
    private String rmmurl;

    /**
     * Constructor.
     * @param url 
     */
    public ConfigRMM(String rmmurl) {
        this.setRmmUrl(rmmurl);

    }

    /**
     * @return the MB Location.
     */
    public String getRmmUrl() {
        return rmmurl;
    }

    /**
     * seturl url the url to set.
     */
    public void setRmmUrl(String rmmurl) {
        this.rmmurl = rmmurl;
    }

}
