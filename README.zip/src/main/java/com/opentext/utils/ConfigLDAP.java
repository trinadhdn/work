/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils;

/**
 * Abstraction that represents an Configuration.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ConfigLDAP {

    public enum ConfigLDAPDetails {
        LDAPSERVERNAME, INVALIDLDAPSERVERNAME, LDAPPORT, LDAPDN, LDAPDNPASSWORD, LDAPFIRSTNAME, LDAPLASTNAME, LDAPEMAIL, LDAPBASEDN, LDAPSEARCHBASEDN, LDAPSEARCHGROUPFIELDNAME;
    }

    /**
     * LDAP serverame Input.
     */
    private String ldapServerName;

    /**
    * LDAP portNumberInput .
    */
    private String ldapPortNumberInput;

    /**
    * LDAP DN .
    */
    private String ldapdn;

    /**
    * LDAP DN Password
    */
    private String ldapDNPassword;

    /**
    * LDAP FirstName
    */
    private String ldapFirstName;

    /**
     * LDAP LastName
     */
    private String ldapLastName;

    /**
    * LDAP Email
    */
    private String ldapEmail;

    /**
    * LDAP Base dn
    */
    private String ldapBaseDN;

    /**
    * LDAP ldapSearchBaseDN
    */
    private String ldapSearchBaseDN;

    /**
    * LDAP LDAPSEARCHGROUPFIELDNAME
    */
    private String ldapSearchGroupFieldName;

    /**
     * Constructor.
     * @param adServerName to be used
     * @param adPort to be used.
     * @param addn to be used.
     * @param adDNPassword to be used.
     * @param adDomain to be used.
     * @param adEmail to be used.
     * @param adBaseDN to be used.
     */
    public ConfigLDAP(String ldapServerName, String ldapPortNumberInput, String ldapdn, String ldapDNPassword,
            String ldapBaseDN, String ldapFirstName, String ldapLastName, String ldapEmail, String ldapSearchBaseDN,
            String ldapSearchGroupFieldName) {

        this.setLDAPServerName(ldapServerName);
        this.setLDAPPortNumberInput(ldapPortNumberInput);
        this.setLDAPdn(ldapdn);
        this.setLDAPDNPassword(ldapDNPassword);
        this.setLDAPBaseDN(ldapBaseDN);
        this.setLDAPEmail(ldapEmail);
        this.setLDAPFirstName(ldapFirstName);
        this.setLDAPLastName(ldapLastName);
        this.setLDAPSearchBaseDN(ldapSearchBaseDN);
        this.setLDAPSearchGroupFieldName(ldapSearchGroupFieldName);

    }

    /**
    * @return the check LDAPServerInput
    */
    public String getLDAPServerName() {
        return ldapServerName;
    }

    /**
    * @param check LDAPServerInput to set.
    */
    public void setLDAPServerName(String ldapServerName) {
        this.ldapServerName = ldapServerName;
    }

    /**
    * @return the check LDAPPortNumberInput
    */
    public String getLDAPPortNumberInput() {
        return ldapPortNumberInput;
    }

    /**
    * @param check LDAPPortNumberInput to set.
    */
    public void setLDAPPortNumberInput(String ldapPortNumberInput) {
        this.ldapPortNumberInput = ldapPortNumberInput;
    }

    /**
    * @return the check LDAPdn
    */
    public String getLDAPdn() {
        return ldapdn;
    }

    /**
    * @param check LDAPdn to set.
    */
    public void setLDAPdn(String ldapdn) {
        this.ldapdn = ldapdn;
    }

    /**
    * @return the check LDAPDNPassword
    */
    public String getLDAPDNPassword() {
        return ldapDNPassword;
    }

    /**
    * @param check LDAPDNPassword to set.
    */
    public void setLDAPDNPassword(String ldapDNPassword) {
        this.ldapDNPassword = ldapDNPassword;
    }

    /**
     * @return the check LDAPDomain
     */
    public String getLDAPBaseDN() {
        return ldapBaseDN;
    }

    /**
    * @param check LDAPDomain to set.
    */
    public void setLDAPBaseDN(String ldapBaseDN) {
        this.ldapBaseDN = ldapBaseDN;
    }

    /**
     * @return the check LDAPEmail
     */
    public String getLDAPEmail() {
        return ldapEmail;
    }

    /**
    * @param check LDAPEmail to set.
    */
    public void setLDAPEmail(String ldapEmail) {
        this.ldapEmail = ldapEmail;
    }

    /**
     * @return the check LDAPFirstName
     */
    public String getLDAPFirstName() {
        return ldapFirstName;
    }

    /**
    * @param check LDAPFirstName to set.
    */
    public void setLDAPFirstName(String ldapFirstName) {
        this.ldapFirstName = ldapFirstName;
    }

    /**
     * @return the check ldapLastName
     */
    public String getLDAPLastName() {
        return ldapLastName;
    }

    /**
    * @param check ldapLastName to set.
    */
    public void setLDAPLastName(String ldapLastName) {
        this.ldapLastName = ldapLastName;
    }

    /**
     * @return the check ldapSearchBaseDN
     */
    public String getLDAPSearchBaseDN() {
        return ldapSearchBaseDN;
    }

    /**
    * @param check ldapSearchBaseDN to set.
    */
    public void setLDAPSearchBaseDN(String ldapSearchBaseDN) {
        this.ldapSearchBaseDN = ldapSearchBaseDN;
    }

    /**
     * @return the check ldapSearchBaseDN
     */
    public String getLDAPSearchGroupFieldName() {
        return ldapSearchGroupFieldName;
    }

    /**
    * @param check ldapSearchBaseDN to set.
    */
    public void setLDAPSearchGroupFieldName(String ldapSearchGroupFieldName) {
        this.ldapSearchGroupFieldName = ldapSearchGroupFieldName;
    }

}
