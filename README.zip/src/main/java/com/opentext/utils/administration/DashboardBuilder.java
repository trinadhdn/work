/**
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils.administration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.opentext.dto.Section;
import com.opentext.dto.Subsection;
import com.opentext.dto.factories.SectionFactory;
import com.opentext.dto.factories.SubsectionFactory;

public abstract class DashboardBuilder {

    /**
     * It retrieves a list of {@link Section} instance depending on the provided the user roles.
     * @param userRoles user roles.
     * @return a list of {@link Section}.
     */
    public static List<Section> buildDashboard(List<String> userRoles) {
        List<Section> sections = new ArrayList<Section>();

        Map<String, List<Object>> mapPcids = XMLDasboardReader.getPcidMap(userRoles);

        for (String sectionName : mapPcids.keySet()) {

            // Build Section by SectionFactory.
            Section section = SectionFactory.buildSection(sectionName);

            List<Object> subsections = mapPcids.get(sectionName);
            Subsection subsection = null;

            for (Object subsectionElement : subsections) {
                if (subsectionElement instanceof Map) {
                    Map<String, List<String>> subsectionMap = (Map<String, List<String>>) subsectionElement;

                    for (String subsectionName : subsectionMap.keySet()) {

                        // Build Section by SubsectionFactory, using a Map.
                        subsection = SubsectionFactory
                                .buildSubsection(subsectionName, subsectionMap.get(subsectionName));
                    }

                } else {
                    // Build Section by SubsectionFactory, using a List.
                    subsection = SubsectionFactory.buildSubsection((String) subsectionElement);
                }
                section = SectionFactory.addSubsection(section, subsection);
            }

            sections.add(section);
        }

        return sections;
    }

}
