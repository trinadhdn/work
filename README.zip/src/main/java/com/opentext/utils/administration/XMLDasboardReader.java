/**
 * Copyright (c) 2014 Hewlett-Packard.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Hewlett-Packard, Inc.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils.administration;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class XMLDasboardReader {

    /**
     * Method to get the map of every section pc-id with every subsection pc-id, just the shown.
     * @param userRoles of the logged user.
     * @return map of every section pc-id with every subsection pc-id, just the shown.
     */
    public static Map<String, List<Object>> getPcidMap(List<String> userRoles) {

        Map<String, List<Object>> sectionsMap = new HashMap<String, List<Object>>();
        try {
            File fXmlFile = new File("src/main/resources/dashboard-config.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);

            doc.getDocumentElement().normalize();

            NodeList sectionNodes = doc.getElementsByTagName("section");
            // Iterating over the sections:
            for (int temp = 0; temp < sectionNodes.getLength(); temp++) {
                Node sectionNode = sectionNodes.item(temp);

                if (sectionNode.getNodeType() == Node.ELEMENT_NODE) {

                    Element eElement = (Element) sectionNode;
                    NodeList subsectionsBySectionNodes = eElement.getElementsByTagName("subsection");

                    List<Object> subsectionList = new ArrayList<>();

                    // Map<String, List<String>> subsectionPcidList = new HashMap<String, List<String>>();

                    // Iterating over the subsections to add the subsectionPcids:
                    for (int subsectionIndex = 0; subsectionIndex < subsectionsBySectionNodes
                            .getLength(); subsectionIndex++) {

                        Node subsectionNode = subsectionsBySectionNodes.item(subsectionIndex);
                        eElement = (Element) subsectionNode;

                        Boolean subsectionShown = false;
                        NodeList roleNodes = eElement.getElementsByTagName("role");
                        // Iterating over the roles to know if the subsection will be shown:
                        for (int roleIndex = 0; roleIndex < roleNodes.getLength() && !subsectionShown; roleIndex++) {
                            String role = roleNodes.item(roleIndex).getTextContent();
                            // If the user has any of the required roles:
                            if (userRoles.contains(role)) {
                                subsectionShown = true;
                            }
                        }
                        if (subsectionShown) {
                            // Get subsectiontab node.
                            NodeList tabNodes = eElement.getElementsByTagName("subsectiontab");
                            // Check if the subsection has any subsectiontab node.
                            if (tabNodes != null && tabNodes.getLength() > 0) {
                                // if it has subsectiontabs
                                Map<String, List<String>> subsectionMap = new HashMap<>();
                                List<String> tabNames = new ArrayList<>();

                                for (int tabNode = 0; tabNode < tabNodes.getLength(); tabNode++) {
                                    String tab = tabNodes.item(tabNode).getAttributes().getNamedItem("pc-id")
                                            .getNodeValue();
                                    tabNames.add(tab);
                                }
                                subsectionMap.put(subsectionNode.getAttributes().getNamedItem("pc-id")
                                        .getNodeValue(), tabNames);

                                subsectionList.add(subsectionMap);

                            } else {
                                subsectionList.add(subsectionNode.getAttributes().getNamedItem("pc-id").getNodeValue());
                            }
                        }
                    }

                    if (!subsectionList.isEmpty()) {
                        sectionsMap
                                .put(sectionNode.getAttributes().getNamedItem("pc-id").getNodeValue(), subsectionList);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return sectionsMap;
    }

}
