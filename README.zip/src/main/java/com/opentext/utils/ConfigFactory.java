/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */

package com.opentext.utils;

import org.apache.commons.lang3.StringUtils;
import org.testng.Assert;

import com.opentext.selenium.utils.PropertiesHandler;
import com.opentext.utils.ConfigAD.ConfigADDetails;
import com.opentext.utils.ConfigCloudStorage.ConfigCloudDetails;
import com.opentext.utils.ConfigEmail.ConfigEMailDetails;
import com.opentext.utils.ConfigLDAP.ConfigLDAPDetails;
import com.opentext.utils.ConfigLibrary.ConfigDetails;
import com.opentext.utils.ConfigMB.ConfigMBDetails;
import com.opentext.utils.ConfigOTDS.ConfigOTDSDetails;
import com.opentext.utils.ConfigRMM.ConfigRMMDetails;

/**
 * Abstraction that represents an Configuration.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */

public abstract class ConfigFactory {

    /**
     * It retrieves a {@link ServerConfig} instance depending on the provided Details.
     * It looks for an server details that matches in Confurations.properties file like:
     *      servername
     *      serverhostname
     *      user
     *      password
     *      port
     * @param servername to be retrieved.
     * @return a {@link ConfigLibrary}.
     */
    public static ConfigLibrary getLibraryConfigDetils(String SERVERNAME, ConfigDetails SERVERHOSTNAME,
            ConfigDetails USER, ConfigDetails PASSWORD, ConfigDetails PORT) {
        String servername = "NOT_DEFINED";
        String serverhostname = "NOT_DEFINED";
        String user = "NOT_DEFINED";
        String password = "NOT_DEFINED";
        String port = "NOT_DEFINED";
        // config details are mandatory
        if (SERVERNAME != null) {
            PropertiesHandler handler = PropertiesHandler.getInstance();
            handler.load("config.properties");
            // getting serverhostname
            if (StringUtils.isNotBlank(handler.get(SERVERHOSTNAME.name().toLowerCase() + ".library"))) {
                serverhostname = handler.get(SERVERHOSTNAME.name().toLowerCase() + ".library");
            } else {
                Assert.assertTrue(false, "There is no defined serverhostname for " + SERVERHOSTNAME.name());
            }
            // getting user
            if (StringUtils.isNotBlank(handler.get(USER.name().toLowerCase() + ".library"))) {
                user = handler.get(USER.name().toLowerCase() + ".library");
            } else {
                Assert.assertTrue(false, "There is no defined user for " + USER.name());
            }
            // getting password
            if (StringUtils.isNotBlank(handler.get(PASSWORD.name().toLowerCase() + ".library"))) {
                password = handler.get(PASSWORD.name().toLowerCase() + ".library");
            } else {
                Assert.assertTrue(false, "There is no defined password for " + PASSWORD.name());
            }
            // getting port
            if (StringUtils.isNotBlank(handler.get(PORT.name().toLowerCase() + ".library"))) {
                port = handler.get(PORT.name().toLowerCase() + ".library");
            } else {
                Assert.assertTrue(false, "There is no defined port for " + PORT.name());
            }
        }
        ConfigLibrary config = new ConfigLibrary(servername, serverhostname, user, password, port);
        return config;
    }

    /**
     * It retrieves a {@link ServerConfig} instance depending on the provided Details.
     * It looks for an server details that matches in Confurations.properties file like:
     *      mblocation
     *      mbuser
     *      mbpassword
     *      mbcategory
     *      @param MBLOCATION,MBUSER,MBPASSWORD,MBCATEGORY
     * @return a {@link mediabinconfig}.
     */
    public static ConfigMB getMBServiceConfigDetils(ConfigMBDetails MBLOCATION, ConfigMBDetails MBUSER,
            ConfigMBDetails MBPASSWORD, ConfigMBDetails MBCATEGORY, ConfigMBDetails NONMBUSER) {
        String mblocation = "NOT_DEFINED";
        String mbuser = "NOT_DEFINED";
        String mbpassword = "NOT_DEFINED";
        String mbcategory = "NOT_DEFINED";
        String nonmbuser = "NOT_DEFINED";

        // MB config details are mandatory
        if (MBLOCATION != null) {
            PropertiesHandler handler = PropertiesHandler.getInstance();
            handler.load("config.properties");
            // getting mblocation
            if (StringUtils.isNotBlank(handler.get(MBLOCATION.name().toLowerCase() + ".mbsevice"))) {
                mblocation = handler.get(MBLOCATION.name().toLowerCase() + ".mbsevice");
            } else {
                Assert.assertTrue(false, "There is no defined mblocation for " + MBLOCATION.name());
            }
            // getting mbuser
            if (StringUtils.isNotBlank(handler.get(MBUSER.name().toLowerCase() + ".mbsevice"))) {
                mbuser = handler.get(MBUSER.name().toLowerCase() + ".mbsevice");
            } else {
                Assert.assertTrue(false, "There is no defined user for " + MBUSER.name());
            }
            // getting mbpassword
            if (StringUtils.isNotBlank(handler.get(MBPASSWORD.name().toLowerCase() + ".mbsevice"))) {
                mbpassword = handler.get(MBPASSWORD.name().toLowerCase() + ".mbsevice");
            } else {
                Assert.assertTrue(false, "There is no defined password for " + MBPASSWORD.name());
            }
            // getting mbcategory
            if (StringUtils.isNotBlank(handler.get(MBCATEGORY.name().toLowerCase() + ".mbsevice"))) {
                mbcategory = handler.get(MBCATEGORY.name().toLowerCase() + ".mbsevice");
            } else {
                Assert.assertTrue(false, "There is no defined port for " + MBCATEGORY.name());
            }
        }
        ConfigMB mediabinconfig = new ConfigMB(mblocation, mbuser, mbpassword, mbcategory, nonmbuser);
        return mediabinconfig;
    }

    /**
     * It retrieves a {@link ServerConfig} instance depending on the provided Details.
     * It looks for an server details that matches in Confurations.properties file like:
     *      mailservername
     *      emailportinput
     *      emailuserNameInput
     *      emailuserPassInput
     *      senderEmailAccount
     *      senderName
     *      checkEmailTest
     *      @param MAILSERVERNAMEINPUT,PORTINPUT,EMAILUSERNAMEINPUT,EMAILUSERPASSINPUT,SENDEREMAILACCOUNT,SENDERNAME,CHECKEMAILTEST
     * @return a {@link emailconfig}.
     */
    public static ConfigEmail getEmailServiceConfigDetils(ConfigEMailDetails MAILSERVERNAMEINPUT,
            ConfigEMailDetails EMAILPORTINPUT, ConfigEMailDetails EMAILUSERNAMEINPUT,
            ConfigEMailDetails EMAILUSERPASSINPUT, ConfigEMailDetails SENDEREMAILACCOUNT, ConfigEMailDetails SENDERNAME,
            ConfigEMailDetails CHECKEMAILTEST) {
        String mailservernameinput = "NOT_DEFINED";
        String emailportinput = "NOT_DEFINED";
        String emailuserNameInput = "NOT_DEFINED";
        String emailuserPassInput = "NOT_DEFINED";
        String senderEmailAccount = "NOT_DEFINED";
        String senderName = "NOT_DEFINED";
        String checkEmailTest = "NOT_DEFINED";

        // Email config details are mandatory
        if (MAILSERVERNAMEINPUT != null) {
            PropertiesHandler handler = PropertiesHandler.getInstance();
            handler.load("config.properties");
            // getting MAILSERVERNAMEINPUT
            if (StringUtils.isNotBlank(handler.get(MAILSERVERNAMEINPUT.name().toLowerCase() + ".emailconfig"))) {
                mailservernameinput = handler.get(MAILSERVERNAMEINPUT.name().toLowerCase() + ".emailconfig");
            } else {
                Assert.assertTrue(false, "There is no defined emailconfig for " + MAILSERVERNAMEINPUT.name());
            }
            // getting portinput
            if (StringUtils.isNotBlank(handler.get(EMAILPORTINPUT.name().toLowerCase() + ".emailconfig"))) {
                emailportinput = handler.get(EMAILPORTINPUT.name().toLowerCase() + ".emailconfig");
            } else {
                Assert.assertTrue(false, "There is no defined port for " + EMAILPORTINPUT.name());
            }
            // getting emailuserNameInput
            if (StringUtils.isNotBlank(handler.get(EMAILUSERNAMEINPUT.name().toLowerCase() + ".emailconfig"))) {
                emailuserNameInput = handler.get(EMAILUSERNAMEINPUT.name().toLowerCase() + ".emailconfig");
            } else {
                Assert.assertTrue(false, "There is no defined User for " + EMAILUSERNAMEINPUT.name());
            }
            // getting emailuserPassInput
            if (StringUtils.isNotBlank(handler.get(EMAILUSERPASSINPUT.name().toLowerCase() + ".emailconfig"))) {
                emailuserPassInput = handler.get(EMAILUSERPASSINPUT.name().toLowerCase() + ".emailconfig");
            } else {
                Assert.assertTrue(false, "There is no defined password for " + EMAILUSERPASSINPUT.name());
            }
            // getting senderEmailAccount
            if (StringUtils.isNotBlank(handler.get(SENDEREMAILACCOUNT.name().toLowerCase() + ".emailconfig"))) {
                senderEmailAccount = handler.get(SENDEREMAILACCOUNT.name().toLowerCase() + ".emailconfig");
            } else {
                Assert.assertTrue(false, "There is no defined Email account for " + SENDEREMAILACCOUNT.name());
            }
            // getting senderName
            if (StringUtils.isNotBlank(handler.get(SENDERNAME.name().toLowerCase() + ".emailconfig"))) {
                senderName = handler.get(SENDERNAME.name().toLowerCase() + ".emailconfig");
            } else {
                Assert.assertTrue(false, "There is no defined Sender Name for " + SENDEREMAILACCOUNT.name());
            }
            // getting checkEmailTest
            if (StringUtils.isNotBlank(handler.get(CHECKEMAILTEST.name().toLowerCase() + ".emailconfig"))) {
                checkEmailTest = handler.get(CHECKEMAILTEST.name().toLowerCase() + ".emailconfig");
            } else {
                Assert.assertTrue(false, "There is no defined Check Email Test for " + CHECKEMAILTEST.name());
            }
            // getting checkInvalidEmailTest
            if (StringUtils.isNotBlank(handler.get(CHECKEMAILTEST.name().toLowerCase() + ".emailconfig"))) {
                checkEmailTest = handler.get(CHECKEMAILTEST.name().toLowerCase() + ".emailconfig");
            } else {
                Assert.assertTrue(false, "There is no defined Check Email Test for " + CHECKEMAILTEST.name());
            }
        }
        ConfigEmail emailconfig = new ConfigEmail(mailservernameinput, emailportinput, emailuserNameInput,
                emailuserPassInput, senderEmailAccount, senderName, checkEmailTest);
        return emailconfig;
    }

    /**
     * It retrieves a {@link CloudConfig} instance depending on the provided Details.
     * It looks for an RMM details that matches in Confurations.properties file like:
     *      URL
     * @param CLIENTID and SECRETID to be retrieved.
     * @return a {@link cloudconfig}.
     */
    public static ConfigCloudStorage getCloudConfig(ConfigCloudDetails CLIENTID, ConfigCloudDetails SECRETID) {
        String clientid = "NOT_DEFINED";
        String secretid = "NOT_DEFINED";

        // RMM details are mandatory
        if (CLIENTID != null) {
            PropertiesHandler handler = PropertiesHandler.getInstance();
            handler.load("config.properties");
            // getting CLIENTID
            if (StringUtils.isNotBlank(handler.get(CLIENTID.name().toLowerCase() + ".cloudconfig"))) {
                clientid = handler.get(CLIENTID.name().toLowerCase() + ".cloudconfig");
            } else {
                Assert.assertTrue(false, "ClientID is not available  " + CLIENTID.name());
            }
            // getting SECRETID
            if (StringUtils.isNotBlank(handler.get(SECRETID.name().toLowerCase() + ".cloudconfig"))) {
                secretid = handler.get(SECRETID.name().toLowerCase() + ".cloudconfig");
            } else {
                Assert.assertTrue(false, "Secretid is not available  " + SECRETID.name());
            }

        }
        ConfigCloudStorage cloudconfig = new ConfigCloudStorage(clientid, secretid);
        return cloudconfig;
    }

    /**
     * It retrieves a {@link ServerConfig} instance depending on the provided Details.
     * It looks for an server details that matches in Confurations.properties file like:
     *      adServerInput
     *      adPortNumberInput
     *      addn
     *      adDNPassword
     *      adDomain
     *      adEmail
     *      adBaseDN
     *      @param ADSERVERNAME,ADPORT,ADDN,ADDNPASSWORD,ADDOMAIN,ADEMAIL,ADBASEDN
     * @return a {@link adsettings}.
     */
    public static ConfigAD getADConfigDetils(ConfigADDetails ADSERVERNAME, ConfigADDetails ADPORT, ConfigADDetails ADDN,
            ConfigADDetails ADDNPASSWORD, ConfigADDetails ADDOMAIN, ConfigADDetails ADEMAIL, ConfigADDetails ADBASEDN) {
        String adServerName = "NOT_DEFINED";
        String adPort = "NOT_DEFINED";
        String addn = "NOT_DEFINED";
        String adDNPassword = "NOT_DEFINED";
        String adDomain = "NOT_DEFINED";
        String adEmail = "NOT_DEFINED";
        String adBaseDN = "NOT_DEFINED";

        // AD config details are mandatory
        if (ADSERVERNAME != null) {
            PropertiesHandler handler = PropertiesHandler.getInstance();
            handler.load("config.properties");
            // getting ADSERVERNAME
            if (StringUtils.isNotBlank(handler.get(ADSERVERNAME.name().toLowerCase() + ".adconfig"))) {
                adServerName = handler.get(ADSERVERNAME.name().toLowerCase() + ".adconfig");
            } else {
                Assert.assertTrue(false, "There is no defined adconfig for " + ADSERVERNAME.name());
            }
            // getting ADPORT
            if (StringUtils.isNotBlank(handler.get(ADPORT.name().toLowerCase() + ".adconfig"))) {
                adPort = handler.get(ADPORT.name().toLowerCase() + ".adconfig");
            } else {
                Assert.assertTrue(false, "There is no defined adconfig for " + ADPORT.name());
            }
            // getting ADDN
            if (StringUtils.isNotBlank(handler.get(ADDN.name().toLowerCase() + ".adconfig"))) {
                addn = handler.get(ADDN.name().toLowerCase() + ".adconfig");
            } else {
                Assert.assertTrue(false, "There is no defined adconfig for " + ADDN.name());
            }
            // getting ADDNPASSWORD
            if (StringUtils.isNotBlank(handler.get(ADDNPASSWORD.name().toLowerCase() + ".adconfig"))) {
                adDNPassword = handler.get(ADDNPASSWORD.name().toLowerCase() + ".adconfig");
            } else {
                Assert.assertTrue(false, "There is no defined adconfig for " + ADDNPASSWORD.name());
            }
            // getting ADDOMAIN
            if (StringUtils.isNotBlank(handler.get(ADDOMAIN.name().toLowerCase() + ".adconfig"))) {
                adDomain = handler.get(ADDOMAIN.name().toLowerCase() + ".adconfig");
            } else {
                Assert.assertTrue(false, "There is no defined adconfig for " + ADDOMAIN.name());
            }
            // getting senderName
            if (StringUtils.isNotBlank(handler.get(ADEMAIL.name().toLowerCase() + ".adconfig"))) {
                adEmail = handler.get(ADEMAIL.name().toLowerCase() + ".adconfig");
            } else {
                Assert.assertTrue(false, "There is no defined adconfig for " + ADEMAIL.name());
            }
            // getting checkEmailTest
            if (StringUtils.isNotBlank(handler.get(ADBASEDN.name().toLowerCase() + ".adconfig"))) {
                adBaseDN = handler.get(ADBASEDN.name().toLowerCase() + ".adconfig");
            } else {
                Assert.assertTrue(false, "There is no defined adconfig for " + ADBASEDN.name());

            }
        }
        ConfigAD adsettings = new ConfigAD(adServerName, adPort, addn, adDNPassword, adDomain, adEmail, adBaseDN);
        return adsettings;

    }

    /**
     * It retrieves a {@link LdapServerConfig} instance depending on the provided Details.
     * It looks for an server details that matches in Confurations.properties file like:
     *      @param LDAPSERVERNAME,LDAPDN,LDAPDNPASSWORD,LDAPFIRSTNAME,LDAPLASTNAME,LDAPEMAIL,LDAPBASEDN,LDAPSEARCHBASEDN,LDAPSEARCHGROUPFIELDNAME
     * @return a {@link ldapSettings}.
     */
    public static ConfigLDAP getLDAPConfigDetils(ConfigLDAPDetails LDAPSERVERNAME, ConfigLDAPDetails LDAPPORT,
            ConfigLDAPDetails LDAPDN, ConfigLDAPDetails LDAPDNPASSWORD, ConfigLDAPDetails LDAPFIRSTNAME,
            ConfigLDAPDetails LDAPLASTNAME, ConfigLDAPDetails LDAPEMAIL, ConfigLDAPDetails LDAPBASEDN,
            ConfigLDAPDetails LDAPSEARCHBASEDN, ConfigLDAPDetails LDAPSEARCHGROUPFIELDNAME) {
        String ldapServerName = "NOT_DEFINED";
        String ldapPortNumberInput = "NOT_DEFINED";
        String ldapdn = "NOT_DEFINED";
        String ldapDNPassword = "NOT_DEFINED";
        String ldapFirstName = "NOT_DEFINED";
        String ldapLastName = "NOT_DEFINED";
        String ldapEmail = "NOT_DEFINED";
        String ldapBaseDN = "NOT_DEFINED";
        String ldapSearchBaseDN = "NOT_DEFINED";
        String ldapSearchGroupFieldName = "NOT_DEFINED";

        // LDAPSERVERNAMEs are mandatory
        if (LDAPSERVERNAME != null) {
            PropertiesHandler handler = PropertiesHandler.getInstance();
            handler.load("config.properties");
            // getting LDAPSERVERNAME
            if (StringUtils.isNotBlank(handler.get(LDAPSERVERNAME.name().toLowerCase() + ".ldapconfig"))) {
                ldapServerName = handler.get(LDAPSERVERNAME.name().toLowerCase() + ".ldapconfig");
            } else {
                Assert.assertTrue(false, "There is no defined ldapconfig for " + LDAPSERVERNAME.name());
            }
            // getting LDAPPORT
            if (StringUtils.isNotBlank(handler.get(LDAPPORT.name().toLowerCase() + ".ldapconfig"))) {
                ldapPortNumberInput = handler.get(LDAPPORT.name().toLowerCase() + ".ldapconfig");
            } else {
                Assert.assertTrue(false, "There is no defined ldapconfig for " + LDAPPORT.name());
            }
            // getting LDAPDN
            if (StringUtils.isNotBlank(handler.get(LDAPDN.name().toLowerCase() + ".ldapconfig"))) {
                ldapdn = handler.get(LDAPDN.name().toLowerCase() + ".ldapconfig");
            } else {
                Assert.assertTrue(false, "There is no defined ldapconfig for " + LDAPDN.name());
            }
            // getting LDAPDNPASSWORD
            if (StringUtils.isNotBlank(handler.get(LDAPDNPASSWORD.name().toLowerCase() + ".ldapconfig"))) {
                ldapDNPassword = handler.get(LDAPDNPASSWORD.name().toLowerCase() + ".ldapconfig");
            } else {
                Assert.assertTrue(false, "There is no defined ldapconfig for " + LDAPDNPASSWORD.name());
            }
            // getting LDAPFIRSTNAME
            if (StringUtils.isNotBlank(handler.get(LDAPFIRSTNAME.name().toLowerCase() + ".ldapconfig"))) {
                ldapFirstName = handler.get(LDAPFIRSTNAME.name().toLowerCase() + ".ldapconfig");
            } else {
                Assert.assertTrue(false, "There is no defined ldapconfig for " + LDAPFIRSTNAME.name());
            }
            // getting LDAPLASTNAME
            if (StringUtils.isNotBlank(handler.get(LDAPLASTNAME.name().toLowerCase() + ".ldapconfig"))) {
                ldapLastName = handler.get(LDAPLASTNAME.name().toLowerCase() + ".ldapconfig");
            } else {
                Assert.assertTrue(false, "There is no defined ldapconfig for " + LDAPLASTNAME.name());
            }
            // getting LDAPEMAIL
            if (StringUtils.isNotBlank(handler.get(LDAPEMAIL.name().toLowerCase() + ".ldapconfig"))) {
                ldapEmail = handler.get(LDAPEMAIL.name().toLowerCase() + ".ldapconfig");
            } else {
                Assert.assertTrue(false, "There is no defined ldapconfig for " + LDAPEMAIL.name());
            }
            // getting LDAPBASEDN
            if (StringUtils.isNotBlank(handler.get(LDAPBASEDN.name().toLowerCase() + ".ldapconfig"))) {
                ldapBaseDN = handler.get(LDAPBASEDN.name().toLowerCase() + ".ldapconfig");
            } else {
                Assert.assertTrue(false, "There is no defined ldapconfig for " + LDAPBASEDN.name());

            }
            // getting LDAPSEARCHBASEDN
            if (StringUtils.isNotBlank(handler.get(LDAPSEARCHBASEDN.name().toLowerCase() + ".ldapconfig"))) {
                ldapSearchBaseDN = handler.get(LDAPSEARCHBASEDN.name().toLowerCase() + ".ldapconfig");
            } else {
                Assert.assertTrue(false, "There is no defined ldapconfig for " + LDAPSEARCHBASEDN.name());

            }
            // getting LDAPSEARCHGROUPFIELDNAME
            if (StringUtils.isNotBlank(handler.get(LDAPSEARCHGROUPFIELDNAME.name().toLowerCase() + ".ldapconfig"))) {
                ldapSearchGroupFieldName = handler.get(LDAPSEARCHGROUPFIELDNAME.name().toLowerCase() + ".ldapconfig");
            } else {
                Assert.assertTrue(false, "There is no defined ldapconfig for " + LDAPSEARCHGROUPFIELDNAME.name());

            }
        }
        ConfigLDAP ldapSettings = new ConfigLDAP(ldapServerName, ldapPortNumberInput, ldapdn, ldapDNPassword,
                ldapBaseDN, ldapFirstName, ldapLastName, ldapEmail, ldapSearchBaseDN, ldapSearchGroupFieldName);
        return ldapSettings;

    }

    /**
     * It retrieves a {@link LdapServerConfig} instance depending on the provided Details.
     * It looks for an server details that matches in Confurations.properties file like:
     *      @param LDAPSERVERNAME,LDAPDN,LDAPDNPASSWORD,LDAPFIRSTNAME,LDAPLASTNAME,LDAPEMAIL,LDAPBASEDN,LDAPSEARCHBASEDN,LDAPSEARCHGROUPFIELDNAME
     * @return a {@link ldapSettings}.
     */
    public static ConfigOTDS getOTDSConfigDetils(ConfigOTDSDetails OTDSSERVERNAME, ConfigOTDSDetails OTDSPORT,
            ConfigOTDSDetails OTDSDN, ConfigOTDSDetails OTDSDNPASSWORD, ConfigOTDSDetails OTDSRESOURCEIDENTIFIER,
            ConfigOTDSDetails OTDSDOMAINNAME, ConfigOTDSDetails OTDSFIRSTNAME, ConfigOTDSDetails OTDSLASTNAME,
            ConfigOTDSDetails OTDSEMAIL, ConfigOTDSDetails OTDSSEARCHGROUPFIELDNAME) {
        String otdsServerName = "NOT_DEFINED";
        String otdsPortNumberInput = "NOT_DEFINED";
        String otdsdn = "NOT_DEFINED";
        String otdsDNPassword = "NOT_DEFINED";
        String otdsResourceIdentifier = "NOT_DEFINED";
        String otdsEmail = "NOT_DEFINED";
        String otdsDomainName = "NOT_DEFINED";
        String otdsFirstName = "NOT_DEFINED";
        String otdsLastName = "NOT_DEFINED";
        String otdsSearchGroupFieldName = "NOT_DEFINED";

        // LDAPSERVERNAMEs are mandatory
        if (OTDSSERVERNAME != null) {
            PropertiesHandler handler = PropertiesHandler.getInstance();
            handler.load("config.properties");
            // getting LDAPSERVERNAME
            if (StringUtils.isNotBlank(handler.get(OTDSSERVERNAME.name().toLowerCase() + ".otdsconfig"))) {
                otdsServerName = handler.get(OTDSSERVERNAME.name().toLowerCase() + ".otdsconfig");
            } else {
                Assert.assertTrue(false, "There is no defined otdsconfig for " + OTDSSERVERNAME.name());
            }
            // getting LDAPPORT
            if (StringUtils.isNotBlank(handler.get(OTDSPORT.name().toLowerCase() + ".otdsconfig"))) {
                otdsPortNumberInput = handler.get(OTDSPORT.name().toLowerCase() + ".otdsconfig");
            } else {
                Assert.assertTrue(false, "There is no defined otdsconfig for " + OTDSPORT.name());
            }
            // getting LDAPDN
            if (StringUtils.isNotBlank(handler.get(OTDSDN.name().toLowerCase() + ".otdsconfig"))) {
                otdsdn = handler.get(OTDSDN.name().toLowerCase() + ".otdsconfig");
            } else {
                Assert.assertTrue(false, "There is no defined otdsconfig for " + OTDSDN.name());
            }
            // getting LDAPDNPASSWORD
            if (StringUtils.isNotBlank(handler.get(OTDSDNPASSWORD.name().toLowerCase() + ".otdsconfig"))) {
                otdsDNPassword = handler.get(OTDSDNPASSWORD.name().toLowerCase() + ".otdsconfig");
            } else {
                Assert.assertTrue(false, "There is no defined otdsconfig for " + OTDSDNPASSWORD.name());
            }
            // getting LDAPFIRSTNAME
            if (StringUtils.isNotBlank(handler.get(OTDSRESOURCEIDENTIFIER.name().toLowerCase() + ".otdsconfig"))) {
                otdsResourceIdentifier = handler.get(OTDSRESOURCEIDENTIFIER.name().toLowerCase() + ".otdsconfig");
            } else {
                Assert.assertTrue(false, "There is no defined otdsconfig for " + OTDSRESOURCEIDENTIFIER.name());
            }
            // getting LDAPLASTNAME
            if (StringUtils.isNotBlank(handler.get(OTDSDOMAINNAME.name().toLowerCase() + ".otdsconfig"))) {
                otdsDomainName = handler.get(OTDSDOMAINNAME.name().toLowerCase() + ".otdsconfig");
            } else {
                Assert.assertTrue(false, "There is no defined otdsconfig for " + OTDSDOMAINNAME.name());
            }
            // getting LDAPEMAIL
            if (StringUtils.isNotBlank(handler.get(OTDSEMAIL.name().toLowerCase() + ".otdsconfig"))) {
                otdsEmail = handler.get(OTDSEMAIL.name().toLowerCase() + ".otdsconfig");
            } else {
                Assert.assertTrue(false, "There is no defined otdsconfig for " + OTDSEMAIL.name());
            }
            // getting LDAPBASEDN
            if (StringUtils.isNotBlank(handler.get(OTDSFIRSTNAME.name().toLowerCase() + ".otdsconfig"))) {
                otdsFirstName = handler.get(OTDSFIRSTNAME.name().toLowerCase() + ".otdsconfig");
            } else {
                Assert.assertTrue(false, "There is no defined otdsconfig for " + OTDSFIRSTNAME.name());

            }
            // getting LDAPSEARCHBASEDN
            if (StringUtils.isNotBlank(handler.get(OTDSLASTNAME.name().toLowerCase() + ".otdsconfig"))) {
                otdsLastName = handler.get(OTDSLASTNAME.name().toLowerCase() + ".otdsconfig");
            } else {
                Assert.assertTrue(false, "There is no defined otdsconfig for " + OTDSLASTNAME.name());

            }
            // getting LDAPSEARCHGROUPFIELDNAME
            if (StringUtils.isNotBlank(handler.get(OTDSSEARCHGROUPFIELDNAME.name().toLowerCase() + ".otdsconfig"))) {
                otdsSearchGroupFieldName = handler.get(OTDSSEARCHGROUPFIELDNAME.name().toLowerCase() + ".otdsconfig");
            } else {
                Assert.assertTrue(false, "There is no defined otdsconfig for " + OTDSSEARCHGROUPFIELDNAME.name());

            }
        }
        ConfigOTDS otdsSettings = new ConfigOTDS(otdsServerName, otdsPortNumberInput, otdsdn, otdsDNPassword,
                otdsResourceIdentifier, otdsDomainName, otdsFirstName, otdsLastName, otdsEmail,
                otdsSearchGroupFieldName);
        return otdsSettings;

    }

    /**
     * It retrieves a {@link RMMConfig} instance depending on the provided Details.
     * It looks for an RMM details that matches in Confurations.properties file like:
     *      URL
     * @param RMMURL to be retrieved.
     * @return a {@link rmmconfig}.
     */
    public static ConfigRMM getRmmURL(ConfigRMMDetails RMMURL) {
        String rmmurl = "NOT_DEFINED";

        // RMM details are mandatory
        if (RMMURL != null) {
            PropertiesHandler handler = PropertiesHandler.getInstance();
            handler.load("config.properties");
            // getting serverhostname
            if (StringUtils.isNotBlank(handler.get(RMMURL.name().toLowerCase() + ".rmm"))) {
                rmmurl = handler.get(RMMURL.name().toLowerCase() + ".rmm");
            } else {
                Assert.assertTrue(false, "There is NOT working URL for " + RMMURL.name());
            }

        }
        ConfigRMM rmmconfig = new ConfigRMM(rmmurl);
        return rmmconfig;
    }

}
