/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils;

/**
 * Abstraction that represents an Configuration.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ConfigOTDS {

    public enum ConfigOTDSDetails {
        OTDSSERVERNAME, INVALIDOTDSSERVERNAME, OTDSPORT, OTDSDN, OTDSDNPASSWORD, OTDSRESOURCEIDENTIFIER, OTDSDOMAINNAME, OTDSFIRSTNAME, OTDSLASTNAME, OTDSEMAIL, OTDSSEARCHGROUPFIELDNAME;
    }

    /**
     * otds serverame Input.
     */
    private String otdsServerName;

    /**
    * otds portNumberInput .
    */
    private String otdsPortNumberInput;

    /**
    * otds DN .
    */
    private String otdsdn;

    /**
    * otds DN Password
    */
    private String otdsDNPassword;

    /**
     * otdsResourceIdentifier
     */
    private String otdsResourceIdentifier;

    /**
     * otds Domain Name
     */
    private String otdsDomainName;

    /**
    * otds FirstName
    */
    private String otdsFirstName;

    /**
     * otds LastName
     */
    private String otdsLastName;

    /**
    * otds Email
    */
    private String otdsEmail;

    /**
    * otds otdsSEARCHGROUPFIELDNAME
    */
    private String otdsSearchGroupFieldName;

    /**
     * Constructor.
     * @param adServerName to be used
     * @param adPort to be used.
     * @param addn to be used.
     * @param adDNPassword to be used.
     * @param adDomain to be used.
     * @param adEmail to be used.
     * @param adBaseDN to be used.
     */
    public ConfigOTDS(String otdsServerName, String otdsPortNumberInput, String otdsdn, String otdsDNPassword,
            String otdsResourceIdentifier, String otdsDomainName, String otdsFirstName, String otdsLastName,
            String otdsEmail, String otdsSearchGroupFieldName) {

        this.setOTDSServerName(otdsServerName);
        this.setOTDSPortNumberInput(otdsPortNumberInput);
        this.setOTDSdn(otdsdn);
        this.setOTDSDNPassword(otdsDNPassword);
        this.setOTDSResourceIdentifier(otdsResourceIdentifier);
        this.setOTDSEmail(otdsEmail);
        this.setOTDSDomainName(otdsDomainName);
        this.setOTDSFirstName(otdsFirstName);
        this.setOTDSLastName(otdsLastName);
        this.setOTDSSearchGroupFieldName(otdsSearchGroupFieldName);

    }

    /**
    * @return the check otdsServerInput
    */
    public String getOTDSServerName() {
        return otdsServerName;
    }

    /**
    * @param check otdsServerInput to set.
    */
    public void setOTDSServerName(String otdsServerName) {
        this.otdsServerName = otdsServerName;
    }

    /**
    * @return the check otdsPortNumberInput
    */
    public String getOTDSPortNumberInput() {
        return otdsPortNumberInput;
    }

    /**
    * @param check otdsPortNumberInput to set.
    */
    public void setOTDSPortNumberInput(String otdsPortNumberInput) {
        this.otdsPortNumberInput = otdsPortNumberInput;
    }

    /**
    * @return the check otdsResourceIdentifier
    */
    public String getOTDSResourceIdentifier() {
        return otdsResourceIdentifier;
    }

    /**
    * @param check otdsResourceIdentifier to set.
    */
    public void setOTDSResourceIdentifier(String otdsResourceIdentifier) {
        this.otdsResourceIdentifier = otdsResourceIdentifier;
    }

    /**
    * @return the check otdsDNPassword
    */
    public String getOTDSDNPassword() {
        return otdsDNPassword;
    }

    /**
    * @param check otdsDNPassword to set.
    */
    public void setOTDSDNPassword(String otdsDNPassword) {
        this.otdsDNPassword = otdsDNPassword;
    }

    /**
     * @return the check otdsdn
     */
    public String getOTDSdn() {
        return otdsdn;
    }

    /**
    * @param check otdsdn to set.
    */
    public void setOTDSdn(String otdsdn) {
        this.otdsdn = otdsdn;
    }

    /**
     * @return the check otdsEmail
     */
    public String getOTDSEmail() {
        return otdsEmail;
    }

    /**
    * @param check otdsEmail to set.
    */
    public void setOTDSEmail(String otdsEmail) {
        this.otdsEmail = otdsEmail;
    }

    /**
     * @return the check otdsFirstName
     */
    public String getOTDSFirstName() {
        return otdsFirstName;
    }

    /**
    * @param check otdsFirstName to set.
    */
    public void setOTDSFirstName(String otdsFirstName) {
        this.otdsFirstName = otdsFirstName;
    }

    /**
     * @return the check otdsLastName
     */
    public String getOTDSLastName() {
        return otdsLastName;
    }

    /**
    * @param check otdsLastName to set.
    */
    public void setOTDSLastName(String otdsLastName) {
        this.otdsLastName = otdsLastName;
    }

    /**
     * @return the check getOTDSDomainName
     */
    public String getOTDSDomainName() {
        return otdsDomainName;
    }

    /**
    * @param check getOTDSDomainName to set.
    */
    public void setOTDSDomainName(String otdsDomainName) {
        this.otdsDomainName = otdsDomainName;
    }

    /**
     * @return the check otdsSearchBaseDN
     */
    public String getOTDSSearchGroupFieldName() {
        return otdsSearchGroupFieldName;
    }

    /**
    * @param check otdsSearchBaseDN to set.
    */
    public void setOTDSSearchGroupFieldName(String otdsSearchGroupFieldName) {
        this.otdsSearchGroupFieldName = otdsSearchGroupFieldName;
    }

}
