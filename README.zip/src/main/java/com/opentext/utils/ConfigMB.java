/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils;

/**
 * Abstraction that represents an Configuration.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ConfigMB {
    public enum ConfigMBDetails {
        MBLOCATION, MBUSER, MBPASSWORD, MBCATEGORY, NONMBUSER;
    }

    /**
     * MBLocation.
     */
    private String mblocation;

    /**
     * MBUser.
     */
    private String mbuser;

    /**
     * MBPassword.
     */
    private String mbpassword;

    /**
     *  MB CATEGORY.
     */
    private String mbcategory;

    /**
     *  MB CATEGORY.
     */
    private String nonmbuser;

    /**
     * Constructor.
     * @param Mb username to be used
     * @param MB password to be used.
     * @param MB location
     * @param MB cataegory
     * @return 
     */
    public ConfigMB(String mblocation, String mbuser, String mbpassword, String mbcategory, String nonmbuser) {

        this.setMBlocation(mblocation);
        this.setMBuser(mbuser);
        this.setMBPassword(mbpassword);
        this.setMBcategory(mbcategory);
        this.setNONMBuser(nonmbuser);

    }

    /**
     * @return the MB Location.
     */
    public String getMBlocation() {
        return mblocation;
    }

    /**
     * @param mblocation to set.
     */
    public void setMBlocation(String mblocation) {
        this.mblocation = mblocation;
    }

    /**
     * @return the MB user.
     */
    public String getMBPassword() {
        return mbpassword;
    }

    /**
     * @param mb user to set.
     */
    public void setMBPassword(String mbpassword) {
        this.mbpassword = mbpassword;
    }

    /**
     * @return the MB user.
     */
    public String getMBuser() {
        return mbuser;
    }

    /**
     * @param mb user to set.
     */
    public void setMBuser(String mbuser) {
        this.mbuser = mbuser;
    }

    /**
     * @return the MB category.
     */
    public String getMBcategory() {
        return mbcategory;
    }

    /**
     * @param MB category to set.
     */
    public void setMBcategory(String mbcategory) {
        this.mbcategory = mbcategory;
    }

    /**
     * @return the NONMBuser.
     */
    public String getNONMBuser() {
        return nonmbuser;
    }

    /**
     * @param NONMBuser to set.
     */
    public void setNONMBuser(String nonmbuser) {
        this.nonmbuser = nonmbuser;
    }

}
