/**
 *
 * Copyright (c) 2017 OpenText.
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * OpenText.
 *
 * Source code style and conventions follow the "ISS Development Guide Java
 * Coding Conventions" standard dated 01/12/2011.
 */
package com.opentext.utils;

/**
 * Abstraction that represents an Configuration.
 * 
 * @author Trinadh Nakka(tnakka@opentext.com)
 */
public class ConfigCloudStorage {

    public enum ConfigCloudDetails {
        CLOUDCLIENTID, CLOUDSECRETID, REFRESHCONTENT, GDRIVETIMEOUT;
    }

    /**
     * cloudClientId
     */
    private String cloudClientId;
    /**
     * cloudSecretId
     */
    private String cloudSecretId;

    /**
     * Constructor.
     * @param ClientID and SecretId 
     */

    public ConfigCloudStorage(String cloudClientId, String cloudSecretId) {
        this.setCloudClientID(cloudClientId);
        this.setCloudSecretID(cloudSecretId);

    }

    /**
     * @return the CloudClientID
     */
    public String getCloudClientID() {
        return cloudClientId;
    }

    /**
    * @param CloudClientID to set.
    */
    public void setCloudClientID(String cloudClientId) {
        this.cloudClientId = cloudClientId;
    }

    /**
    * @return the check CloudSecretID
    */
    public String getCloudSecretID() {
        return cloudSecretId;
    }

    /**
    * @param check CloudSecretID to set.
    */
    public void setCloudSecretID(String cloudSecretId) {
        this.cloudSecretId = cloudSecretId;
    }

}
